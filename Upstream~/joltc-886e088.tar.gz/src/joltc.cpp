// Copyright (c) Amer Koleci and Contributors.
// Licensed under the MIT License (MIT). See LICENSE in the repository root for more information.

#include "joltc.h"

#include <Jolt/Core/Core.h>

JPH_SUPPRESS_WARNING_PUSH
JPH_SUPPRESS_WARNINGS

#include "Jolt/Jolt.h"
#include "Jolt/RegisterTypes.h"
#include "Jolt/Core/Factory.h"
#include "Jolt/Core/TempAllocator.h"
#include "Jolt/Core/JobSystemThreadPool.h"
#include "Jolt/Physics/PhysicsSettings.h"
#include "Jolt/Physics/PhysicsSystem.h"
#include "Jolt/Physics/Collision/BroadPhase/BroadPhaseLayerInterfaceMask.h"
#include "Jolt/Physics/Collision/BroadPhase/ObjectVsBroadPhaseLayerFilterMask.h"
#include "Jolt/Physics/Collision/ObjectLayerPairFilterMask.h"
#include "Jolt/Physics/Collision/BroadPhase/BroadPhaseLayerInterfaceTable.h"
#include "Jolt/Physics/Collision/BroadPhase/ObjectVsBroadPhaseLayerFilterTable.h"
#include "Jolt/Physics/Collision/ObjectLayerPairFilterTable.h"
#include "Jolt/Physics/Collision/CastResult.h"
#include "Jolt/Physics/Collision/CollidePointResult.h"
#include "Jolt/Physics/Collision/CollideShape.h"
#include <Jolt/Physics/Collision/CollisionCollectorImpl.h>
#include <Jolt/Physics/Collision/CollisionDispatch.h>
#include <Jolt/Physics/Collision/EstimateCollisionResponse.h>
#include <Jolt/Physics/Collision/ShapeCast.h>
#include <Jolt/Physics/Collision/SimShapeFilter.h>
#include "Jolt/Physics/Collision/Shape/PlaneShape.h"
#include "Jolt/Physics/Collision/Shape/BoxShape.h"
#include "Jolt/Physics/Collision/Shape/SphereShape.h"
#include "Jolt/Physics/Collision/Shape/TriangleShape.h"
#include "Jolt/Physics/Collision/Shape/CapsuleShape.h"
#include "Jolt/Physics/Collision/Shape/TaperedCapsuleShape.h"
#include "Jolt/Physics/Collision/Shape/CylinderShape.h"
#include "Jolt/Physics/Collision/Shape/TaperedCylinderShape.h"
#include "Jolt/Physics/Collision/Shape/ConvexHullShape.h"
#include "Jolt/Physics/Collision/Shape/MeshShape.h"
#include "Jolt/Physics/Collision/Shape/HeightFieldShape.h"
#include "Jolt/Physics/Collision/Shape/StaticCompoundShape.h"
#include "Jolt/Physics/Collision/Shape/MutableCompoundShape.h"
#include "Jolt/Physics/Collision/Shape/DecoratedShape.h"
#include "Jolt/Physics/Collision/Shape/RotatedTranslatedShape.h"
#include "Jolt/Physics/Collision/Shape/ScaledShape.h"
#include "Jolt/Physics/Collision/Shape/OffsetCenterOfMassShape.h"
#include "Jolt/Physics/Collision/Shape/EmptyShape.h"
#include "Jolt/Physics/Body/BodyCreationSettings.h"
#include "Jolt/Physics/Body/BodyActivationListener.h"
#include "Jolt/Physics/SoftBody/SoftBodyCreationSettings.h"
#include "Jolt/Physics/Collision/RayCast.h"
#include "Jolt/Physics/Collision/BroadPhase/BroadPhaseQuery.h"
#include "Jolt/Physics/Collision/NarrowPhaseQuery.h"
#include "Jolt/Physics/Constraints/SpringSettings.h"
#include "Jolt/Physics/Constraints/FixedConstraint.h"
#include "Jolt/Physics/Constraints/PointConstraint.h"
#include "Jolt/Physics/Constraints/DistanceConstraint.h"
#include "Jolt/Physics/Constraints/HingeConstraint.h"
#include "Jolt/Physics/Constraints/SliderConstraint.h"
#include "Jolt/Physics/Constraints/ConeConstraint.h"
#include "Jolt/Physics/Constraints/SwingTwistConstraint.h"
#include "Jolt/Physics/Constraints/SixDOFConstraint.h"
#include "Jolt/Physics/Constraints/GearConstraint.h"
#include "Jolt/Physics/Constraints/PulleyConstraint.h"
#include "Jolt/Physics/Character/Character.h"
#include "Jolt/Physics/Character/CharacterVirtual.h"
#include "Jolt/Physics/Collision/PhysicsMaterialSimple.h"
#include "Jolt/Physics/Collision/GroupFilterTable.h"
#include "Jolt/Physics/Body/BodyLockMulti.h"
#include "Jolt/Physics/Ragdoll/Ragdoll.h"
#include "Jolt/Skeleton/SkeletonMapper.h"
#include "Jolt/Physics/Vehicle/WheeledVehicleController.h"
#include "Jolt/Physics/Vehicle/MotorcycleController.h"
#include "Jolt/Physics/Vehicle/TrackedVehicleController.h"
#include "Jolt/Physics/SoftBody/SoftBodyMotionProperties.h"
#include "Jolt/Physics/SoftBody/SoftBodySharedSettings.h"
#include "Jolt/Physics/Vehicle/VehicleTrack.h"
#include "Jolt/Core/LinearCurve.h"

#include <cstdio>
#include <cstdarg>
#include <algorithm>

// All Jolt symbols are in the JPH namespace
using namespace JPH;

#define DEF_MAP_DECL(JoltType, c_type)        \
    static inline const JPH::JoltType& As##JoltType(const c_type& t) {    \
        return reinterpret_cast<const JPH::JoltType&>(t);              \
    }                                                               \
    static inline const JPH::JoltType* As##JoltType(const c_type* t) {    \
        return reinterpret_cast<const JPH::JoltType*>(t);              \
    }                                                               \
    static inline JPH::JoltType& As##JoltType(c_type& t) {                \
        return reinterpret_cast<JPH::JoltType&>(t);                    \
    }                                                               \
    static inline JPH::JoltType* As##JoltType(c_type* t) {                \
        return reinterpret_cast<JPH::JoltType*>(t);                    \
    }                                                               \
    static inline const c_type& To##JoltType(const JPH::JoltType& t) {    \
        return reinterpret_cast<const c_type&>(t);                 \
    }                                                               \
    static inline const c_type* To##JoltType(const JPH::JoltType* t) {    \
        return reinterpret_cast<const c_type*>(t);                 \
    }                                                               \
    static inline c_type& To##JoltType(JPH::JoltType& t) {                \
        return reinterpret_cast<c_type&>(t);                       \
    }                                                               \
    static inline c_type* To##JoltType(JPH::JoltType* t) {                \
        return reinterpret_cast<c_type*>(t);                       \
    }

//DEF_MAP_DECL(Quat, JPH_Quat)
DEF_MAP_DECL(ContactManifold, JPH_ContactManifold)
DEF_MAP_DECL(BodyCreationSettings, JPH_BodyCreationSettings)
DEF_MAP_DECL(SoftBodyCreationSettings, JPH_SoftBodyCreationSettings)
DEF_MAP_DECL(SoftBodySharedSettings, JPH_SoftBodySharedSettings)
DEF_MAP_DECL(Body, JPH_Body)
DEF_MAP_DECL(BodyInterface, JPH_BodyInterface)
DEF_MAP_DECL(BodyLockInterface, JPH_BodyLockInterface)
DEF_MAP_DECL(MotionProperties, JPH_MotionProperties)
DEF_MAP_DECL(BroadPhaseQuery, JPH_BroadPhaseQuery)
DEF_MAP_DECL(NarrowPhaseQuery, JPH_NarrowPhaseQuery)
DEF_MAP_DECL(PhysicsMaterial, JPH_PhysicsMaterial)

DEF_MAP_DECL(Shape, JPH_Shape)
DEF_MAP_DECL(ShapeSettings, JPH_ShapeSettings)
DEF_MAP_DECL(EmptyShape, JPH_EmptyShape)
DEF_MAP_DECL(EmptyShapeSettings, JPH_EmptyShapeSettings)
DEF_MAP_DECL(CompoundShape, JPH_CompoundShape)
DEF_MAP_DECL(CompoundShapeSettings, JPH_CompoundShapeSettings)
DEF_MAP_DECL(MutableCompoundShape, JPH_MutableCompoundShape)
DEF_MAP_DECL(MutableCompoundShapeSettings, JPH_MutableCompoundShapeSettings)
DEF_MAP_DECL(MeshShape, JPH_MeshShape)
DEF_MAP_DECL(MeshShapeSettings, JPH_MeshShapeSettings)
DEF_MAP_DECL(HeightFieldShape, JPH_HeightFieldShape)
DEF_MAP_DECL(HeightFieldShapeSettings, JPH_HeightFieldShapeSettings)
DEF_MAP_DECL(ConvexShape, JPH_ConvexShape)
DEF_MAP_DECL(ConvexShapeSettings, JPH_ConvexShapeSettings)
DEF_MAP_DECL(ConvexHullShape, JPH_ConvexHullShape)
DEF_MAP_DECL(ConvexHullShapeSettings, JPH_ConvexHullShapeSettings)
DEF_MAP_DECL(SphereShape, JPH_SphereShape)
DEF_MAP_DECL(SphereShapeSettings, JPH_SphereShapeSettings)
DEF_MAP_DECL(BoxShape, JPH_BoxShape)
DEF_MAP_DECL(BoxShapeSettings, JPH_BoxShapeSettings)
DEF_MAP_DECL(PlaneShape, JPH_PlaneShape)
DEF_MAP_DECL(PlaneShapeSettings, JPH_PlaneShapeSettings)
DEF_MAP_DECL(CapsuleShape, JPH_CapsuleShape)
DEF_MAP_DECL(CapsuleShapeSettings, JPH_CapsuleShapeSettings)
DEF_MAP_DECL(CylinderShape, JPH_CylinderShape)
DEF_MAP_DECL(CylinderShapeSettings, JPH_CylinderShapeSettings)
DEF_MAP_DECL(TriangleShape, JPH_TriangleShape)
DEF_MAP_DECL(TriangleShapeSettings, JPH_TriangleShapeSettings)
DEF_MAP_DECL(TaperedCylinderShape, JPH_TaperedCylinderShape)
DEF_MAP_DECL(TaperedCylinderShapeSettings, JPH_TaperedCylinderShapeSettings)
DEF_MAP_DECL(TaperedCapsuleShape, JPH_TaperedCapsuleShape)
DEF_MAP_DECL(TaperedCapsuleShapeSettings, JPH_TaperedCapsuleShapeSettings)
DEF_MAP_DECL(StaticCompoundShape, JPH_StaticCompoundShape)
DEF_MAP_DECL(StaticCompoundShapeSettings, JPH_StaticCompoundShapeSettings)
DEF_MAP_DECL(DecoratedShape, JPH_DecoratedShape)
DEF_MAP_DECL(RotatedTranslatedShape, JPH_RotatedTranslatedShape)
DEF_MAP_DECL(RotatedTranslatedShapeSettings, JPH_RotatedTranslatedShapeSettings)
DEF_MAP_DECL(ScaledShape, JPH_ScaledShape)
DEF_MAP_DECL(ScaledShapeSettings, JPH_ScaledShapeSettings)
DEF_MAP_DECL(OffsetCenterOfMassShape, JPH_OffsetCenterOfMassShape)
DEF_MAP_DECL(OffsetCenterOfMassShapeSettings, JPH_OffsetCenterOfMassShapeSettings)

DEF_MAP_DECL(Constraint, JPH_Constraint)
DEF_MAP_DECL(TwoBodyConstraint, JPH_TwoBodyConstraint)
DEF_MAP_DECL(FixedConstraint, JPH_FixedConstraint)
DEF_MAP_DECL(DistanceConstraint, JPH_DistanceConstraint)
DEF_MAP_DECL(PointConstraint, JPH_PointConstraint)
DEF_MAP_DECL(HingeConstraint, JPH_HingeConstraint)
DEF_MAP_DECL(SliderConstraint, JPH_SliderConstraint)
DEF_MAP_DECL(ConeConstraint, JPH_ConeConstraint)
DEF_MAP_DECL(SwingTwistConstraint, JPH_SwingTwistConstraint)
DEF_MAP_DECL(SixDOFConstraint, JPH_SixDOFConstraint)
DEF_MAP_DECL(GearConstraint, JPH_GearConstraint)
DEF_MAP_DECL(Character, JPH_Character)
DEF_MAP_DECL(CharacterVirtual, JPH_CharacterVirtual)
DEF_MAP_DECL(Skeleton, JPH_Skeleton)
DEF_MAP_DECL(SkeletonPose, JPH_SkeletonPose)
DEF_MAP_DECL(SkeletalAnimation, JPH_SkeletalAnimation)
DEF_MAP_DECL(SkeletonMapper, JPH_SkeletonMapper)
DEF_MAP_DECL(RagdollSettings, JPH_RagdollSettings)
DEF_MAP_DECL(Ragdoll, JPH_Ragdoll)
DEF_MAP_DECL(GroupFilter, JPH_GroupFilter)
DEF_MAP_DECL(GroupFilterTable, JPH_GroupFilterTable)

DEF_MAP_DECL(PhysicsStepListener, JPH_PhysicsStepListener)

// Vehicle
DEF_MAP_DECL(WheelSettings, JPH_WheelSettings)
DEF_MAP_DECL(Wheel, JPH_Wheel)

DEF_MAP_DECL(VehicleControllerSettings, JPH_VehicleControllerSettings)
DEF_MAP_DECL(VehicleController, JPH_VehicleController)

DEF_MAP_DECL(WheelSettingsWV, JPH_WheelSettingsWV)
DEF_MAP_DECL(WheelWV, JPH_WheelWV)
DEF_MAP_DECL(WheeledVehicleControllerSettings, JPH_WheeledVehicleControllerSettings)
DEF_MAP_DECL(WheeledVehicleController, JPH_WheeledVehicleController)

DEF_MAP_DECL(MotorcycleControllerSettings, JPH_MotorcycleControllerSettings)
DEF_MAP_DECL(MotorcycleController, JPH_MotorcycleController)

DEF_MAP_DECL(WheelSettingsTV, JPH_WheelSettingsTV)
DEF_MAP_DECL(WheelTV, JPH_WheelTV)
DEF_MAP_DECL(TrackedVehicleControllerSettings, JPH_TrackedVehicleControllerSettings)
DEF_MAP_DECL(TrackedVehicleController, JPH_TrackedVehicleController)
DEF_MAP_DECL(VehicleTrackSettings, JPH_VehicleTrackSettings)
DEF_MAP_DECL(VehicleTrack, JPH_VehicleTrack)

DEF_MAP_DECL(VehicleEngine, JPH_VehicleEngine)
DEF_MAP_DECL(VehicleTransmission, JPH_VehicleTransmission)
DEF_MAP_DECL(VehicleTransmissionSettings, JPH_VehicleTransmissionSettings)
DEF_MAP_DECL(VehicleCollisionTester, JPH_VehicleCollisionTester)
DEF_MAP_DECL(VehicleCollisionTesterRay, JPH_VehicleCollisionTesterRay)
DEF_MAP_DECL(VehicleCollisionTesterCastSphere, JPH_VehicleCollisionTesterCastSphere)
DEF_MAP_DECL(VehicleCollisionTesterCastCylinder, JPH_VehicleCollisionTesterCastCylinder)
DEF_MAP_DECL(VehicleConstraint, JPH_VehicleConstraint)

DEF_MAP_DECL(LinearCurve, JPH_LinearCurve)

DEF_MAP_DECL(TempAllocator, JPH_TempAllocator)

// Callback for traces, connect this to your own trace function if you have one
static JPH_TraceFunc s_TraceFunc = nullptr;

static void TraceImpl(const char* fmt, ...)
{
	// Format the message
	va_list list;
	va_start(list, fmt);

	// Print to the TTY
	if (s_TraceFunc)
	{
		char buffer[1024];
		vsnprintf(buffer, sizeof(buffer), fmt, list);
		va_end(list);
		s_TraceFunc(buffer);
	}
	else
	{
		vfprintf(stdout, fmt, list);
		printf("\n");
		fflush(stdout);
	}
}

#ifdef JPH_ENABLE_ASSERTS
static JPH_AssertFailureFunc s_AssertFailureFunc = nullptr;

// Callback for asserts, connect this to your own assert handler if you have one
static bool AssertFailedImpl(const char* inExpression, const char* inMessage, const char* inFile, uint inLine)
{
	if (s_AssertFailureFunc)
	{
		return s_AssertFailureFunc(inExpression, inMessage, inFile, inLine);
	}

	// Print to the TTY
	fprintf(stderr, "%s:%u: (%s) %s\n", inFile, inLine, inExpression, (inMessage != nullptr) ? inMessage : "");

	// Breakpoint
	return true;
};

#endif // JPH_ENABLE_ASSERTS

// From Jolt conversion methods
static inline JPH_Vec3 FromJolt(const Vec3& vec)
{
	return { vec.GetX(), vec.GetY(), vec.GetZ() };
}

static inline JPH_Vec4 FromJolt(const Vec4& vec)
{
	return { vec.GetX(), vec.GetY(), vec.GetZ(), vec.GetW() };
}

static inline void FromJolt(const Vec3& vec, JPH_Vec3* result)
{
	result->x = vec.GetX();
	result->y = vec.GetY();
	result->z = vec.GetZ();
}

static inline void FromJolt(const Float3& vec, JPH_Vec3* result)
{
	result->x = vec.x;
	result->y = vec.y;
	result->z = vec.z;
}

static inline void FromJolt(const Quat& quat, JPH_Quat* result)
{
	result->x = quat.GetX();
	result->y = quat.GetY();
	result->z = quat.GetZ();
	result->w = quat.GetW();
}

static inline void FromJolt(const Plane& value, JPH_Plane* result)
{
	FromJolt(value.GetNormal(), &result->normal);
	result->distance = value.GetConstant();
}

static inline void FromJolt(const AABox& value, JPH_AABox* result)
{
	FromJolt(value.mMin, &result->min);
	FromJolt(value.mMax, &result->max);
}

static inline void FromJolt(const Mat44& matrix, JPH_Mat4* result)
{
	memcpy(result, &matrix, sizeof(JPH_Mat4));
}

#if defined(JPH_DOUBLE_PRECISION)
static inline void FromJolt(const RVec3& vec, JPH_RVec3* result)
{
	result->x = vec.GetX();
	result->y = vec.GetY();
	result->z = vec.GetZ();
}

static inline JPH_RVec3 FromJolt(const RVec3& vec)
{
	return { vec.GetX(), vec.GetY(), vec.GetZ() };
}

static inline void FromJolt(const DMat44& matrix, JPH_RMat4* result)
{
	Vec4 column0 = matrix.GetColumn4(0);
	Vec4 column1 = matrix.GetColumn4(1);
	Vec4 column2 = matrix.GetColumn4(2);
	DVec3 translation = matrix.GetTranslation();

	result->column[0] = FromJolt(column0);
	result->column[1] = FromJolt(column1);
	result->column[2] = FromJolt(column2);
	result->column3 = FromJolt(translation);
}
#endif /* defined(JPH_DOUBLE_PRECISION) */

static inline void FromJolt(const LinearCurve::Point& jolt, JPH_Point* result)
{
	result->x = jolt.mX;
	result->y = jolt.mY;
}

static inline void FromJolt(const MassProperties& jolt, JPH_MassProperties* result)
{
	result->mass = jolt.mMass;
	FromJolt(jolt.mInertia, &result->inertia);
}

static inline void FromJolt(const SpringSettings& jolt, JPH_SpringSettings* result)
{
	result->mode = static_cast<JPH_SpringMode>(jolt.mMode);
	result->frequencyOrStiffness = jolt.mFrequency;
	result->damping = jolt.mDamping;
}

static inline void FromJolt(const MotorSettings& jolt, JPH_MotorSettings* result)
{
	FromJolt(jolt.mSpringSettings, &result->springSettings);
	result->minForceLimit = jolt.mMinForceLimit;
	result->maxForceLimit = jolt.mMaxForceLimit;
	result->minTorqueLimit = jolt.mMinTorqueLimit;
	result->maxTorqueLimit = jolt.mMaxTorqueLimit;
}

static inline void FromJolt(const ContactSettings& jolt, JPH_ContactSettings* result)
{
	JPH_ASSERT(result);

	result->combinedFriction = jolt.mCombinedFriction;
	result->combinedRestitution = jolt.mCombinedRestitution;
	result->invMassScale1 = jolt.mInvMassScale1;
	result->invInertiaScale1 = jolt.mInvInertiaScale1;
	result->invMassScale2 = jolt.mInvMassScale2;
	result->invInertiaScale2 = jolt.mInvInertiaScale2;
	result->isSensor = jolt.mIsSensor;
	FromJolt(jolt.mRelativeLinearSurfaceVelocity, &result->relativeLinearSurfaceVelocity);
	FromJolt(jolt.mRelativeAngularSurfaceVelocity, &result->relativeAngularSurfaceVelocity);
}

static inline const JPH_PhysicsMaterial* FromJolt(const JPH::PhysicsMaterial* joltMaterial)
{
	return joltMaterial != nullptr ? ToPhysicsMaterial(joltMaterial) : nullptr;
}

static inline void FromJolt(const CharacterContact& jolt, JPH_CharacterContact* result)
{
	result->hash = jolt.GetHash();
	result->bodyB = (JPH_BodyID)jolt.mBodyB.GetIndexAndSequenceNumber();
	result->characterIDB = (JPH_BodyID)jolt.mCharacterIDB.GetValue();
	result->subShapeIDB = (JPH_BodyID)jolt.mSubShapeIDB.GetValue();
	FromJolt(jolt.mPosition, &result->position);
	FromJolt(jolt.mLinearVelocity, &result->linearVelocity);
	FromJolt(jolt.mContactNormal, &result->contactNormal);
	FromJolt(jolt.mSurfaceNormal, &result->surfaceNormal);
	result->distance = jolt.mDistance;
	result->fraction = jolt.mFraction;
	result->motionTypeB = static_cast<JPH_MotionType>(jolt.mMotionTypeB);
	result->isSensorB = jolt.mIsSensorB;
	result->characterB = ToCharacterVirtual(jolt.mCharacterB);
	result->userData = jolt.mUserData;
	result->material = ToPhysicsMaterial(jolt.mMaterial);
	result->hadCollision = jolt.mHadCollision;
	result->wasDiscarded = jolt.mWasDiscarded;
	result->canPushCharacter = jolt.mCanPushCharacter;
	result->isBackFacingContact = jolt.mIsBackFacingContact;
}

static inline void FromJolt(const Skeleton::Joint& jolt, JPH_SkeletonJoint* result)
{
	result->name = jolt.mName.c_str();
	result->parentName = jolt.mParentName.c_str();
	result->parentJointIndex = jolt.mParentJointIndex;
}

static inline JPH_CollideShapeResult FromJolt(const JPH::CollideShapeResult& jolt)
{
	JPH_CollideShapeResult result{};
	FromJolt(jolt.mContactPointOn1, &result.contactPointOn1);
	FromJolt(jolt.mContactPointOn2, &result.contactPointOn2);
	FromJolt(jolt.mPenetrationAxis, &result.penetrationAxis);
	result.penetrationDepth = jolt.mPenetrationDepth;
	result.subShapeID1 = jolt.mSubShapeID1.GetValue();
	result.subShapeID2 = jolt.mSubShapeID2.GetValue();
	result.bodyID2 = jolt.mBodyID2.GetIndexAndSequenceNumber();

	if (!jolt.mShape1Face.empty())
	{
		result.shape1FaceCount = static_cast<uint32_t>(jolt.mShape1Face.size());
		result.shape1Faces = (JPH_Vec3*)malloc(sizeof(JPH_Vec3) * result.shape1FaceCount);
		for (uint32_t i = 0; i < result.shape1FaceCount; i++)
		{
			FromJolt(jolt.mShape1Face[i], &result.shape1Faces[i]);
		}
	}

	if (!jolt.mShape2Face.empty())
	{
		result.shape2FaceCount = static_cast<uint32_t>(jolt.mShape2Face.size());
		result.shape2Faces = (JPH_Vec3*)malloc(sizeof(JPH_Vec3) * result.shape2FaceCount);
		for (uint32_t i = 0; i < result.shape2FaceCount; i++)
		{
			FromJolt(jolt.mShape2Face[i], &result.shape2Faces[i]);
		}
	}

	return result;
}

static inline void FromJolt(const CollisionGroup& jolt, JPH_CollisionGroup* result)
{
	result->groupFilter = ToGroupFilter(jolt.GetGroupFilter());
	result->groupID = jolt.GetGroupID();
	result->subGroupID = jolt.GetSubGroupID();
}

// To Jolt conversion methods
static inline JPH::Vec3 ToJolt(const JPH_Vec3& vec)
{
	return JPH::Vec3(vec.x, vec.y, vec.z);
}

static inline JPH::Vec3 ToJolt(const JPH_Vec3* vec)
{
	return JPH::Vec3(vec->x, vec->y, vec->z);
}

static inline JPH::Vec4 ToJolt(const JPH_Vec4& vec)
{
	return JPH::Vec4(vec.x, vec.y, vec.z, vec.w);
}

static inline JPH::Quat ToJolt(const JPH_Quat* quat)
{
	return JPH::Quat(quat->x, quat->y, quat->z, quat->w);
}

static inline JPH::Plane ToJolt(const JPH_Plane* value)
{
	return JPH::Plane(ToJolt(value->normal), value->distance);
}

static inline JPH::Mat44 ToJolt(const JPH_Mat4* matrix)
{
	JPH::Mat44 result{};
	memcpy(&result, matrix, sizeof(JPH_Mat4));
	return result;
}

static inline JPH::Float3 ToJoltFloat3(const JPH_Vec3& vec)
{
	return JPH::Float3(vec.x, vec.y, vec.z);
}

static inline JPH::AABox ToJolt(const JPH_AABox* value)
{
	return JPH::AABox(ToJolt(value->min), ToJolt(value->max));
}

#if defined(JPH_DOUBLE_PRECISION)
static inline JPH::RVec3 ToJolt(const JPH_RVec3& vec)
{
	return JPH::RVec3(vec.x, vec.y, vec.z);
}

static inline JPH::RVec3 ToJolt(const JPH_RVec3* vec)
{
	return JPH::RVec3(vec->x, vec->y, vec->z);
}

static inline JPH::RMat44 ToJolt(const JPH_RMat4* matrix)
{
	JPH::RMat44 result{};
	result.SetColumn4(0, ToJolt(matrix->column[0]));
	result.SetColumn4(1, ToJolt(matrix->column[1]));
	result.SetColumn4(2, ToJolt(matrix->column[2]));
	result.SetTranslation(ToJolt(matrix->column3));
	return result;
}
#endif /* defined(JPH_DOUBLE_PRECISION) */

static inline JPH::MassProperties ToJolt(const JPH_MassProperties* properties)
{
	JPH::MassProperties result{};
	if (!properties)
		return result;
	result.mMass = properties->mass;
	result.mInertia = ToJolt(&properties->inertia);
	return result;
}

static inline JPH::RayCastSettings ToJolt(const JPH_RayCastSettings* settings)
{
	JPH::RayCastSettings result{};
	if (!settings)
		return result;
	result.mBackFaceModeTriangles = static_cast<EBackFaceMode>(settings->backFaceModeTriangles);
	result.mBackFaceModeConvex = static_cast<EBackFaceMode>(settings->backFaceModeConvex);
	result.mTreatConvexAsSolid = settings->treatConvexAsSolid;
	return result;
}

static inline JPH::SpringSettings ToJolt(const JPH_SpringSettings* settings)
{
	JPH::SpringSettings result{};
	if (!settings)
		return result;
	result.mMode = static_cast<JPH::ESpringMode>(settings->mode);
	result.mFrequency = settings->frequencyOrStiffness;
	result.mDamping = settings->damping;
	return result;
}

static inline JPH::MotorSettings ToJolt(const JPH_MotorSettings* settings)
{
	JPH::MotorSettings result{};
	if (!settings)
		return result;
	result.mSpringSettings = ToJolt(&settings->springSettings);
	result.mMinForceLimit = settings->minForceLimit;
	result.mMaxForceLimit = settings->maxForceLimit;
	result.mMinTorqueLimit = settings->minTorqueLimit;
	result.mMaxTorqueLimit = settings->maxTorqueLimit;
	return result;
}

static inline JPH::CollisionGroup ToJolt(const JPH_CollisionGroup* group)
{
	JPH::CollisionGroup result(
		AsGroupFilter(group->groupFilter),
		static_cast<JPH::CollisionGroup::GroupID>(group->groupID),
		static_cast<JPH::CollisionGroup::SubGroupID>(group->subGroupID)
	);
	return result;
}

static inline void ToJolt(ContactSettings& jolt, const JPH_ContactSettings* settings)
{
	jolt.mCombinedFriction = settings->combinedFriction;
	jolt.mCombinedRestitution = settings->combinedRestitution;
	jolt.mInvMassScale1 = settings->invMassScale1;
	jolt.mInvInertiaScale1 = settings->invInertiaScale1;
	jolt.mInvMassScale2 = settings->invMassScale2;
	jolt.mInvInertiaScale2 = settings->invInertiaScale2;
	jolt.mIsSensor = settings->isSensor;
	jolt.mRelativeLinearSurfaceVelocity = ToJolt(settings->relativeLinearSurfaceVelocity);
	jolt.mRelativeAngularSurfaceVelocity = ToJolt(settings->relativeAngularSurfaceVelocity);
}

static void ToJolt(JPH::VehicleTrackSettings& joltTrack, const JPH_VehicleTrackSettings* track)
{
	joltTrack.mDrivenWheel = track->drivenWheel;
	joltTrack.mInertia = track->inertia;
	joltTrack.mAngularDamping = track->angularDamping;
	joltTrack.mMaxBrakeTorque = track->maxBrakeTorque;
	joltTrack.mDifferentialRatio = track->differentialRatio;

	joltTrack.mWheels.clear();
	if (track->wheels && track->wheelsCount > 0)
	{
		for (uint32_t i = 0; i < track->wheelsCount; ++i)
		{
			joltTrack.mWheels.push_back(track->wheels[i]);
		}
	}
}

void JPH_MassProperties_DecomposePrincipalMomentsOfInertia(JPH_MassProperties* properties, JPH_Mat4* rotation, JPH_Vec3* diagonal)
{
	JPH::Mat44 joltRotation;
	JPH::Vec3 joltDiagonal;
	JPH::MassProperties joltProperties = ToJolt(properties);
	joltProperties.DecomposePrincipalMomentsOfInertia(joltRotation, joltDiagonal);
	FromJolt(joltRotation, rotation);
	FromJolt(joltDiagonal, diagonal);
}

void JPH_MassProperties_ScaleToMass(JPH_MassProperties* properties, float mass)
{
	JPH::MassProperties joltProperties = ToJolt(properties);
	joltProperties.ScaleToMass(mass);
	properties->mass = joltProperties.mMass;
	FromJolt(joltProperties.mInertia, &properties->inertia);
}

void JPH_MassProperties_GetEquivalentSolidBoxSize(float mass, const JPH_Vec3* inertiaDiagonal, JPH_Vec3* result)
{
	FromJolt(JPH::MassProperties::sGetEquivalentSolidBoxSize(mass, ToJolt(inertiaDiagonal)), result);
}

JPH_CAPI void JPH_RayCast_GetPointOnRay(const JPH_Vec3* origin, const JPH_Vec3* direction, float fraction, JPH_Vec3* result)
{
	JPH_ASSERT(origin);
	JPH_ASSERT(direction);
	JPH_ASSERT(result);

	JPH::RayCast ray(ToJolt(origin), ToJolt(direction));
	JPH::Vec3 point = ray.GetPointOnRay(fraction);
	FromJolt(point, result);
}

JPH_CAPI void JPH_RRayCast_GetPointOnRay(const JPH_RVec3* origin, const JPH_Vec3* direction, float fraction, JPH_RVec3* result)
{
	JPH_ASSERT(origin);
	JPH_ASSERT(direction);
	JPH_ASSERT(result);

	JPH::RRayCast ray(ToJolt(origin), ToJolt(direction));
	JPH::RVec3 point = ray.GetPointOnRay(fraction);
	FromJolt(point, result);
}

static JPH::Triangle ToTriangle(const JPH_Triangle& triangle)
{
	return JPH::Triangle(ToJoltFloat3(triangle.v1), ToJoltFloat3(triangle.v2), ToJoltFloat3(triangle.v3), triangle.materialIndex);
}

static JPH::IndexedTriangle ToIndexedTriangle(const JPH_IndexedTriangle& triangle)
{
	return JPH::IndexedTriangle(triangle.i1, triangle.i2, triangle.i3, triangle.materialIndex, triangle.userData);
}

// 10 MB was not enough for large simulation, let's use TempAllocatorMalloc
static bool s_initialized = false;
static TempAllocator* s_TempAllocator = nullptr;

class JobSystemCallback final : public JPH::JobSystemWithBarrier
{
public:
	JobSystemCallback(const JPH_JobSystemConfig* config)
	{
		JobSystemWithBarrier::Init(config->maxBarriers > 0 ? config->maxBarriers : JPH::cMaxPhysicsBarriers);
		mJobs.Init(JPH::cMaxPhysicsJobs, JPH::cMaxPhysicsJobs);
		mConfig = *config;
	}

	JobHandle CreateJob(const char* name, JPH::ColorArg color, const JPH::JobSystem::JobFunction& callback, uint32_t dependencies = 0) override
	{
		uint32_t index;

		for (;;)
		{
			index = mJobs.ConstructObject(name, color, this, callback, dependencies);
			if (index != FixedSizeFreeList<Job>::cInvalidObjectIndex)
				break;
			JPH_ASSERT(false, "No jobs available!");
			std::this_thread::sleep_for(std::chrono::microseconds(100));
		}

		Job* job = &mJobs.Get(index);
		JobHandle handle(job);

		if (dependencies == 0)
			QueueJob(job);

		return handle;
	}

	void FreeJob(Job* job) override
	{
		mJobs.DestructObject(job);
	}

	int GetMaxConcurrency() const override
	{
		return mConfig.maxConcurrency;
	}

protected:
	static void RunJob(void* arg)
	{
		Job* job = reinterpret_cast<Job*>(arg);
		job->Execute();
		job->Release();
	}

	void QueueJob(Job* job) override
	{
		job->AddRef();
		mConfig.queueJob(mConfig.context, RunJob, job);
	}

	void QueueJobs(Job** jobs, uint32_t count) override
	{
		for (uint32_t i = 0; i < count; i++) {
			jobs[i]->AddRef();
		}

		mConfig.queueJobs(mConfig.context, RunJob, (void**)jobs, count);
	}

private:
	FixedSizeFreeList<Job> mJobs;
	JPH_JobSystemConfig mConfig;
};

JPH_JobSystem* JPH_JobSystemThreadPool_Create(const JobSystemThreadPoolConfig* config)
{
	JobSystemThreadPoolConfig createConfig{};
	if (config)
		createConfig = *config;

	uint32_t maxJobs = createConfig.maxJobs > 0 ? createConfig.maxJobs : JPH::cMaxPhysicsJobs;
	uint32_t maxBarriers = createConfig.maxBarriers > 0 ? createConfig.maxBarriers : JPH::cMaxPhysicsBarriers;
	int32_t numThreads = createConfig.numThreads > 0 ? createConfig.numThreads : -1;
	JPH::JobSystem* jobSystem = new JPH::JobSystemThreadPool(maxJobs, maxBarriers, numThreads);
	return reinterpret_cast<JPH_JobSystem*>(jobSystem);
}

JPH_JobSystem* JPH_JobSystemCallback_Create(const JPH_JobSystemConfig* config)
{
	JPH::JobSystem* jobSystem = new JobSystemCallback(config);
	return reinterpret_cast<JPH_JobSystem*>(jobSystem);
}

void JPH_JobSystem_Destroy(JPH_JobSystem* jobSystem)
{
	delete reinterpret_cast<JPH::JobSystem*>(jobSystem);
}

bool JPH_Init()
{
	if (s_initialized)
		return true;

	JPH::RegisterDefaultAllocator();

	JPH::Trace = TraceImpl;
	JPH_IF_ENABLE_ASSERTS(JPH::AssertFailed = AssertFailedImpl;)

		// Create a factory
		JPH::Factory::sInstance = new JPH::Factory();

	// Register all Jolt physics types
	JPH::RegisterTypes();

#if defined(__SANITIZE_THREAD__) || defined(ENABLE_SANITIZER)
	// ThreadSanitizer does not understand Jolt's lock-free 8MB bump allocator
	// and will flag cross-frame memory reuse as data races.
	// We fall back to standard malloc/free which TSan can track perfectly.
	s_TempAllocator = new TempAllocatorMalloc();
#else
	// High-performance lock-free allocator for production
	s_TempAllocator = new TempAllocatorImplWithMallocFallback(8 * 1024 * 1024);
#endif

	s_initialized = true;

	return true;
}

void JPH_Shutdown(void)
{
	if (!s_initialized)
		return;

	delete s_TempAllocator; s_TempAllocator = nullptr;

	// Unregisters all types with the factory and cleans up the default material
	JPH::UnregisterTypes();

	// Destroy the factory
	delete JPH::Factory::sInstance;
	JPH::Factory::sInstance = nullptr;

	s_initialized = false;
}

void JPH_SetTraceHandler(JPH_TraceFunc handler)
{
	s_TraceFunc = handler;
}

void JPH_SetAssertFailureHandler(JPH_AssertFailureFunc handler)
{
#ifdef JPH_ENABLE_ASSERTS
	s_AssertFailureFunc = handler;
#else
	JPH_UNUSED(handler);
#endif
}

/* JPH_CollideShapeResult */
JPH_CAPI void JPH_CollideShapeResult_FreeMembers(JPH_CollideShapeResult* result)
{
	if (result->shape1FaceCount)
	{
		free(result->shape1Faces);
	}

	if (result->shape2FaceCount)
	{
		free(result->shape2Faces);
	}
}

void JPH_CollisionEstimationResult_FreeMembers(JPH_CollisionEstimationResult* result)
{
	if (result->contactImpulseCount)
	{
		free(result->contactImpulses);
	}
}

/* JPH_BroadPhaseLayerInterface */
void JPH_BroadPhaseLayerInterface_Destroy(JPH_BroadPhaseLayerInterface* bpInterface)
{
	if (bpInterface)
		delete reinterpret_cast<JPH::BroadPhaseLayerInterface*>(bpInterface);
}

JPH_BroadPhaseLayerInterface* JPH_BroadPhaseLayerInterfaceMask_Create(uint32_t numBroadPhaseLayers)
{
	auto system = new BroadPhaseLayerInterfaceMask(numBroadPhaseLayers);
	return reinterpret_cast<JPH_BroadPhaseLayerInterface*>(system);
}

void JPH_BroadPhaseLayerInterfaceMask_ConfigureLayer(JPH_BroadPhaseLayerInterface* bpInterface, JPH_BroadPhaseLayer broadPhaseLayer, uint32_t groupsToInclude, uint32_t groupsToExclude)
{
	reinterpret_cast<JPH::BroadPhaseLayerInterfaceMask*>(bpInterface)->ConfigureLayer(
		static_cast<JPH::BroadPhaseLayer>(broadPhaseLayer),
		groupsToInclude,
		groupsToExclude
	);
}

JPH_BroadPhaseLayerInterface* JPH_BroadPhaseLayerInterfaceTable_Create(uint32_t numObjectLayers, uint32_t numBroadPhaseLayers)
{
	auto system = new BroadPhaseLayerInterfaceTable(numObjectLayers, numBroadPhaseLayers);
	return reinterpret_cast<JPH_BroadPhaseLayerInterface*>(system);
}

void JPH_BroadPhaseLayerInterfaceTable_MapObjectToBroadPhaseLayer(JPH_BroadPhaseLayerInterface* bpInterface, JPH_ObjectLayer objectLayer, JPH_BroadPhaseLayer broadPhaseLayer)
{
	reinterpret_cast<JPH::BroadPhaseLayerInterfaceTable*>(bpInterface)->MapObjectToBroadPhaseLayer(
		static_cast<JPH::ObjectLayer>(objectLayer),
		static_cast<JPH::BroadPhaseLayer>(broadPhaseLayer)
	);
}

/* JPH_ObjectLayerPairFilter */
void JPH_ObjectLayerPairFilter_Destroy(JPH_ObjectLayerPairFilter* filter)
{
	if (filter)
		delete reinterpret_cast<JPH::ObjectLayerPairFilter*>(filter);
}

JPH_ObjectLayerPairFilter* JPH_ObjectLayerPairFilterMask_Create(void)
{
	auto filter = new JPH::ObjectLayerPairFilterMask();
	return reinterpret_cast<JPH_ObjectLayerPairFilter*>(filter);
}

JPH_ObjectLayer JPH_ObjectLayerPairFilterMask_GetObjectLayer(uint32_t group, uint32_t mask)
{
	return static_cast<JPH_ObjectLayer>(JPH::ObjectLayerPairFilterMask::sGetObjectLayer(group, mask));
}

uint32_t JPH_ObjectLayerPairFilterMask_GetGroup(JPH_ObjectLayer layer)
{
	return JPH::ObjectLayerPairFilterMask::sGetGroup(static_cast<JPH::ObjectLayer>(layer));
}

uint32_t JPH_ObjectLayerPairFilterMask_GetMask(JPH_ObjectLayer layer)
{
	return JPH::ObjectLayerPairFilterMask::sGetMask(static_cast<JPH::ObjectLayer>(layer));
}

JPH_ObjectLayerPairFilter* JPH_ObjectLayerPairFilterTable_Create(uint32_t numObjectLayers)
{
	auto filter = new JPH::ObjectLayerPairFilterTable(numObjectLayers);
	return reinterpret_cast<JPH_ObjectLayerPairFilter*>(filter);
}

void JPH_ObjectLayerPairFilterTable_DisableCollision(JPH_ObjectLayerPairFilter* objectFilter, JPH_ObjectLayer layer1, JPH_ObjectLayer layer2)
{
	reinterpret_cast<JPH::ObjectLayerPairFilterTable*>(objectFilter)->DisableCollision(
		static_cast<JPH::ObjectLayer>(layer1),
		static_cast<JPH::ObjectLayer>(layer2)
	);
}

void JPH_ObjectLayerPairFilterTable_EnableCollision(JPH_ObjectLayerPairFilter* objectFilter, JPH_ObjectLayer layer1, JPH_ObjectLayer layer2)
{
	reinterpret_cast<JPH::ObjectLayerPairFilterTable*>(objectFilter)->EnableCollision(
		static_cast<JPH::ObjectLayer>(layer1),
		static_cast<JPH::ObjectLayer>(layer2)
	);
}

bool JPH_ObjectLayerPairFilterTable_ShouldCollide(JPH_ObjectLayerPairFilter* objectFilter, JPH_ObjectLayer layer1, JPH_ObjectLayer layer2)
{
	return reinterpret_cast<JPH::ObjectLayerPairFilterTable*>(objectFilter)->ShouldCollide(
		static_cast<JPH::ObjectLayer>(layer1),
		static_cast<JPH::ObjectLayer>(layer2)
	);
}

/* JPH_ObjectVsBroadPhaseLayerFilter */
void JPH_ObjectVsBroadPhaseLayerFilter_Destroy(JPH_ObjectVsBroadPhaseLayerFilter* filter)
{
	if (filter)
		delete reinterpret_cast<JPH::ObjectVsBroadPhaseLayerFilter*>(filter);
}

JPH_ObjectVsBroadPhaseLayerFilter* JPH_ObjectVsBroadPhaseLayerFilterMask_Create(const JPH_BroadPhaseLayerInterface* broadPhaseLayerInterface)
{
	auto joltBroadPhaseLayerInterface = reinterpret_cast<const JPH::BroadPhaseLayerInterfaceMask*>(broadPhaseLayerInterface);
	auto filter = new JPH::ObjectVsBroadPhaseLayerFilterMask(*joltBroadPhaseLayerInterface);
	return reinterpret_cast<JPH_ObjectVsBroadPhaseLayerFilter*>(filter);
}

JPH_ObjectVsBroadPhaseLayerFilter* JPH_ObjectVsBroadPhaseLayerFilterTable_Create(
	JPH_BroadPhaseLayerInterface* broadPhaseLayerInterface, uint32_t numBroadPhaseLayers,
	JPH_ObjectLayerPairFilter* objectLayerPairFilter, uint32_t numObjectLayers)
{
	auto joltBroadPhaseLayerInterface = reinterpret_cast<JPH::BroadPhaseLayerInterface*>(broadPhaseLayerInterface);
	auto joltObjectLayerPairFilter = reinterpret_cast<JPH::ObjectLayerPairFilter*>(objectLayerPairFilter);

	auto filter = new JPH::ObjectVsBroadPhaseLayerFilterTable(*joltBroadPhaseLayerInterface, numBroadPhaseLayers, *joltObjectLayerPairFilter, numObjectLayers);
	return reinterpret_cast<JPH_ObjectVsBroadPhaseLayerFilter*>(filter);
}

void JPH_DrawSettings_InitDefault(JPH_DrawSettings* settings)
{
	JPH_ASSERT(settings);

	settings->drawGetSupportFunction = false;
	settings->drawSupportDirection = false;
	settings->drawGetSupportingFace = false;
	settings->drawShape = true;
	settings->drawShapeWireframe = false;
	settings->drawShapeColor = JPH_BodyManager_ShapeColor_MotionTypeColor;
	settings->drawBoundingBox = false;
	settings->drawCenterOfMassTransform = false;
	settings->drawWorldTransform = false;
	settings->drawVelocity = false;
	settings->drawMassAndInertia = false;
	settings->drawSleepStats = false;
	settings->drawSoftBodyVertices = false;
	settings->drawSoftBodyVertexVelocities = false;
	settings->drawSoftBodyEdgeConstraints = false;
	settings->drawSoftBodyBendConstraints = false;
	settings->drawSoftBodyVolumeConstraints = false;
	settings->drawSoftBodySkinConstraints = false;
	settings->drawSoftBodyLRAConstraints = false;
	settings->drawSoftBodyPredictedBounds = false;
	settings->drawSoftBodyConstraintColor = JPH_SoftBodyConstraintColor_ConstraintType;
}

/* JPH_PhysicsSystem */
struct JPH_PhysicsSystem final
{
	JPH::BroadPhaseLayerInterface* broadPhaseLayerInterface = nullptr;
	JPH::ObjectLayerPairFilter* objectLayerPairFilter = nullptr;
	JPH::ObjectVsBroadPhaseLayerFilter* objectVsBroadPhaseLayerFilter = nullptr;
	JPH::PhysicsSystem* physicsSystem = nullptr;
};
static JPH::UnorderedMap<JPH::PhysicsSystem*, JPH_PhysicsSystem*> s_PhysicsSystems;

JPH_PhysicsSystem* JPH_PhysicsSystem_Create(const JPH_PhysicsSystemSettings* settings)
{
	if (!settings)
		return nullptr;

	JPH_PhysicsSystem* system = new JPH_PhysicsSystem();
	system->broadPhaseLayerInterface = reinterpret_cast<JPH::BroadPhaseLayerInterface*>(settings->broadPhaseLayerInterface);
	system->objectLayerPairFilter = reinterpret_cast<JPH::ObjectLayerPairFilter*>(settings->objectLayerPairFilter);
	system->objectVsBroadPhaseLayerFilter = reinterpret_cast<JPH::ObjectVsBroadPhaseLayerFilter*>(settings->objectVsBroadPhaseLayerFilter);

	// Init the physics system
	const uint maxBodies = settings->maxBodies ? settings->maxBodies : 10240;
	const uint cNumBodyMutexes = settings->numBodyMutexes;
	const uint maxBodyPairs = settings->maxBodyPairs ? settings->maxBodyPairs : 65536;
	const uint maxContactConstraints = settings->maxContactConstraints ? settings->maxContactConstraints : 10240;
	system->physicsSystem = new JPH::PhysicsSystem();
	system->physicsSystem->Init(maxBodies, cNumBodyMutexes, maxBodyPairs, maxContactConstraints,
		*system->broadPhaseLayerInterface,
		*system->objectVsBroadPhaseLayerFilter,
		*system->objectLayerPairFilter);

	s_PhysicsSystems[system->physicsSystem] = system;
	return system;
}

void JPH_PhysicsSystem_Destroy(JPH_PhysicsSystem* system)
{
	if (system)
	{
		s_PhysicsSystems.erase(system->physicsSystem);
		delete system->physicsSystem;
		delete system->broadPhaseLayerInterface;
		delete system->objectVsBroadPhaseLayerFilter;
		delete system->objectLayerPairFilter;

		delete system;
	}
}

void JPH_PhysicsSystem_SetPhysicsSettings(JPH_PhysicsSystem* system, JPH_PhysicsSettings* settings)
{
	JPH::PhysicsSettings joltSettings;
	joltSettings.mMaxInFlightBodyPairs = settings->maxInFlightBodyPairs;
	joltSettings.mStepListenersBatchSize = settings->stepListenersBatchSize;
	joltSettings.mStepListenerBatchesPerJob = settings->stepListenerBatchesPerJob;
	joltSettings.mBaumgarte = settings->baumgarte;
	joltSettings.mSpeculativeContactDistance = settings->speculativeContactDistance;
	joltSettings.mPenetrationSlop = settings->penetrationSlop;
	joltSettings.mLinearCastThreshold = settings->linearCastThreshold;
	joltSettings.mLinearCastMaxPenetration = settings->linearCastMaxPenetration;
	joltSettings.mManifoldTolerance = settings->manifoldTolerance;
	joltSettings.mMaxPenetrationDistance = settings->maxPenetrationDistance;
	joltSettings.mBodyPairCacheMaxDeltaPositionSq = settings->bodyPairCacheMaxDeltaPositionSq;
	joltSettings.mBodyPairCacheCosMaxDeltaRotationDiv2 = settings->bodyPairCacheCosMaxDeltaRotationDiv2;
	joltSettings.mContactNormalCosMaxDeltaRotation = settings->contactNormalCosMaxDeltaRotation;
	joltSettings.mContactPointPreserveLambdaMaxDistSq = settings->contactPointPreserveLambdaMaxDistSq;
	joltSettings.mNumVelocitySteps = settings->numVelocitySteps;
	joltSettings.mNumPositionSteps = settings->numPositionSteps;
	joltSettings.mMinVelocityForRestitution = settings->minVelocityForRestitution;
	joltSettings.mTimeBeforeSleep = settings->timeBeforeSleep;
	joltSettings.mPointVelocitySleepThreshold = settings->pointVelocitySleepThreshold;
	joltSettings.mDeterministicSimulation = settings->deterministicSimulation;
	joltSettings.mConstraintWarmStart = settings->constraintWarmStart;
	joltSettings.mUseBodyPairContactCache = settings->useBodyPairContactCache;
	joltSettings.mUseManifoldReduction = settings->useManifoldReduction;
	joltSettings.mUseLargeIslandSplitter = settings->useLargeIslandSplitter;
	joltSettings.mAllowSleeping = settings->allowSleeping;
	joltSettings.mCheckActiveEdges = settings->checkActiveEdges;
	system->physicsSystem->SetPhysicsSettings(joltSettings);
}

void JPH_PhysicsSystem_GetPhysicsSettings(JPH_PhysicsSystem* system, JPH_PhysicsSettings* result)
{
	auto joltSettings = system->physicsSystem->GetPhysicsSettings();
	result->maxInFlightBodyPairs = joltSettings.mMaxInFlightBodyPairs;
	result->stepListenersBatchSize = joltSettings.mStepListenersBatchSize;
	result->stepListenerBatchesPerJob = joltSettings.mStepListenerBatchesPerJob;
	result->baumgarte = joltSettings.mBaumgarte;
	result->speculativeContactDistance = joltSettings.mSpeculativeContactDistance;
	result->penetrationSlop = joltSettings.mPenetrationSlop;
	result->linearCastThreshold = joltSettings.mLinearCastThreshold;
	result->linearCastMaxPenetration = joltSettings.mLinearCastMaxPenetration;
	result->manifoldTolerance = joltSettings.mManifoldTolerance;
	result->maxPenetrationDistance = joltSettings.mMaxPenetrationDistance;
	result->bodyPairCacheMaxDeltaPositionSq = joltSettings.mBodyPairCacheMaxDeltaPositionSq;
	result->bodyPairCacheCosMaxDeltaRotationDiv2 = joltSettings.mBodyPairCacheCosMaxDeltaRotationDiv2;
	result->contactNormalCosMaxDeltaRotation = joltSettings.mContactNormalCosMaxDeltaRotation;
	result->contactPointPreserveLambdaMaxDistSq = joltSettings.mContactPointPreserveLambdaMaxDistSq;
	result->numVelocitySteps = joltSettings.mNumVelocitySteps;
	result->numPositionSteps = joltSettings.mNumPositionSteps;
	result->minVelocityForRestitution = joltSettings.mMinVelocityForRestitution;
	result->timeBeforeSleep = joltSettings.mTimeBeforeSleep;
	result->pointVelocitySleepThreshold = joltSettings.mPointVelocitySleepThreshold;
	result->deterministicSimulation = joltSettings.mDeterministicSimulation;
	result->constraintWarmStart = joltSettings.mConstraintWarmStart;
	result->useBodyPairContactCache = joltSettings.mUseBodyPairContactCache;
	result->useManifoldReduction = joltSettings.mUseManifoldReduction;
	result->useLargeIslandSplitter = joltSettings.mUseLargeIslandSplitter;
	result->allowSleeping = joltSettings.mAllowSleeping;
	result->checkActiveEdges = joltSettings.mCheckActiveEdges;
}

void JPH_PhysicsSystem_OptimizeBroadPhase(JPH_PhysicsSystem* system)
{
	JPH_ASSERT(system);

	system->physicsSystem->OptimizeBroadPhase();
}

JPH_PhysicsUpdateError JPH_PhysicsSystem_Update(JPH_PhysicsSystem* system, float deltaTime, int collisionSteps, JPH_JobSystem* jobSystem)
{
	JPH::JobSystem* joltJobSystem = reinterpret_cast<JPH::JobSystem*>(jobSystem);
	return static_cast<JPH_PhysicsUpdateError>(system->physicsSystem->Update(deltaTime, collisionSteps, s_TempAllocator, joltJobSystem));
}

JPH_BodyInterface* JPH_PhysicsSystem_GetBodyInterface(JPH_PhysicsSystem* system)
{
	return reinterpret_cast<JPH_BodyInterface*>(&system->physicsSystem->GetBodyInterface());
}

JPH_BodyInterface* JPH_PhysicsSystem_GetBodyInterfaceNoLock(JPH_PhysicsSystem* system)
{
	return reinterpret_cast<JPH_BodyInterface*>(&system->physicsSystem->GetBodyInterfaceNoLock());
}

const JPH_BodyLockInterface* JPH_PhysicsSystem_GetBodyLockInterface(const JPH_PhysicsSystem* system)
{
	return reinterpret_cast<const JPH_BodyLockInterface*>(&system->physicsSystem->GetBodyLockInterface());
}
const JPH_BodyLockInterface* JPH_PhysicsSystem_GetBodyLockInterfaceNoLock(const JPH_PhysicsSystem* system)
{
	return reinterpret_cast<const JPH_BodyLockInterface*>(&system->physicsSystem->GetBodyLockInterfaceNoLock());
}

/* JPH_BroadPhaseLayerFilter */
static const JPH::BroadPhaseLayerFilter& ToJolt(const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter)
{
	static const JPH::BroadPhaseLayerFilter g_defaultBroadPhaseLayerFilter = {};
	return broadPhaseLayerFilter ? *reinterpret_cast<const JPH::BroadPhaseLayerFilter*>(broadPhaseLayerFilter) : g_defaultBroadPhaseLayerFilter;
}

class ManagedBroadPhaseLayerFilter final : public JPH::BroadPhaseLayerFilter
{
public:
	static const JPH_BroadPhaseLayerFilter_Procs* s_Procs;
	void* userData = nullptr;

	ManagedBroadPhaseLayerFilter(void* userData_)
		: userData(userData_)
	{

	}

	bool ShouldCollide(BroadPhaseLayer inLayer) const override
	{
		if (s_Procs != nullptr
			&& s_Procs->ShouldCollide)
		{
			return s_Procs->ShouldCollide(userData, static_cast<JPH_BroadPhaseLayer>(inLayer));
		}

		return true;
	}
};

const JPH_BroadPhaseLayerFilter_Procs* ManagedBroadPhaseLayerFilter::s_Procs = nullptr;

void JPH_BroadPhaseLayerFilter_SetProcs(const JPH_BroadPhaseLayerFilter_Procs* procs)
{
	ManagedBroadPhaseLayerFilter::s_Procs = procs;
}

JPH_BroadPhaseLayerFilter* JPH_BroadPhaseLayerFilter_Create(void* userData)
{
	auto filter = new ManagedBroadPhaseLayerFilter(userData);
	return reinterpret_cast<JPH_BroadPhaseLayerFilter*>(filter);
}

void JPH_BroadPhaseLayerFilter_Destroy(JPH_BroadPhaseLayerFilter* filter)
{
	if (filter)
	{
		delete reinterpret_cast<ManagedBroadPhaseLayerFilter*>(filter);
	}
}

/* JPH_ObjectLayerFilter */
static const JPH::ObjectLayerFilter& ToJolt(const JPH_ObjectLayerFilter* objectLayerFilter)
{
	static const JPH::ObjectLayerFilter g_defaultObjectLayerFilter = {};
	return objectLayerFilter ? *reinterpret_cast<const JPH::ObjectLayerFilter*>(objectLayerFilter) : g_defaultObjectLayerFilter;
}

class ManagedObjectLayerFilter final : public JPH::ObjectLayerFilter
{
public:
	static const JPH_ObjectLayerFilter_Procs* s_Procs;
	void* userData = nullptr;

	ManagedObjectLayerFilter(void* userData_)
		: userData(userData_)
	{

	}

	bool ShouldCollide(ObjectLayer inLayer) const override
	{
		if (s_Procs != nullptr
			&& s_Procs->ShouldCollide)
		{
			return s_Procs->ShouldCollide(userData, static_cast<JPH_ObjectLayer>(inLayer));
		}

		return true;
	}
};

const JPH_ObjectLayerFilter_Procs* ManagedObjectLayerFilter::s_Procs = nullptr;

void JPH_ObjectLayerFilter_SetProcs(const JPH_ObjectLayerFilter_Procs* procs)
{
	ManagedObjectLayerFilter::s_Procs = procs;
}

JPH_ObjectLayerFilter* JPH_ObjectLayerFilter_Create(void* userData)
{
	auto filter = new ManagedObjectLayerFilter(userData);
	return reinterpret_cast<JPH_ObjectLayerFilter*>(filter);
}

void JPH_ObjectLayerFilter_Destroy(JPH_ObjectLayerFilter* filter)
{
	if (filter)
	{
		delete reinterpret_cast<ManagedObjectLayerFilter*>(filter);
	}
}

/* JPH_BodyFilter */
static const JPH::BodyFilter& ToJolt(const JPH_BodyFilter* bodyFilter)
{
	static const JPH::BodyFilter g_defaultBodyFilter = {};
	return bodyFilter ? *reinterpret_cast<const JPH::BodyFilter*>(bodyFilter) : g_defaultBodyFilter;
}

class ManagedBodyFilter final : public JPH::BodyFilter
{
public:
	static const JPH_BodyFilter_Procs* s_Procs;
	void* userData = nullptr;

	ManagedBodyFilter(void* userData_)
		: userData(userData_)
	{

	}

	bool ShouldCollide(const BodyID& bodyID) const override
	{
		if (s_Procs != nullptr
			&& s_Procs->ShouldCollide)
		{
			return s_Procs->ShouldCollide(userData, (JPH_BodyID)bodyID.GetIndexAndSequenceNumber());
		}

		return true;
	}

	bool ShouldCollideLocked(const Body& body) const override
	{
		if (s_Procs != nullptr
			&& s_Procs->ShouldCollideLocked)
		{
			return s_Procs->ShouldCollideLocked(userData, reinterpret_cast<const JPH_Body*>(&body));
		}

		return true;
	}
};

const JPH_BodyFilter_Procs* ManagedBodyFilter::s_Procs = nullptr;

void JPH_BodyFilter_SetProcs(const JPH_BodyFilter_Procs* procs)
{
	ManagedBodyFilter::s_Procs = procs;
}

JPH_BodyFilter* JPH_BodyFilter_Create(void* userData)
{
	auto filter = new ManagedBodyFilter(userData);
	return reinterpret_cast<JPH_BodyFilter*>(filter);
}

void JPH_BodyFilter_Destroy(JPH_BodyFilter* filter)
{
	if (filter)
	{
		delete reinterpret_cast<ManagedBodyFilter*>(filter);
	}
}

/* JPH_ShapeFilter */
static const JPH::ShapeFilter& ToJolt(const JPH_ShapeFilter* filter)
{
	static const JPH::ShapeFilter g_defaultBodyFilter = {};
	return filter ? *reinterpret_cast<const JPH::ShapeFilter*>(filter) : g_defaultBodyFilter;
}

class ManagedShapeFilter final : public JPH::ShapeFilter
{
public:
	static const JPH_ShapeFilter_Procs* s_Procs;
	void* userData = nullptr;

	ManagedShapeFilter(void* userData_)
		: userData(userData_)
	{

	}

	bool ShouldCollide([[maybe_unused]] const Shape* inShape2, [[maybe_unused]] const SubShapeID& inSubShapeIDOfShape2) const override
	{
		if (s_Procs != nullptr && s_Procs->ShouldCollide)
		{
			auto subShapeIDOfShape2 = inSubShapeIDOfShape2.GetValue();
			return s_Procs->ShouldCollide(userData, ToShape(inShape2), &subShapeIDOfShape2);
		}

		return true;
	}

	bool ShouldCollide(
		[[maybe_unused]] const Shape* inShape1,
		[[maybe_unused]] const SubShapeID& inSubShapeIDOfShape1,
		[[maybe_unused]] const Shape* inShape2,
		[[maybe_unused]] const SubShapeID& inSubShapeIDOfShape2) const override
	{
		if (s_Procs != nullptr && s_Procs->ShouldCollide2)
		{
			auto subShapeIDOfShape1 = inSubShapeIDOfShape1.GetValue();
			auto subShapeIDOfShape2 = inSubShapeIDOfShape2.GetValue();

			return s_Procs->ShouldCollide2(userData, ToShape(inShape1), &subShapeIDOfShape1, ToShape(inShape2), &subShapeIDOfShape2);
		}

		return true;
	}
};

const JPH_ShapeFilter_Procs* ManagedShapeFilter::s_Procs = nullptr;

void JPH_ShapeFilter_SetProcs(const JPH_ShapeFilter_Procs* procs)
{
	ManagedShapeFilter::s_Procs = procs;
}

JPH_ShapeFilter* JPH_ShapeFilter_Create(void* userData)
{
	auto filter = new ManagedShapeFilter(userData);
	return reinterpret_cast<JPH_ShapeFilter*>(filter);
}

void JPH_ShapeFilter_Destroy(JPH_ShapeFilter* filter)
{
	if (filter)
	{
		delete reinterpret_cast<ManagedShapeFilter*>(filter);
	}
}

JPH_BodyID JPH_ShapeFilter_GetBodyID2(JPH_ShapeFilter* filter)
{
	return reinterpret_cast<ManagedShapeFilter*>(filter)->mBodyID2.GetIndexAndSequenceNumber();
}

void JPH_ShapeFilter_SetBodyID2(JPH_ShapeFilter* filter, JPH_BodyID id)
{
	reinterpret_cast<ManagedShapeFilter*>(filter)->mBodyID2 = JPH::BodyID(id);
}

/* JPH_SimShapeFilter */
class ManagedSimShapeFilter final : public JPH::SimShapeFilter
{
public:
	static const JPH_SimShapeFilter_Procs* s_Procs;
	void* userData = nullptr;

	ManagedSimShapeFilter(void* userData_)
		: userData(userData_)
	{

	}

	bool ShouldCollide(
		[[maybe_unused]] const Body& inBody1,
		[[maybe_unused]] const Shape* inShape1,
		[[maybe_unused]] const SubShapeID& inSubShapeIDOfShape1,
		[[maybe_unused]] const Body& inBody2,
		[[maybe_unused]] const Shape* inShape2,
		[[maybe_unused]] const SubShapeID& inSubShapeIDOfShape2) const override
	{
		if (s_Procs != nullptr && s_Procs->ShouldCollide)
		{

			auto subShapeIDOfShape1 = inSubShapeIDOfShape1.GetValue();
			auto subShapeIDOfShape2 = inSubShapeIDOfShape2.GetValue();
			return s_Procs->ShouldCollide(userData,
				reinterpret_cast<const JPH_Body*>(&inBody1), ToShape(inShape1), &subShapeIDOfShape1,
				reinterpret_cast<const JPH_Body*>(&inBody2), ToShape(inShape2), &subShapeIDOfShape2);
		}

		return true;
	}
};

const JPH_SimShapeFilter_Procs* ManagedSimShapeFilter::s_Procs = nullptr;

void JPH_SimShapeFilter_SetProcs(const JPH_SimShapeFilter_Procs* procs)
{
	ManagedSimShapeFilter::s_Procs = procs;
}

JPH_SimShapeFilter* JPH_SimShapeFilter_Create(void* userData)
{
	auto filter = new ManagedSimShapeFilter(userData);
	return reinterpret_cast<JPH_SimShapeFilter*>(filter);
}

void JPH_SimShapeFilter_Destroy(JPH_SimShapeFilter* filter)
{
	if (filter)
	{
		delete reinterpret_cast<ManagedSimShapeFilter*>(filter);
	}
}

/* Math */
float JPH_Math_Sin(float value)
{
	return JPH::Sin(value);
}

float JPH_Math_Cos(float value)
{
	return JPH::Cos(value);
}

void JPH_Quat_FromTo(const JPH_Vec3* from, const JPH_Vec3* to, JPH_Quat* quat)
{
	FromJolt(JPH::Quat::sFromTo(ToJolt(from), ToJolt(to)), quat);
}

void JPH_Quat_GetAxisAngle(const JPH_Quat* quat, JPH_Vec3* outAxis, float* outAngle)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(outAxis);
	JPH_ASSERT(outAngle);

	JPH::Vec3 joltAxis;
	float angle;
	JPH::Quat joltQuat = ToJolt(quat);
	joltQuat.GetAxisAngle(joltAxis, angle);
	FromJolt(joltAxis, outAxis);
	*outAngle = angle;
}

void JPH_Quat_GetEulerAngles(const JPH_Quat* quat, JPH_Vec3* result)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(result);

	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.GetEulerAngles(), result);
}

void JPH_Quat_RotateAxisX(const JPH_Quat* quat, JPH_Vec3* result)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(result);

	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.RotateAxisX(), result);
}

void JPH_Quat_RotateAxisY(const JPH_Quat* quat, JPH_Vec3* result)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(result);

	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.RotateAxisY(), result);
}

void JPH_Quat_RotateAxisZ(const JPH_Quat* quat, JPH_Vec3* result)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(result);

	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.RotateAxisZ(), result);
}

void JPH_Quat_Inversed(const JPH_Quat* quat, JPH_Quat* result)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(result);

	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.Inversed(), result);
}

void JPH_Quat_GetPerpendicular(const JPH_Quat* quat, JPH_Quat* result)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(result);

	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.GetPerpendicular(), result);
}

float JPH_Quat_GetRotationAngle(const JPH_Quat* quat, const JPH_Vec3* axis)
{
	JPH_ASSERT(quat);
	JPH_ASSERT(axis);

	auto joltQuat = ToJolt(quat);
	return joltQuat.GetRotationAngle(ToJolt(axis));
}

void JPH_Quat_Multiply(const JPH_Quat* q1, const JPH_Quat* q2, JPH_Quat* result)
{
	JPH_ASSERT(q1 && q2 && result);
	auto joltQ1 = ToJolt(q1);
	auto joltQ2 = ToJolt(q2);
	FromJolt(joltQ1 * joltQ2, result);
}

void JPH_Quat_MultiplyScalar(const JPH_Quat* q, float scalar, JPH_Quat* result)
{
	JPH_ASSERT(q && result);
	auto joltQ = ToJolt(q);
	FromJolt(joltQ * scalar, result);
}

void JPH_Quat_Add(const JPH_Quat* q1, const JPH_Quat* q2, JPH_Quat* result)
{
	JPH_ASSERT(q1 && q2 && result);
	auto joltQ1 = ToJolt(q1);
	auto joltQ2 = ToJolt(q2);
	FromJolt(joltQ1 + joltQ2, result);
}

void JPH_Quat_Subtract(const JPH_Quat* q1, const JPH_Quat* q2, JPH_Quat* result)
{
	JPH_ASSERT(q1 && q2 && result);
	auto joltQ1 = ToJolt(q1);
	auto joltQ2 = ToJolt(q2);
	FromJolt(joltQ1 - joltQ2, result);
}

void JPH_Quat_DivideScalar(const JPH_Quat* q, float scalar, JPH_Quat* result)
{
	JPH_ASSERT(q && result);
	JPH_ASSERT(scalar != 0.0f);
	auto joltQ = ToJolt(q);
	FromJolt(joltQ / scalar, result);
}

void JPH_Quat_Dot(const JPH_Quat* q1, const JPH_Quat* q2, float* result)
{
	JPH_ASSERT(q1 && q2 && result);
	auto joltQ1 = ToJolt(q1);
	auto joltQ2 = ToJolt(q2);
	*result = joltQ1.Dot(joltQ2);
}

void JPH_Quat_Conjugated(const JPH_Quat* quat, JPH_Quat* result)
{
	JPH_ASSERT(quat && result);
	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.Conjugated(), result);
}

void JPH_Quat_GetTwist(const JPH_Quat* quat, const JPH_Vec3* axis, JPH_Quat* result)
{
	JPH_ASSERT(quat && axis && result);
	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.GetTwist(ToJolt(axis)), result);
}

void JPH_Quat_GetSwingTwist(const JPH_Quat* quat, JPH_Quat* outSwing, JPH_Quat* outTwist)
{
	JPH_ASSERT(quat && outSwing && outTwist);
	auto joltQuat = ToJolt(quat);
	JPH::Quat swing, twist;
	joltQuat.GetSwingTwist(swing, twist);
	FromJolt(swing, outSwing);
	FromJolt(twist, outTwist);
}

void JPH_Quat_Lerp(const JPH_Quat* from, const JPH_Quat* to, float fraction, JPH_Quat* result)
{
	JPH_ASSERT(from && to && result);
	auto joltFrom = ToJolt(from);
	auto joltTo = ToJolt(to);
	FromJolt(joltFrom.LERP(joltTo, fraction), result);
}

void JPH_Quat_Slerp(const JPH_Quat* from, const JPH_Quat* to, float fraction, JPH_Quat* result)
{
	JPH_ASSERT(from && to && result);
	auto joltFrom = ToJolt(from);
	auto joltTo = ToJolt(to);
	FromJolt(joltFrom.SLERP(joltTo, fraction), result);
}

void JPH_Quat_Rotate(const JPH_Quat* quat, const JPH_Vec3* vec, JPH_Vec3* result)
{
	JPH_ASSERT(quat && vec && result);
	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat * ToJolt(vec), result);
}

void JPH_Quat_InverseRotate(const JPH_Quat* quat, const JPH_Vec3* vec, JPH_Vec3* result)
{
	JPH_ASSERT(quat && vec && result);
	auto joltQuat = ToJolt(quat);
	FromJolt(joltQuat.InverseRotate(ToJolt(vec)), result);
}

void JPH_Quat_FromEulerAngles(const JPH_Vec3* angles, JPH_Quat* result)
{
	JPH_ASSERT(angles && result);
	FromJolt(JPH::Quat::sEulerAngles(ToJolt(angles)), result);
}

void JPH_Vec3_AxisX(JPH_Vec3* result)
{
	FromJolt(JPH::Vec3::sAxisX(), result);
}

void JPH_Vec3_AxisY(JPH_Vec3* result)
{
	FromJolt(JPH::Vec3::sAxisY(), result);
}

void JPH_Vec3_AxisZ(JPH_Vec3* result)
{
	FromJolt(JPH::Vec3::sAxisZ(), result);
}

bool JPH_Vec3_IsClose(const JPH_Vec3* v1, const JPH_Vec3* v2, float maxDistSq)
{
	JPH_ASSERT(v1 != nullptr);
	JPH_ASSERT(v2 != nullptr);

	JPH::Vec3 joltV1 = ToJolt(v1);
	JPH::Vec3 joltV2 = ToJolt(v2);

	return joltV1.IsClose(joltV2, maxDistSq);
}

bool JPH_Vec3_IsNearZero(const JPH_Vec3* v, float maxDistSq)
{
	JPH_ASSERT(v != nullptr);

	JPH::Vec3 joltV = ToJolt(v);
	return joltV.IsNearZero(maxDistSq);
}

bool JPH_Vec3_IsNormalized(const JPH_Vec3* v, float tolerance)
{
	JPH_ASSERT(v != nullptr);

	JPH::Vec3 joltV = ToJolt(v);
	return joltV.IsNormalized(tolerance);
}

bool JPH_Vec3_IsNaN(const JPH_Vec3* v)
{
	JPH_ASSERT(v != nullptr);

	JPH::Vec3 joltV = ToJolt(v);
	return joltV.IsNaN();
}

void JPH_Vec3_Negate(const JPH_Vec3* v, JPH_Vec3* result)
{
	JPH_ASSERT(v != nullptr);
	JPH_ASSERT(result != nullptr);

	JPH::Vec3 joltV = ToJolt(v);
	FromJolt(-joltV, result);
}

void JPH_Vec3_Normalized(const JPH_Vec3* v, JPH_Vec3* result)
{
	JPH_ASSERT(v != nullptr);
	JPH_ASSERT(result != nullptr);

	JPH::Vec3 joltV = ToJolt(v);
	FromJolt(joltV.Normalized(), result);
}

void JPH_Vec3_Cross(const JPH_Vec3* v1, const JPH_Vec3* v2, JPH_Vec3* result)
{
	JPH_ASSERT(v1 != nullptr);
	JPH_ASSERT(v2 != nullptr);
	JPH_ASSERT(result != nullptr);

	JPH::Vec3 joltV1 = ToJolt(v1);
	JPH::Vec3 joltV2 = ToJolt(v2);
	FromJolt(joltV1.Cross(joltV2), result);
}

void JPH_Vec3_Abs(const JPH_Vec3* v, JPH_Vec3* result)
{
	JPH_ASSERT(v != nullptr);
	JPH_ASSERT(result != nullptr);

	JPH::Vec3 joltV = ToJolt(v);
	FromJolt(joltV.Abs(), result);
}

float JPH_Vec3_Length(const JPH_Vec3* v)
{
	JPH_ASSERT(v);
	JPH::Vec3 joltVec = ToJolt(v);
	return joltVec.Length();
}

float JPH_Vec3_LengthSquared(const JPH_Vec3* v)
{
	JPH_ASSERT(v);
	JPH::Vec3 joltVec = ToJolt(v);
	return joltVec.LengthSq();
}

void JPH_Vec3_Multiply(const JPH_Vec3* v1, const JPH_Vec3* v2, JPH_Vec3* result)
{
	JPH_ASSERT(v1 && v2 && result);
	JPH::Vec3 joltVec1 = ToJolt(v1);
	JPH::Vec3 joltVec2 = ToJolt(v2);
	FromJolt(joltVec1 * joltVec2, result);
}

void JPH_Vec3_MultiplyScalar(const JPH_Vec3* v, float scalar, JPH_Vec3* result)
{
	JPH_ASSERT(v && result);
	JPH::Vec3 joltVec = ToJolt(v);
	FromJolt(joltVec * scalar, result);
}

void JPH_Vec3_MultiplyMatrix(const JPH_Mat4* left, const JPH_Vec3* right, JPH_Vec3* result)
{
	FromJolt(ToJolt(left) * ToJolt(right), result);
}

void JPH_Vec3_Divide(const JPH_Vec3* v1, const JPH_Vec3* v2, JPH_Vec3* result)
{
	JPH_ASSERT(v1 && v2 && result);
	JPH::Vec3 joltVec1 = ToJolt(v1);
	JPH::Vec3 joltVec2 = ToJolt(v2);
	FromJolt(joltVec1 / joltVec2, result);
}

void JPH_Vec3_DivideScalar(const JPH_Vec3* v, float scalar, JPH_Vec3* result)
{
	JPH_ASSERT(v && result);
	JPH_ASSERT(scalar != 0.0f);
	JPH::Vec3 joltVec = ToJolt(v);
	FromJolt(joltVec / scalar, result);
}

void JPH_Vec3_GetNormalizedPerpendicular(const JPH_Vec3* v, JPH_Vec3* result)
{
	JPH_ASSERT(v && result);
	JPH::Vec3 joltVec = ToJolt(v);
	FromJolt(joltVec.GetNormalizedPerpendicular(), result);
}

void JPH_Vec3_DotProduct(const JPH_Vec3* v1, const JPH_Vec3* v2, float* result)
{
	JPH_ASSERT(v1 && v2 && result);
	JPH::Vec3 joltVec1 = ToJolt(v1);
	JPH::Vec3 joltVec2 = ToJolt(v2);
	*result = joltVec1.Dot(joltVec2);
}

void JPH_Vec3_Normalize(const JPH_Vec3* v, JPH_Vec3* result)
{
	JPH_ASSERT(v && result);
	JPH::Vec3 joltVec = ToJolt(v);
	FromJolt(joltVec.Normalized(), result);
}

void JPH_Vec3_Add(const JPH_Vec3* v1, const JPH_Vec3* v2, JPH_Vec3* result)
{
	JPH_ASSERT(v1 && v2 && result);
	JPH::Vec3 joltVec1 = ToJolt(v1);
	JPH::Vec3 joltVec2 = ToJolt(v2);
	FromJolt(joltVec1 + joltVec2, result);
}

void JPH_Vec3_Subtract(const JPH_Vec3* v1, const JPH_Vec3* v2, JPH_Vec3* result)
{
	JPH_ASSERT(v1 && v2 && result);
	JPH::Vec3 joltVec1 = ToJolt(v1);
	JPH::Vec3 joltVec2 = ToJolt(v2);
	FromJolt(joltVec1 - joltVec2, result);
}

void JPH_Mat4_Add(const JPH_Mat4* m1, const JPH_Mat4* m2, JPH_Mat4* result)
{
	JPH_ASSERT(m1 && m2 && result);
	auto joltM1 = ToJolt(m1);
	auto joltM2 = ToJolt(m2);
	FromJolt(joltM1 + joltM2, result);
}

void JPH_Mat4_Subtract(const JPH_Mat4* m1, const JPH_Mat4* m2, JPH_Mat4* result)
{
	JPH_ASSERT(m1 && m2 && result);
	auto joltM1 = ToJolt(m1);
	auto joltM2 = ToJolt(m2);
	FromJolt(joltM1 - joltM2, result);
}

void JPH_Mat4_Multiply(const JPH_Mat4* m1, const JPH_Mat4* m2, JPH_Mat4* result)
{
	JPH_ASSERT(m1 && m2 && result);
	auto joltM1 = ToJolt(m1);
	auto joltM2 = ToJolt(m2);
	FromJolt(joltM1 * joltM2, result);
}

void JPH_Mat4_MultiplyScalar(const JPH_Mat4* m, float scalar, JPH_Mat4* result)
{
	JPH_ASSERT(m && result);
	auto joltM = ToJolt(m);
	FromJolt(joltM * scalar, result);
}

void JPH_Mat4_Zero(JPH_Mat4* result)
{
	const JPH::Mat44 mat = JPH::Mat44::sZero();
	FromJolt(mat, result);
}

void JPH_Mat4_Identity(JPH_Mat4* result)
{
	const JPH::Mat44 mat = JPH::Mat44::sIdentity();
	FromJolt(mat, result);
}

void JPH_Mat4_Rotation(JPH_Mat4* result, const JPH_Quat* rotation)
{
	const JPH::Mat44 mat = JPH::Mat44::sRotation(ToJolt(rotation));
	FromJolt(mat, result);
}

void JPH_Mat4_Rotation2(JPH_Mat4* result, const JPH_Vec3* axis, float angle)
{
	FromJolt(JPH::Mat44::sRotation(ToJolt(axis), angle), result);
}

void JPH_Mat4_Translation(JPH_Mat4* result, const JPH_Vec3* translation)
{
	const JPH::Mat44 mat = JPH::Mat44::sTranslation(ToJolt(translation));
	FromJolt(mat, result);
}

void JPH_Mat4_RotationTranslation(JPH_Mat4* result, const JPH_Quat* rotation, const JPH_Vec3* translation)
{
	const JPH::Mat44 mat = JPH::Mat44::sRotationTranslation(ToJolt(rotation), ToJolt(translation));
	FromJolt(mat, result);
}

void JPH_Mat4_InverseRotationTranslation(JPH_Mat4* result, const JPH_Quat* rotation, const JPH_Vec3* translation)
{
	const JPH::Mat44 mat = JPH::Mat44::sInverseRotationTranslation(ToJolt(rotation), ToJolt(translation));
	FromJolt(mat, result);
}

void JPH_Mat4_Scale(JPH_Mat4* result, const JPH_Vec3* scale)
{
	const JPH::Mat44 mat = JPH::Mat44::sScale(ToJolt(scale));
	FromJolt(mat, result);
}

void JPH_Mat4_Transposed(const JPH_Mat4* matrix, JPH_Mat4* result)
{
	FromJolt(ToJolt(matrix).Transposed(), result);
}

void JPH_Mat4_Inversed(const JPH_Mat4* matrix, JPH_Mat4* result)
{
	FromJolt(ToJolt(matrix).Inversed(), result);
}

void JPH_Mat4_GetAxisX(const JPH_Mat4* matrix, JPH_Vec3* result)
{
	FromJolt(ToJolt(matrix).GetAxisX(), result);
}

void JPH_Mat4_GetAxisY(const JPH_Mat4* matrix, JPH_Vec3* result)
{
	FromJolt(ToJolt(matrix).GetAxisY(), result);
}

void JPH_Mat4_GetAxisZ(const JPH_Mat4* matrix, JPH_Vec3* result)
{
	FromJolt(ToJolt(matrix).GetAxisZ(), result);
}

void JPH_Mat4_GetTranslation(const JPH_Mat4* matrix, JPH_Vec3* result)
{
	FromJolt(ToJolt(matrix).GetTranslation(), result);
}

void JPH_Mat4_GetQuaternion(const JPH_Mat4* matrix, JPH_Quat* result)
{
	FromJolt(ToJolt(matrix).GetQuaternion(), result);
}

#if defined(JPH_DOUBLE_PRECISION)
void JPH_RMat4_Zero(JPH_RMat4* result)
{
	const JPH::RMat44 mat = JPH::RMat44::sZero();
	FromJolt(mat, result);
}

void JPH_RMat4_Identity(JPH_RMat4* result)
{
	const JPH::RMat44 mat = JPH::RMat44::sIdentity();
	FromJolt(mat, result);
}

void JPH_RMat4_Rotation(JPH_RMat4* result, const JPH_Quat* rotation)
{
	const JPH::RMat44 mat = JPH::RMat44::sRotation(ToJolt(rotation));
	FromJolt(mat, result);
}

void JPH_RMat4_Translation(JPH_RMat4* result, const JPH_RVec3* translation)
{
	const JPH::RMat44 mat = JPH::RMat44::sTranslation(ToJolt(translation));
	FromJolt(mat, result);
}

void JPH_RMat4_RotationTranslation(JPH_RMat4* result, const JPH_Quat* rotation, const JPH_RVec3* translation)
{
	const JPH::RMat44 mat = JPH::RMat44::sRotationTranslation(ToJolt(rotation), ToJolt(translation));
	FromJolt(mat, result);
}

void JPH_RMat4_InverseRotationTranslation(JPH_RMat4* result, const JPH_Quat* rotation, const JPH_RVec3* translation)
{
	const JPH::RMat44 mat = JPH::RMat44::sInverseRotationTranslation(ToJolt(rotation), ToJolt(translation));
	FromJolt(mat, result);
}

void JPH_RMat4_Scale(JPH_RMat4* result, const JPH_Vec3* scale)
{
	const JPH::RMat44 mat = JPH::RMat44::sScale(ToJolt(scale));
	FromJolt(mat, result);
}

void JPH_RMat4_Inversed(const JPH_RMat4* m, JPH_RMat4* result)
{
	JPH_ASSERT(m && result);
	auto joltM = ToJolt(m);
	FromJolt(joltM.Inversed(), result);
}
#endif /* defined(JPH_DOUBLE_PRECISION) */

/* Material */
JPH_PhysicsMaterial* JPH_PhysicsMaterial_Create(const char* name, uint32_t color)
{
	auto material = new JPH::PhysicsMaterialSimple(name, JPH::Color(color));
	material->AddRef();

	return ToPhysicsMaterial(material);
}

void JPH_PhysicsMaterial_Destroy(JPH_PhysicsMaterial* material)
{
	if (material)
	{
		AsPhysicsMaterial(material)->Release();
	}
}

const char* JPH_PhysicsMaterial_GetDebugName(const JPH_PhysicsMaterial* material)
{
	return AsPhysicsMaterial(material)->GetDebugName();
}

uint32_t JPH_PhysicsMaterial_GetDebugColor(const JPH_PhysicsMaterial* material)
{
	return AsPhysicsMaterial(material)->GetDebugColor().GetUInt32();
}

/* GroupFilter/GroupFilterTable */
void JPH_GroupFilter_Destroy(JPH_GroupFilter* groupFilter)
{
	if (groupFilter)
	{
		AsGroupFilter(groupFilter)->Release();
	}
}

bool JPH_GroupFilter_CanCollide(JPH_GroupFilter* groupFilter, const JPH_CollisionGroup* group1, const JPH_CollisionGroup* group2)
{
	return AsGroupFilter(groupFilter)->CanCollide(ToJolt(group1), ToJolt(group2));
}

JPH_GroupFilterTable* JPH_GroupFilterTable_Create(uint32_t numSubGroups)
{
	auto material = new JPH::GroupFilterTable(numSubGroups);
	material->AddRef();

	return ToGroupFilterTable(material);
}

void JPH_GroupFilterTable_DisableCollision(JPH_GroupFilterTable* table, JPH_CollisionSubGroupID subGroup1, JPH_CollisionSubGroupID subGroup2)
{
	AsGroupFilterTable(table)->DisableCollision(
		static_cast<JPH::CollisionGroup::SubGroupID>(subGroup1),
		static_cast<JPH::CollisionGroup::SubGroupID>(subGroup2)
	);
}

void JPH_GroupFilterTable_EnableCollision(JPH_GroupFilterTable* table, JPH_CollisionSubGroupID subGroup1, JPH_CollisionSubGroupID subGroup2)
{
	AsGroupFilterTable(table)->EnableCollision(
		static_cast<JPH::CollisionGroup::SubGroupID>(subGroup1),
		static_cast<JPH::CollisionGroup::SubGroupID>(subGroup2)
	);
}

bool JPH_GroupFilterTable_IsCollisionEnabled(JPH_GroupFilterTable* table, JPH_CollisionSubGroupID subGroup1, JPH_CollisionSubGroupID subGroup2)
{
	return AsGroupFilterTable(table)->IsCollisionEnabled(
		static_cast<JPH::CollisionGroup::SubGroupID>(subGroup1),
		static_cast<JPH::CollisionGroup::SubGroupID>(subGroup2)
	);
}

/* ShapeSettings */
void JPH_ShapeSettings_Destroy(JPH_ShapeSettings* settings)
{
	if (settings)
	{
		auto joltSettings = reinterpret_cast<JPH::ShapeSettings*>(settings);
		joltSettings->Release();
	}
}

uint64_t JPH_ShapeSettings_GetUserData(const JPH_ShapeSettings* settings)
{
	return reinterpret_cast<const JPH::ShapeSettings*>(settings)->mUserData;
}

void JPH_ShapeSettings_SetUserData(JPH_ShapeSettings* settings, uint64_t userData)
{
	reinterpret_cast<JPH::ShapeSettings*>(settings)->mUserData = userData;
}


/* Shape */
#ifdef JPH_DEBUG_RENDERER
void JPH_Shape_Draw(const JPH_Shape* shape, JPH_DebugRenderer* renderer, const JPH_RMat4* centerOfMassTransform, const JPH_Vec3* scale, JPH_Color color, bool useMaterialColors, bool drawWireframe)
{
	AsShape(shape)->Draw(
		reinterpret_cast<DebugRenderer*>(renderer),
		ToJolt(centerOfMassTransform),
		ToJolt(scale),
		JPH::Color(color),
		useMaterialColors,
		drawWireframe);
}
#endif

void JPH_Shape_Destroy(JPH_Shape* shape)
{
	AsShape(shape)->Release();
}

JPH_ShapeType JPH_Shape_GetType(const JPH_Shape* shape)
{
	return static_cast<JPH_ShapeType>(AsShape(shape)->GetType());
}

JPH_ShapeSubType JPH_Shape_GetSubType(const JPH_Shape* shape)
{
	return static_cast<JPH_ShapeSubType>(AsShape(shape)->GetSubType());
}

uint64_t JPH_Shape_GetUserData(const JPH_Shape* shape)
{
	return AsShape(shape)->GetUserData();
}

void JPH_Shape_SetUserData(JPH_Shape* shape, uint64_t userData)
{
	AsShape(shape)->SetUserData(userData);
}

bool JPH_Shape_MustBeStatic(const JPH_Shape* shape)
{
	return AsShape(shape)->MustBeStatic();
}

void JPH_Shape_GetCenterOfMass(const JPH_Shape* shape, JPH_Vec3* result)
{
	FromJolt(AsShape(shape)->GetCenterOfMass(), result);
}

void JPH_Shape_GetLocalBounds(const JPH_Shape* shape, JPH_AABox* result)
{
	FromJolt(AsShape(shape)->GetLocalBounds(), result);
}

uint32_t JPH_Shape_GetSubShapeIDBitsRecursive(const JPH_Shape* shape)
{
	return AsShape(shape)->GetSubShapeIDBitsRecursive();
}

void JPH_Shape_GetWorldSpaceBounds(const JPH_Shape* shape, JPH_RMat4* centerOfMassTransform, JPH_Vec3* scale, JPH_AABox* result)
{
	auto bounds = AsShape(shape)->GetWorldSpaceBounds(ToJolt(centerOfMassTransform), ToJolt(scale));
	FromJolt(bounds, result);
}

float JPH_Shape_GetInnerRadius(const JPH_Shape* shape)
{
	return AsShape(shape)->GetInnerRadius();
}

void JPH_Shape_GetMassProperties(const JPH_Shape* shape, JPH_MassProperties* result)
{
	FromJolt(AsShape(shape)->GetMassProperties(), result);
}

const JPH_Shape* JPH_Shape_GetLeafShape(const JPH_Shape* shape, JPH_SubShapeID subShapeID, JPH_SubShapeID* remainder)
{
	auto joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(subShapeID);
	JPH::SubShapeID joltRemainder = JPH::SubShapeID();
	const JPH::Shape* leaf = AsShape(shape)->GetLeafShape(joltSubShapeID, joltRemainder);
	*remainder = joltRemainder.GetValue();
	return reinterpret_cast<const JPH_Shape*>(leaf);
}

const JPH_PhysicsMaterial* JPH_Shape_GetMaterial(const JPH_Shape* shape, JPH_SubShapeID subShapeID)
{
	auto joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(subShapeID);
	return FromJolt(AsShape(shape)->GetMaterial(joltSubShapeID));
}

void JPH_Shape_GetSurfaceNormal(const JPH_Shape* shape, JPH_SubShapeID subShapeID, JPH_Vec3* localPosition, JPH_Vec3* normal)
{
	auto joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(subShapeID);
	Vec3 joltNormal = AsShape(shape)->GetSurfaceNormal(joltSubShapeID, ToJolt(localPosition));
	FromJolt(joltNormal, normal);
}

void JPH_Shape_GetSupportingFace(const JPH_Shape* shape,
	const JPH_SubShapeID subShapeID,
	const JPH_Vec3* direction,
	const JPH_Vec3* scale,
	const JPH_Mat4* centerOfMassTransform,
	JPH_SupportingFace* outVertices)
{
	JPH_ASSERT(shape);
	JPH_ASSERT(subShapeID);
	JPH_ASSERT(direction);
	JPH_ASSERT(scale);
	JPH_ASSERT(centerOfMassTransform);
	JPH_ASSERT(outVertices);

	auto joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(subShapeID);

	JPH::Vec3 joltDirection = ToJolt(direction);
	JPH::Vec3 joltScale = ToJolt(scale);
	JPH::Mat44 joltTransform = ToJolt(centerOfMassTransform);

	JPH::Shape::SupportingFace joltFace;
	AsShape(shape)->GetSupportingFace(joltSubShapeID, joltDirection, joltScale, joltTransform, joltFace);

	outVertices->count = static_cast<uint32_t>(joltFace.size());
	JPH_ASSERT(outVertices->count <= 32);

	for (uint32_t i = 0; i < outVertices->count && i < 32; ++i) {
		FromJolt(joltFace[i], &outVertices->vertices[i]);
	}
}

float JPH_Shape_GetVolume(const JPH_Shape* shape)
{
	return AsShape(shape)->GetVolume();
}

bool JPH_Shape_IsValidScale(const JPH_Shape* shape, const JPH_Vec3* scale)
{
	return AsShape(shape)->IsValidScale(ToJolt(scale));
}

void JPH_Shape_MakeScaleValid(const JPH_Shape* shape, const JPH_Vec3* scale, JPH_Vec3* result)
{
	FromJolt(AsShape(shape)->MakeScaleValid(ToJolt(scale)), result);
}

JPH_Shape* JPH_Shape_ScaleShape(const JPH_Shape* shape, const JPH_Vec3* scale)
{
	auto shapeResult = AsShape(shape)->ScaleShape(ToJolt(scale));
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto scaleShape = shapeResult.Get().GetPtr();
	scaleShape->AddRef();

	return ToShape(scaleShape);
}

bool JPH_Shape_CastRay(const JPH_Shape* shape, const JPH_Vec3* origin, const JPH_Vec3* direction, JPH_RayCastResult* hit)
{
	JPH::RayCast ray(ToJolt(origin), ToJolt(direction));
	SubShapeIDCreator creator;
	RayCastResult result;

	const bool hadHit = AsShape(shape)->CastRay(ray, creator, result);

	if (hadHit)
	{
		hit->fraction = result.mFraction;
		hit->bodyID = result.mBodyID.GetIndexAndSequenceNumber();
		hit->subShapeID2 = result.mSubShapeID2.GetValue();
	}

	return hadHit;
}

bool JPH_Shape_CastRay2(const JPH_Shape* shape, const JPH_Vec3* origin, const JPH_Vec3* direction, const JPH_RayCastSettings* rayCastSettings, JPH_CollisionCollectorType collectorType, JPH_CastRayResultCallback* callback, void* userData, const JPH_ShapeFilter* shapeFilter)
{
	JPH::RayCast ray(ToJolt(origin), ToJolt(direction));
	JPH::RayCastSettings settings = ToJolt(rayCastSettings);

	SubShapeIDCreator creator;
	JPH_RayCastResult hitResult{};

	switch (collectorType)
	{
		case JPH_CollisionCollectorType_AllHit:
		case JPH_CollisionCollectorType_AllHitSorted:
		{
			AllHitCollisionCollector<CastRayCollector> collector;
			AsShape(shape)->CastRay(ray, settings, creator, collector, ToJolt(shapeFilter));

			if (collector.HadHit())
			{
				if (collectorType == JPH_CollisionCollectorType_AllHitSorted)
					collector.Sort();

				for (auto& hit : collector.mHits)
				{
					hitResult.fraction = hit.mFraction;
					hitResult.bodyID = hit.mBodyID.GetIndexAndSequenceNumber();
					hitResult.subShapeID2 = hit.mSubShapeID2.GetValue();
					callback(userData, &hitResult);
				}
			}

			return collector.HadHit();
		}
		case JPH_CollisionCollectorType_ClosestHit:
		{
			ClosestHitCollisionCollector<CastRayCollector> collector;
			AsShape(shape)->CastRay(ray, settings, creator, collector, ToJolt(shapeFilter));

			if (collector.HadHit())
			{
				hitResult.fraction = collector.mHit.mFraction;
				hitResult.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				hitResult.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &hitResult);
			}

			return collector.HadHit();
		}

		case JPH_CollisionCollectorType_AnyHit:
		{
			AnyHitCollisionCollector<CastRayCollector> collector;
			AsShape(shape)->CastRay(ray, settings, creator, collector, ToJolt(shapeFilter));

			if (collector.HadHit())
			{
				hitResult.fraction = collector.mHit.mFraction;
				hitResult.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				hitResult.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &hitResult);
			}

			return collector.HadHit();
		}

		default:
			return false;
	}
}

bool JPH_Shape_CollidePoint(const JPH_Shape* shape, const JPH_Vec3* point, const JPH_ShapeFilter* shapeFilter)
{
	SubShapeIDCreator creator;
	AnyHitCollisionCollector<CollidePointCollector> collector;

	AsShape(shape)->CollidePoint(ToJolt(point), creator, collector, ToJolt(shapeFilter));
	return collector.HadHit();
}

bool JPH_Shape_CollidePoint2(const JPH_Shape* shape, const JPH_Vec3* point,
	JPH_CollisionCollectorType collectorType,
	JPH_CollidePointResultCallback* callback,
	void* userData,
	const JPH_ShapeFilter* shapeFilter)
{
	JPH::Vec3 joltPoint = ToJolt(point);
	SubShapeIDCreator creator;
	JPH_CollidePointResult result{};

	switch (collectorType)
	{
		case JPH_CollisionCollectorType_AllHit:
		case JPH_CollisionCollectorType_AllHitSorted:
		{
			AllHitCollisionCollector<CollidePointCollector> collector;
			AsShape(shape)->CollidePoint(joltPoint, creator, collector, ToJolt(shapeFilter));

			if (collector.HadHit())
			{
				if (collectorType == JPH_CollisionCollectorType_AllHitSorted)
					collector.Sort();

				for (auto& hit : collector.mHits)
				{
					result.bodyID = hit.mBodyID.GetIndexAndSequenceNumber();
					result.subShapeID2 = hit.mSubShapeID2.GetValue();
					callback(userData, &result);
				}
			}

			return collector.HadHit();
		}
		case JPH_CollisionCollectorType_ClosestHit:
		{
			ClosestHitCollisionCollector<CollidePointCollector> collector;
			AsShape(shape)->CollidePoint(joltPoint, creator, collector, ToJolt(shapeFilter));

			if (collector.HadHit())
			{
				result.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				result.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &result);
			}

			return collector.HadHit();
		}

		case JPH_CollisionCollectorType_AnyHit:
		{
			AnyHitCollisionCollector<CollidePointCollector> collector;
			AsShape(shape)->CollidePoint(joltPoint, creator, collector, ToJolt(shapeFilter));

			if (collector.HadHit())
			{
				result.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				result.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &result);
			}

			return collector.HadHit();
		}

		default:
			return false;
	}
}

/* ConvexShape */
float JPH_ConvexShapeSettings_GetDensity(const JPH_ConvexShapeSettings* shape)
{
	return AsConvexShapeSettings(shape)->mDensity;
}

void JPH_ConvexShapeSettings_SetDensity(JPH_ConvexShapeSettings* shape, float value)
{
	AsConvexShapeSettings(shape)->SetDensity(value);
}

float JPH_ConvexShape_GetDensity(const JPH_ConvexShape* shape)
{
	return AsConvexShape(shape)->GetDensity();
}

void JPH_ConvexShape_SetDensity(JPH_ConvexShape* shape, float density)
{
	AsConvexShape(shape)->SetDensity(density);
}

/* BoxShape */
JPH_BoxShapeSettings* JPH_BoxShapeSettings_Create(const JPH_Vec3* halfExtent, float convexRadius)
{
	auto settings = new JPH::BoxShapeSettings(ToJolt(halfExtent), convexRadius);
	settings->AddRef();

	return ToBoxShapeSettings(settings);
}

JPH_BoxShape* JPH_BoxShapeSettings_CreateShape(const JPH_BoxShapeSettings* settings)
{
	auto shapeResult = AsBoxShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_BoxShape*>(shape);
}

JPH_BoxShape* JPH_BoxShape_Create(const JPH_Vec3* halfExtent, float convexRadius)
{
	auto shape = new JPH::BoxShape(ToJolt(halfExtent), convexRadius);
	shape->AddRef();

	return ToBoxShape(shape);
}

void JPH_BoxShape_GetHalfExtent(const JPH_BoxShape* shape, JPH_Vec3* halfExtent)
{
	auto joltVector = AsBoxShape(shape)->GetHalfExtent();
	FromJolt(joltVector, halfExtent);
}

float JPH_BoxShape_GetConvexRadius(const JPH_BoxShape* shape)
{
	return AsBoxShape(shape)->GetConvexRadius();
}

/* SphereShapeSettings */
JPH_SphereShapeSettings* JPH_SphereShapeSettings_Create(float radius)
{
	auto settings = new JPH::SphereShapeSettings(radius);
	settings->AddRef();

	return ToSphereShapeSettings(settings);
}

JPH_SphereShape* JPH_SphereShapeSettings_CreateShape(const JPH_SphereShapeSettings* settings)
{
	auto shapeResult = AsSphereShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_SphereShape*>(shape);
}

float JPH_SphereShapeSettings_GetRadius(const JPH_SphereShapeSettings* settings)
{
	return AsSphereShapeSettings(settings)->mRadius;
}

void JPH_SphereShapeSettings_SetRadius(JPH_SphereShapeSettings* settings, float radius)
{
	AsSphereShapeSettings(settings)->mRadius = radius;
}

JPH_SphereShape* JPH_SphereShape_Create(float radius)
{
	auto shape = new JPH::SphereShape(radius);
	shape->AddRef();

	return ToSphereShape(shape);
}

float JPH_SphereShape_GetRadius(const JPH_SphereShape* shape)
{
	return AsSphereShape(shape)->GetRadius();
}

/* PlaneShape */
JPH_PlaneShapeSettings* JPH_PlaneShapeSettings_Create(const JPH_Plane* plane, const JPH_PhysicsMaterial* material, float halfExtent)
{
	const JPH::PhysicsMaterial* joltMaterial = material != nullptr ? reinterpret_cast<const JPH::PhysicsMaterial*>(material) : nullptr;

	auto settings = new JPH::PlaneShapeSettings(ToJolt(plane), joltMaterial, halfExtent);
	settings->AddRef();

	return ToPlaneShapeSettings(settings);
}

JPH_PlaneShape* JPH_PlaneShapeSettings_CreateShape(const JPH_PlaneShapeSettings* settings)
{
	auto shapeResult = AsPlaneShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_PlaneShape*>(shape);
}

JPH_PlaneShape* JPH_PlaneShape_Create(const JPH_Plane* plane, const JPH_PhysicsMaterial* material, float halfExtent)
{
	const JPH::PhysicsMaterial* joltMaterial = material != nullptr ? reinterpret_cast<const JPH::PhysicsMaterial*>(material) : nullptr;

	auto shape = new JPH::PlaneShape(ToJolt(plane), joltMaterial, halfExtent);
	shape->AddRef();

	return ToPlaneShape(shape);
}

void JPH_PlaneShape_GetPlane(const JPH_PlaneShape* shape, JPH_Plane* result)
{
	FromJolt(AsPlaneShape(shape)->GetPlane(), result);
}

float JPH_PlaneShape_GetHalfExtent(const JPH_PlaneShape* shape)
{
	return AsPlaneShape(shape)->GetHalfExtent();
}

/* TriangleShape */
JPH_TriangleShapeSettings* JPH_TriangleShapeSettings_Create(const JPH_Vec3* v1, const JPH_Vec3* v2, const JPH_Vec3* v3, float convexRadius)
{
	auto settings = new JPH::TriangleShapeSettings(ToJolt(v1), ToJolt(v2), ToJolt(v3), convexRadius);
	settings->AddRef();

	return ToTriangleShapeSettings(settings);
}

JPH_TriangleShape* JPH_TriangleShapeSettings_CreateShape(const JPH_TriangleShapeSettings* settings)
{
	const JPH::TriangleShapeSettings* joltSettings = reinterpret_cast<const JPH::TriangleShapeSettings*>(settings);
	auto shapeResult = joltSettings->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_TriangleShape*>(shape);
}

JPH_TriangleShape* JPH_TriangleShape_Create(const JPH_Vec3* v1, const JPH_Vec3* v2, const JPH_Vec3* v3, float convexRadius)
{
	auto shape = new JPH::TriangleShape(ToJolt(v1), ToJolt(v2), ToJolt(v3), convexRadius);
	shape->AddRef();

	return ToTriangleShape(shape);
}

float JPH_TriangleShape_GetConvexRadius(const JPH_TriangleShape* shape)
{
	return AsTriangleShape(shape)->GetConvexRadius();
}

void JPH_TriangleShape_GetVertex1(const JPH_TriangleShape* shape, JPH_Vec3* result)
{
	FromJolt(AsTriangleShape(shape)->GetVertex1(), result);
}

void JPH_TriangleShape_GetVertex2(const JPH_TriangleShape* shape, JPH_Vec3* result)
{
	FromJolt(AsTriangleShape(shape)->GetVertex2(), result);
}

void JPH_TriangleShape_GetVertex3(const JPH_TriangleShape* shape, JPH_Vec3* result)
{
	FromJolt(AsTriangleShape(shape)->GetVertex3(), result);
}

/* CapsuleShapeSettings */
JPH_CapsuleShapeSettings* JPH_CapsuleShapeSettings_Create(float halfHeightOfCylinder, float radius)
{
	auto settings = new JPH::CapsuleShapeSettings(halfHeightOfCylinder, radius);
	settings->AddRef();

	return ToCapsuleShapeSettings(settings);
}

JPH_CapsuleShape* JPH_CapsuleShapeSettings_CreateShape(const JPH_CapsuleShapeSettings* settings)
{
	auto shapeResult = AsCapsuleShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_CapsuleShape*>(shape);
}

JPH_CapsuleShape* JPH_CapsuleShape_Create(float halfHeightOfCylinder, float radius)
{
	auto shape = new JPH::CapsuleShape(halfHeightOfCylinder, radius, 0);
	shape->AddRef();

	return ToCapsuleShape(shape);
}

float JPH_CapsuleShape_GetRadius(const JPH_CapsuleShape* shape)
{
	return AsCapsuleShape(shape)->GetRadius();
}

float JPH_CapsuleShape_GetHalfHeightOfCylinder(const JPH_CapsuleShape* shape)
{
	return AsCapsuleShape(shape)->GetHalfHeightOfCylinder();
}

/* CylinderShapeSettings */
JPH_CylinderShapeSettings* JPH_CylinderShapeSettings_Create(float halfHeight, float radius, float convexRadius)
{
	auto settings = new JPH::CylinderShapeSettings(halfHeight, radius, convexRadius);
	settings->AddRef();

	return ToCylinderShapeSettings(settings);
}

JPH_CylinderShape* JPH_CylinderShapeSettings_CreateShape(const JPH_CylinderShapeSettings* settings)
{
	auto shapeResult = AsCylinderShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_CylinderShape*>(shape);
}

JPH_CylinderShape* JPH_CylinderShape_Create(float halfHeight, float radius)
{
	auto shape = new JPH::CylinderShape(halfHeight, radius, 0.f, 0);
	shape->AddRef();

	return ToCylinderShape(shape);
}

float JPH_CylinderShape_GetRadius(const JPH_CylinderShape* shape)
{
	return AsCylinderShape(shape)->GetRadius();
}

float JPH_CylinderShape_GetHalfHeight(const JPH_CylinderShape* shape)
{
	return AsCylinderShape(shape)->GetHalfHeight();
}

/* TaperedCylinderShape */
JPH_TaperedCylinderShapeSettings* JPH_TaperedCylinderShapeSettings_Create(float halfHeightOfTaperedCylinder, float topRadius, float bottomRadius, float convexRadius/* = cDefaultConvexRadius*/, const JPH_PhysicsMaterial* material /* = NULL*/)
{
	const JPH::PhysicsMaterial* joltMaterial = material != nullptr ? reinterpret_cast<const JPH::PhysicsMaterial*>(material) : nullptr;

	auto settings = new JPH::TaperedCylinderShapeSettings(halfHeightOfTaperedCylinder, topRadius, bottomRadius, convexRadius, joltMaterial);
	settings->AddRef();

	return ToTaperedCylinderShapeSettings(settings);
}

JPH_TaperedCylinderShape* JPH_TaperedCylinderShapeSettings_CreateShape(const JPH_TaperedCylinderShapeSettings* settings)
{
	auto shapeResult = AsTaperedCylinderShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_TaperedCylinderShape*>(shape);
}

float JPH_TaperedCylinderShape_GetTopRadius(const JPH_TaperedCylinderShape* shape)
{
	return AsTaperedCylinderShape(shape)->GetTopRadius();
}

float JPH_TaperedCylinderShape_GetBottomRadius(const JPH_TaperedCylinderShape* shape)
{
	return AsTaperedCylinderShape(shape)->GetBottomRadius();
}

float JPH_TaperedCylinderShape_GetConvexRadius(const JPH_TaperedCylinderShape* shape)
{
	return AsTaperedCylinderShape(shape)->GetConvexRadius();
}

float JPH_TaperedCylinderShape_GetHalfHeight(const JPH_TaperedCylinderShape* shape)
{
	return AsTaperedCylinderShape(shape)->GetHalfHeight();
}

/* ConvexHullShape */
JPH_ConvexHullShapeSettings* JPH_ConvexHullShapeSettings_Create(const JPH_Vec3* points, uint32_t pointsCount, float maxConvexRadius)
{
	Array<Vec3> joltPoints;
	joltPoints.reserve(pointsCount);

	for (uint32_t i = 0; i < pointsCount; i++)
	{
		joltPoints.push_back(ToJolt(&points[i]));
	}

	auto settings = new JPH::ConvexHullShapeSettings(joltPoints, maxConvexRadius);
	settings->AddRef();

	return ToConvexHullShapeSettings(settings);
}

JPH_ConvexHullShape* JPH_ConvexHullShapeSettings_CreateShape(const JPH_ConvexHullShapeSettings* settings)
{
	auto shapeResult = AsConvexHullShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_ConvexHullShape*>(shape);
}

uint32_t JPH_ConvexHullShape_GetNumPoints(const JPH_ConvexHullShape* shape)
{
	return AsConvexHullShape(shape)->GetNumPoints();
}

void JPH_ConvexHullShape_GetPoint(const JPH_ConvexHullShape* shape, uint32_t index, JPH_Vec3* result)
{
	FromJolt(AsConvexHullShape(shape)->GetPoint(index), result);
}

uint32_t JPH_ConvexHullShape_GetNumFaces(const JPH_ConvexHullShape* shape)
{
	return AsConvexHullShape(shape)->GetNumFaces();
}

uint32_t JPH_ConvexHullShape_GetNumVerticesInFace(const JPH_ConvexHullShape* shape, uint32_t faceIndex)
{
	return AsConvexHullShape(shape)->GetNumVerticesInFace(faceIndex);
}

uint32_t JPH_ConvexHullShape_GetFaceVertices(const JPH_ConvexHullShape* shape, uint32_t faceIndex, uint32_t maxVertices, uint32_t* vertices)
{
	return AsConvexHullShape(shape)->GetFaceVertices(faceIndex, maxVertices, vertices);
}

/* MeshShapeSettings */
JPH_MeshShapeSettings* JPH_MeshShapeSettings_Create(const JPH_Triangle* triangles, uint32_t triangleCount)
{
	TriangleList jolTriangles;
	jolTriangles.reserve(triangleCount);

	for (uint32_t i = 0; i < triangleCount; ++i)
	{
		jolTriangles.push_back(ToTriangle(triangles[i]));
	}

	auto settings = new MeshShapeSettings(jolTriangles);
	settings->AddRef();

	return ToMeshShapeSettings(settings);
}

JPH_MeshShapeSettings* JPH_MeshShapeSettings_Create2(const JPH_Vec3* vertices, uint32_t verticesCount, const JPH_IndexedTriangle* triangles, uint32_t triangleCount)
{
	JPH::VertexList joltVertices;
	JPH::IndexedTriangleList joltTriangles;

	joltVertices.reserve(verticesCount);
	joltTriangles.reserve(triangleCount);

	for (uint32_t i = 0; i < verticesCount; ++i)
	{
		joltVertices.push_back(ToJoltFloat3(vertices[i]));
	}

	for (uint32_t i = 0; i < triangleCount; ++i)
	{
		joltTriangles.push_back(ToIndexedTriangle(triangles[i]));
	}

	auto settings = new JPH::MeshShapeSettings(joltVertices, joltTriangles);
	settings->AddRef();

	return ToMeshShapeSettings(settings);
}

uint32_t JPH_MeshShapeSettings_GetMaxTrianglesPerLeaf(const JPH_MeshShapeSettings* settings)
{
	return AsMeshShapeSettings(settings)->mMaxTrianglesPerLeaf;
}

void JPH_MeshShapeSettings_SetMaxTrianglesPerLeaf(JPH_MeshShapeSettings* settings, uint32_t value)
{
	AsMeshShapeSettings(settings)->mMaxTrianglesPerLeaf = value;
}
float JPH_MeshShapeSettings_GetActiveEdgeCosThresholdAngle(const JPH_MeshShapeSettings* settings)
{
	return AsMeshShapeSettings(settings)->mActiveEdgeCosThresholdAngle;
}

void JPH_MeshShapeSettings_SetActiveEdgeCosThresholdAngle(JPH_MeshShapeSettings* settings, float value)
{
	AsMeshShapeSettings(settings)->mActiveEdgeCosThresholdAngle = value;
}

bool JPH_MeshShapeSettings_GetPerTriangleUserData(const JPH_MeshShapeSettings* settings)
{
	return AsMeshShapeSettings(settings)->mPerTriangleUserData;
}

void JPH_MeshShapeSettings_SetPerTriangleUserData(JPH_MeshShapeSettings* settings, bool value)
{
	AsMeshShapeSettings(settings)->mPerTriangleUserData = value;
}

JPH_Mesh_Shape_BuildQuality JPH_MeshShapeSettings_GetBuildQuality(const JPH_MeshShapeSettings* settings)
{
	return static_cast<JPH_Mesh_Shape_BuildQuality>(AsMeshShapeSettings(settings)->mBuildQuality);
}

void JPH_MeshShapeSettings_SetBuildQuality(JPH_MeshShapeSettings* settings, JPH_Mesh_Shape_BuildQuality value)
{
	AsMeshShapeSettings(settings)->mBuildQuality = static_cast<MeshShapeSettings::EBuildQuality>(value);
}

void JPH_MeshShapeSettings_Sanitize(JPH_MeshShapeSettings* settings)
{
	AsMeshShapeSettings(settings)->Sanitize();
}

JPH_MeshShape* JPH_MeshShapeSettings_CreateShape(const JPH_MeshShapeSettings* settings)
{
	auto shapeResult = AsMeshShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_MeshShape*>(shape);
}

uint32_t JPH_MeshShape_GetTriangleUserData(const JPH_MeshShape* shape, JPH_SubShapeID id)
{
	JPH::SubShapeID joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(id);
	return AsMeshShape(shape)->GetTriangleUserData(joltSubShapeID);
}

/* HeightFieldShapeSettings */
JPH_HeightFieldShapeSettings* JPH_HeightFieldShapeSettings_Create(const float* samples, const JPH_Vec3* offset, const JPH_Vec3* scale, uint32_t sampleCount, const uint8_t* materialIndices)
{
	auto settings = new JPH::HeightFieldShapeSettings(samples, ToJolt(offset), ToJolt(scale), sampleCount, materialIndices);
	settings->AddRef();

	return ToHeightFieldShapeSettings(settings);
}

void JPH_HeightFieldShapeSettings_DetermineMinAndMaxSample(const JPH_HeightFieldShapeSettings* settings, float* pOutMinValue, float* pOutMaxValue, float* pOutQuantizationScale)
{
	float outMinValue, outMaxValue, outQuantizationScale;
	AsHeightFieldShapeSettings(settings)->DetermineMinAndMaxSample(outMinValue, outMaxValue, outQuantizationScale);
	if (pOutMinValue)
		*pOutMinValue = outMinValue;
	if (pOutMaxValue)
		*pOutMaxValue = outMaxValue;
	if (pOutQuantizationScale)
		*pOutQuantizationScale = outQuantizationScale;
}

uint32_t JPH_HeightFieldShapeSettings_CalculateBitsPerSampleForError(const JPH_HeightFieldShapeSettings* settings, float maxError)
{
	return AsHeightFieldShapeSettings(settings)->CalculateBitsPerSampleForError(maxError);
}

void JPH_HeightFieldShapeSettings_GetOffset(const JPH_HeightFieldShapeSettings* shape, JPH_Vec3* result)
{
	FromJolt(AsHeightFieldShapeSettings(shape)->mOffset, result);
}

void JPH_HeightFieldShapeSettings_SetOffset(JPH_HeightFieldShapeSettings* settings, const JPH_Vec3* value)
{
	AsHeightFieldShapeSettings(settings)->mOffset = ToJolt(value);
}

void JPH_HeightFieldShapeSettings_GetScale(const JPH_HeightFieldShapeSettings* shape, JPH_Vec3* result)
{
	FromJolt(AsHeightFieldShapeSettings(shape)->mScale, result);
}

JPH_CAPI void JPH_HeightFieldShapeSettings_SetScale(JPH_HeightFieldShapeSettings* settings, const JPH_Vec3* value)
{
	AsHeightFieldShapeSettings(settings)->mScale = ToJolt(value);
}

uint32_t JPH_HeightFieldShapeSettings_GetSampleCount(const JPH_HeightFieldShapeSettings* settings)
{
	return AsHeightFieldShapeSettings(settings)->mSampleCount;
}

void JPH_HeightFieldShapeSettings_SetSampleCount(JPH_HeightFieldShapeSettings* settings, uint32_t value)
{
	AsHeightFieldShapeSettings(settings)->mSampleCount = value;
}

float JPH_HeightFieldShapeSettings_GetMinHeightValue(const JPH_HeightFieldShapeSettings* settings)
{
	return AsHeightFieldShapeSettings(settings)->mMinHeightValue;
}

void JPH_HeightFieldShapeSettings_SetMinHeightValue(JPH_HeightFieldShapeSettings* settings, float value)
{
	AsHeightFieldShapeSettings(settings)->mMinHeightValue = value;
}

float JPH_HeightFieldShapeSettings_GetMaxHeightValue(const JPH_HeightFieldShapeSettings* settings)
{
	return AsHeightFieldShapeSettings(settings)->mMaxHeightValue;
}

void JPH_HeightFieldShapeSettings_SetMaxHeightValue(JPH_HeightFieldShapeSettings* settings, float value)
{
	AsHeightFieldShapeSettings(settings)->mMaxHeightValue = value;
}

uint32_t JPH_HeightFieldShapeSettings_GetBlockSize(const JPH_HeightFieldShapeSettings* settings)
{
	return AsHeightFieldShapeSettings(settings)->mBlockSize;
}

void JPH_HeightFieldShapeSettings_SetBlockSize(JPH_HeightFieldShapeSettings* settings, uint32_t value)
{
	AsHeightFieldShapeSettings(settings)->mBlockSize = value;
}

uint32_t JPH_HeightFieldShapeSettings_GetBitsPerSample(const JPH_HeightFieldShapeSettings* settings)
{
	return AsHeightFieldShapeSettings(settings)->mBitsPerSample;
}

void JPH_HeightFieldShapeSettings_SetBitsPerSample(JPH_HeightFieldShapeSettings* settings, uint32_t value)
{
	AsHeightFieldShapeSettings(settings)->mBitsPerSample = value;
}

float JPH_HeightFieldShapeSettings_GetActiveEdgeCosThresholdAngle(const JPH_HeightFieldShapeSettings* settings)
{
	return AsHeightFieldShapeSettings(settings)->mActiveEdgeCosThresholdAngle;
}

void JPH_HeightFieldShapeSettings_SetActiveEdgeCosThresholdAngle(JPH_HeightFieldShapeSettings* settings, float value)
{
	AsHeightFieldShapeSettings(settings)->mActiveEdgeCosThresholdAngle = value;
}

JPH_HeightFieldShape* JPH_HeightFieldShapeSettings_CreateShape(JPH_HeightFieldShapeSettings* settings)
{
	auto shapeResult = AsHeightFieldShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_HeightFieldShape*>(shape);
}

uint32_t JPH_HeightFieldShape_GetSampleCount(const JPH_HeightFieldShape* shape)
{
	return AsHeightFieldShape(shape)->GetSampleCount();
}

uint32_t JPH_HeightFieldShape_GetBlockSize(const JPH_HeightFieldShape* shape)
{
	return AsHeightFieldShape(shape)->GetBlockSize();
}

const JPH_PhysicsMaterial* JPH_HeightFieldShape_GetMaterial(const JPH_HeightFieldShape* shape, uint32_t x, uint32_t y)
{
	return FromJolt(AsHeightFieldShape(shape)->GetMaterial(x, y));
}

void JPH_HeightFieldShape_GetPosition(const JPH_HeightFieldShape* shape, uint32_t x, uint32_t y, JPH_Vec3* result)
{
	return FromJolt(AsHeightFieldShape(shape)->GetPosition(x, y), result);
}

bool JPH_HeightFieldShape_IsNoCollision(const JPH_HeightFieldShape* shape, uint32_t x, uint32_t y)
{
	return AsHeightFieldShape(shape)->IsNoCollision(x, y);
}

bool JPH_HeightFieldShape_ProjectOntoSurface(const JPH_HeightFieldShape* shape, const JPH_Vec3* localPosition, JPH_Vec3* outSurfacePosition, JPH_SubShapeID* outSubShapeID)
{
	JPH_ASSERT(outSurfacePosition);
	JPH_ASSERT(outSubShapeID);

	Vec3 surfacePosition;
	SubShapeID subShapeID;

	bool result = AsHeightFieldShape(shape)->ProjectOntoSurface(ToJolt(localPosition), surfacePosition, subShapeID);
	FromJolt(surfacePosition, outSurfacePosition);
	*outSubShapeID = subShapeID.GetValue();
	return result;
}

float JPH_HeightFieldShape_GetMinHeightValue(const JPH_HeightFieldShape* shape)
{
	return AsHeightFieldShape(shape)->GetMinHeightValue();
}

float JPH_HeightFieldShape_GetMaxHeightValue(const JPH_HeightFieldShape* shape)
{
	return AsHeightFieldShape(shape)->GetMaxHeightValue();
}

/* TaperedCapsuleShapeSettings */
JPH_TaperedCapsuleShapeSettings* JPH_TaperedCapsuleShapeSettings_Create(float halfHeightOfTaperedCylinder, float topRadius, float bottomRadius)
{
	auto settings = new JPH::TaperedCapsuleShapeSettings(halfHeightOfTaperedCylinder, topRadius, bottomRadius);
	settings->AddRef();

	return ToTaperedCapsuleShapeSettings(settings);
}

JPH_TaperedCapsuleShape* JPH_TaperedCapsuleShapeSettings_CreateShape(JPH_TaperedCapsuleShapeSettings* settings)
{
	auto shapeResult = AsTaperedCapsuleShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_TaperedCapsuleShape*>(shape);
}

float JPH_TaperedCapsuleShape_GetTopRadius(const JPH_TaperedCapsuleShape* shape)
{
	return AsTaperedCapsuleShape(shape)->GetTopRadius();
}

float JPH_TaperedCapsuleShape_GetBottomRadius(const JPH_TaperedCapsuleShape* shape)
{
	return AsTaperedCapsuleShape(shape)->GetBottomRadius();
}

float JPH_TaperedCapsuleShape_GetHalfHeight(const JPH_TaperedCapsuleShape* shape)
{
	return AsTaperedCapsuleShape(shape)->GetHalfHeight();
}

/* CompoundShape */
void JPH_CompoundShapeSettings_AddShape(JPH_CompoundShapeSettings* settings, const JPH_Vec3* position, const JPH_Quat* rotation, const JPH_ShapeSettings* shapeSettings, uint32_t userData)
{
	AsCompoundShapeSettings(settings)->AddShape(
		ToJolt(position),
		ToJolt(rotation),
		AsShapeSettings(shapeSettings),
		userData);
}

void JPH_CompoundShapeSettings_AddShape2(JPH_CompoundShapeSettings* settings, const JPH_Vec3* position, const JPH_Quat* rotation, const JPH_Shape* shape, uint32_t userData)
{
	AsCompoundShapeSettings(settings)->AddShape(
		ToJolt(position),
		ToJolt(rotation),
		AsShape(shape),
		userData);
}

uint32_t JPH_CompoundShape_GetNumSubShapes(const JPH_CompoundShape* shape)
{
	return AsCompoundShape(shape)->GetNumSubShapes();
}

void JPH_CompoundShape_GetSubShape(const JPH_CompoundShape* shape, uint32_t index, const JPH_Shape** subShape, JPH_Vec3* positionCOM, JPH_Quat* rotation, uint32_t* userData)
{
	const JPH::CompoundShape::SubShape& sub = AsCompoundShape(shape)->GetSubShape(index);
	if (subShape)
		*subShape = ToShape(sub.mShape.GetPtr());
	if (positionCOM)
		FromJolt(sub.GetPositionCOM(), positionCOM);
	if (rotation)
		FromJolt(sub.GetRotation(), rotation);
	if (userData)
		*userData = sub.mUserData;
}

uint32_t JPH_CompoundShape_GetSubShapeIndexFromID(const JPH_CompoundShape* shape, JPH_SubShapeID id, JPH_SubShapeID* remainder)
{
	auto joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(id);
	JPH::SubShapeID joltRemainder = JPH::SubShapeID();
	uint32_t index = AsCompoundShape(shape)->GetSubShapeIndexFromID(joltSubShapeID, joltRemainder);
	*remainder = joltRemainder.GetValue();
	return index;
}

/* StaticCompoundShape */
JPH_StaticCompoundShapeSettings* JPH_StaticCompoundShapeSettings_Create(void)
{
	auto settings = new JPH::StaticCompoundShapeSettings();
	settings->AddRef();

	return ToStaticCompoundShapeSettings(settings);
}

JPH_StaticCompoundShape* JPH_StaticCompoundShape_Create(const JPH_StaticCompoundShapeSettings* settings)
{
	const JPH::StaticCompoundShapeSettings* jolt_settings = reinterpret_cast<const JPH::StaticCompoundShapeSettings*>(settings);
	auto shapeResult = jolt_settings->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_StaticCompoundShape*>(shape);
}

/* MutableCompoundShape */
JPH_CAPI JPH_MutableCompoundShapeSettings* JPH_MutableCompoundShapeSettings_Create(void)
{
	auto settings = new JPH::MutableCompoundShapeSettings();
	settings->AddRef();

	return ToMutableCompoundShapeSettings(settings);
}

JPH_MutableCompoundShape* JPH_MutableCompoundShape_Create(const JPH_MutableCompoundShapeSettings* settings)
{
	const JPH::MutableCompoundShapeSettings* jolt_settings = reinterpret_cast<const JPH::MutableCompoundShapeSettings*>(settings);
	auto shapeResult = jolt_settings->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_MutableCompoundShape*>(shape);
}

uint32_t JPH_MutableCompoundShape_AddShape(JPH_MutableCompoundShape* shape, const JPH_Vec3* position, const JPH_Quat* rotation, const JPH_Shape* child, uint32_t userData, uint32_t index)
{
	return AsMutableCompoundShape(shape)->AddShape(ToJolt(position), ToJolt(rotation), AsShape(child), userData, index);
}

void JPH_MutableCompoundShape_RemoveShape(JPH_MutableCompoundShape* shape, uint32_t index)
{
	AsMutableCompoundShape(shape)->RemoveShape(index);
}

void JPH_MutableCompoundShape_ModifyShape(JPH_MutableCompoundShape* shape, uint32_t index, const JPH_Vec3* position, const JPH_Quat* rotation)
{
	AsMutableCompoundShape(shape)->ModifyShape(index, ToJolt(position), ToJolt(rotation));
}

void JPH_MutableCompoundShape_ModifyShape2(JPH_MutableCompoundShape* shape, uint32_t index, const JPH_Vec3* position, const JPH_Quat* rotation, const JPH_Shape* newShape)
{
	AsMutableCompoundShape(shape)->ModifyShape(index, ToJolt(position), ToJolt(rotation), AsShape(newShape));
}

void JPH_MutableCompoundShape_AdjustCenterOfMass(JPH_MutableCompoundShape* shape)
{
	reinterpret_cast<JPH::MutableCompoundShape*>(shape)->AdjustCenterOfMass();
}

/* DecoratedShape */
const JPH_Shape* JPH_DecoratedShape_GetInnerShape(const JPH_DecoratedShape* shape)
{
	return ToShape(AsDecoratedShape(shape)->GetInnerShape());
}

/* RotatedTranslatedShape */
JPH_RotatedTranslatedShapeSettings* JPH_RotatedTranslatedShapeSettings_Create(const JPH_Vec3* position, const JPH_Quat* rotation, const JPH_ShapeSettings* shapeSettings)
{
	auto settings = new JPH::RotatedTranslatedShapeSettings(
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		AsShapeSettings(shapeSettings)
	);
	settings->AddRef();

	return ToRotatedTranslatedShapeSettings(settings);
}

JPH_RotatedTranslatedShapeSettings* JPH_RotatedTranslatedShapeSettings_Create2(const JPH_Vec3* position, const JPH_Quat* rotation, const JPH_Shape* shape)
{
	auto settings = new JPH::RotatedTranslatedShapeSettings(
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		AsShape(shape)
	);
	settings->AddRef();

	return ToRotatedTranslatedShapeSettings(settings);
}

JPH_RotatedTranslatedShape* JPH_RotatedTranslatedShapeSettings_CreateShape(const JPH_RotatedTranslatedShapeSettings* settings)
{
	auto shapeResult = AsRotatedTranslatedShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}


	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_RotatedTranslatedShape*>(shape);
}

JPH_RotatedTranslatedShape* JPH_RotatedTranslatedShape_Create(const JPH_Vec3* position, const JPH_Quat* rotation, const JPH_Shape* shape)
{
	auto rotatedTranslatedShape = new JPH::RotatedTranslatedShape(
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		AsShape(shape)
	);
	rotatedTranslatedShape->AddRef();

	return ToRotatedTranslatedShape(rotatedTranslatedShape);
}

void JPH_RotatedTranslatedShape_GetPosition(const JPH_RotatedTranslatedShape* shape, JPH_Vec3* position)
{
	JPH::Vec3 joltVector = AsRotatedTranslatedShape(shape)->GetPosition();
	FromJolt(joltVector, position);
}

void JPH_RotatedTranslatedShape_GetRotation(const JPH_RotatedTranslatedShape* shape, JPH_Quat* rotation)
{
	JPH::Quat joltQuat = AsRotatedTranslatedShape(shape)->GetRotation();
	FromJolt(joltQuat, rotation);
}

JPH_ScaledShapeSettings* JPH_ScaledShapeSettings_Create(const JPH_ShapeSettings* shapeSettings, const JPH_Vec3* scale)
{
	auto settings = new JPH::ScaledShapeSettings(
		AsShapeSettings(shapeSettings),
		ToJolt(scale)
	);
	settings->AddRef();

	return ToScaledShapeSettings(settings);
}

JPH_ScaledShapeSettings* JPH_ScaledShapeSettings_Create2(const JPH_Shape* shape, const JPH_Vec3* scale)
{
	auto settings = new JPH::ScaledShapeSettings(
		AsShape(shape),
		ToJolt(scale)
	);
	settings->AddRef();

	return ToScaledShapeSettings(settings);
}

JPH_ScaledShape* JPH_ScaledShapeSettings_CreateShape(const JPH_ScaledShapeSettings* settings)
{
	const JPH::ScaledShapeSettings* jolt_settings = reinterpret_cast<const JPH::ScaledShapeSettings*>(settings);
	auto shapeResult = jolt_settings->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_ScaledShape*>(shape);
}

JPH_ScaledShape* JPH_ScaledShape_Create(const JPH_Shape* shape, const JPH_Vec3* scale)
{
	auto scaledShape = new JPH::ScaledShape(AsShape(shape), ToJolt(scale));
	scaledShape->AddRef();

	return ToScaledShape(scaledShape);
}

void JPH_ScaledShape_GetScale(const JPH_ScaledShape* shape, JPH_Vec3* result)
{
	JPH::Vec3 joltScale = AsScaledShape(shape)->GetScale();
	FromJolt(joltScale, result);
}

/* JPH_OffsetCenterOfMassShape */
JPH_OffsetCenterOfMassShapeSettings* JPH_OffsetCenterOfMassShapeSettings_Create(const JPH_Vec3* offset, const JPH_ShapeSettings* shapeSettings)
{
	auto settings = new JPH::OffsetCenterOfMassShapeSettings(
		ToJolt(offset),
		AsShapeSettings(shapeSettings)
	);
	settings->AddRef();

	return ToOffsetCenterOfMassShapeSettings(settings);
}

JPH_OffsetCenterOfMassShapeSettings* JPH_OffsetCenterOfMassShapeSettings_Create2(const JPH_Vec3* offset, const JPH_Shape* shape)
{
	auto rotatedTranslatedShape = new JPH::OffsetCenterOfMassShapeSettings(ToJolt(offset), AsShape(shape));
	rotatedTranslatedShape->AddRef();

	return ToOffsetCenterOfMassShapeSettings(rotatedTranslatedShape);
}

JPH_OffsetCenterOfMassShape* JPH_OffsetCenterOfMassShapeSettings_CreateShape(const JPH_OffsetCenterOfMassShapeSettings* settings)
{
	auto shapeResult = AsOffsetCenterOfMassShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return reinterpret_cast<JPH_OffsetCenterOfMassShape*>(shape);
}

JPH_OffsetCenterOfMassShape* JPH_OffsetCenterOfMassShape_Create(const JPH_Vec3* offset, const JPH_Shape* shape)
{
	auto offsetCenterOfMassShape = new JPH::OffsetCenterOfMassShape(AsShape(shape), ToJolt(offset));
	offsetCenterOfMassShape->AddRef();

	return ToOffsetCenterOfMassShape(offsetCenterOfMassShape);
}

void JPH_OffsetCenterOfMassShape_GetOffset(const JPH_OffsetCenterOfMassShape* shape, JPH_Vec3* result)
{
	FromJolt(AsOffsetCenterOfMassShape(shape)->GetOffset(), result);
}

/* EmptyShape */
JPH_EmptyShapeSettings* JPH_EmptyShapeSettings_Create(const JPH_Vec3* centerOfMass)
{
	auto settings = new EmptyShapeSettings(ToJolt(centerOfMass));
	settings->AddRef();

	return ToEmptyShapeSettings(settings);
}

JPH_EmptyShape* JPH_EmptyShapeSettings_CreateShape(const JPH_EmptyShapeSettings* settings)
{
	auto shapeResult = AsEmptyShapeSettings(settings)->Create();
	if (!shapeResult.IsValid())
	{
		return nullptr;
	}

	auto shape = shapeResult.Get().GetPtr();
	shape->AddRef();

	return ToEmptyShape(static_cast<EmptyShape*>(shape));
}

/* JPH_BodyCreationSettings */
JPH_BodyCreationSettings* JPH_BodyCreationSettings_Create(void)
{
	auto bodyCreationSettings = new JPH::BodyCreationSettings();
	return ToBodyCreationSettings(bodyCreationSettings);
}

JPH_BodyCreationSettings* JPH_BodyCreationSettings_Create2(
	const JPH_ShapeSettings* shapeSettings,
	const JPH_RVec3* position,
	const JPH_Quat* rotation,
	JPH_MotionType motionType,
	JPH_ObjectLayer objectLayer)
{
	auto bodyCreationSettings = new JPH::BodyCreationSettings(
		AsShapeSettings(shapeSettings),
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		(JPH::EMotionType)motionType,
		objectLayer
	);
	return ToBodyCreationSettings(bodyCreationSettings);
}

JPH_BodyCreationSettings* JPH_BodyCreationSettings_Create3(
	const JPH_Shape* shape,
	const JPH_RVec3* position,
	const JPH_Quat* rotation,
	JPH_MotionType motionType,
	JPH_ObjectLayer objectLayer)
{
	auto bodyCreationSettings = new JPH::BodyCreationSettings(
		AsShape(shape),
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		(JPH::EMotionType)motionType,
		objectLayer
	);
	return ToBodyCreationSettings(bodyCreationSettings);
}
void JPH_BodyCreationSettings_Destroy(JPH_BodyCreationSettings* settings)
{
	if (settings)
	{
		delete AsBodyCreationSettings(settings);
	}
}

void JPH_BodyCreationSettings_GetPosition(JPH_BodyCreationSettings* settings, JPH_RVec3* result)
{
	FromJolt(AsBodyCreationSettings(settings)->mPosition, result);
}

void JPH_BodyCreationSettings_SetPosition(JPH_BodyCreationSettings* settings, const JPH_RVec3* value)
{
	AsBodyCreationSettings(settings)->mPosition = ToJolt(value);
}

void JPH_BodyCreationSettings_GetRotation(JPH_BodyCreationSettings* settings, JPH_Quat* result)
{
	FromJolt(AsBodyCreationSettings(settings)->mRotation, result);
}

void JPH_BodyCreationSettings_SetRotation(JPH_BodyCreationSettings* settings, const JPH_Quat* value)
{
	AsBodyCreationSettings(settings)->mRotation = ToJolt(value);
}

void JPH_BodyCreationSettings_GetLinearVelocity(JPH_BodyCreationSettings* settings, JPH_Vec3* velocity)
{
	FromJolt(AsBodyCreationSettings(settings)->mLinearVelocity, velocity);
}

void JPH_BodyCreationSettings_SetLinearVelocity(JPH_BodyCreationSettings* settings, const JPH_Vec3* velocity)
{
	AsBodyCreationSettings(settings)->mLinearVelocity = ToJolt(velocity);
}

void JPH_BodyCreationSettings_GetAngularVelocity(JPH_BodyCreationSettings* settings, JPH_Vec3* velocity)
{
	FromJolt(AsBodyCreationSettings(settings)->mAngularVelocity, velocity);
}

void JPH_BodyCreationSettings_SetAngularVelocity(JPH_BodyCreationSettings* settings, const JPH_Vec3* velocity)
{
	JPH_ASSERT(settings);

	AsBodyCreationSettings(settings)->mAngularVelocity = ToJolt(velocity);
}

uint64_t JPH_BodyCreationSettings_GetUserData(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mUserData;
}

void JPH_BodyCreationSettings_SetUserData(JPH_BodyCreationSettings* settings, uint64_t value)
{
	AsBodyCreationSettings(settings)->mUserData = value;
}

JPH_ObjectLayer JPH_BodyCreationSettings_GetObjectLayer(const JPH_BodyCreationSettings* settings)
{
	return static_cast<JPH_ObjectLayer>(AsBodyCreationSettings(settings)->mObjectLayer);
}

void JPH_BodyCreationSettings_SetObjectLayer(JPH_BodyCreationSettings* settings, JPH_ObjectLayer value)
{
	AsBodyCreationSettings(settings)->mObjectLayer = static_cast<JPH::ObjectLayer>(value);
}

void JPH_BodyCreationSettings_GetCollisionGroup(const JPH_BodyCreationSettings* settings, JPH_CollisionGroup* result)
{
	FromJolt(AsBodyCreationSettings(settings)->mCollisionGroup, result);
}

void JPH_BodyCreationSettings_SetCollisionGroup(JPH_BodyCreationSettings* settings, const JPH_CollisionGroup* value)
{
	AsBodyCreationSettings(settings)->mCollisionGroup = ToJolt(value);
}

JPH_MotionType JPH_BodyCreationSettings_GetMotionType(const JPH_BodyCreationSettings* settings)
{
	return static_cast<JPH_MotionType>(AsBodyCreationSettings(settings)->mMotionType);
}

void JPH_BodyCreationSettings_SetMotionType(JPH_BodyCreationSettings* settings, JPH_MotionType value)
{
	AsBodyCreationSettings(settings)->mMotionType = static_cast<JPH::EMotionType>(value);
}

JPH_AllowedDOFs JPH_BodyCreationSettings_GetAllowedDOFs(const JPH_BodyCreationSettings* settings)
{
	return static_cast<JPH_AllowedDOFs>(AsBodyCreationSettings(settings)->mAllowedDOFs);
}

void JPH_BodyCreationSettings_SetAllowedDOFs(JPH_BodyCreationSettings* settings, JPH_AllowedDOFs value)
{
	AsBodyCreationSettings(settings)->mAllowedDOFs = (JPH::EAllowedDOFs)value;
}

bool JPH_BodyCreationSettings_GetAllowDynamicOrKinematic(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mAllowDynamicOrKinematic;
}

void JPH_BodyCreationSettings_SetAllowDynamicOrKinematic(JPH_BodyCreationSettings* settings, bool value)
{
	AsBodyCreationSettings(settings)->mAllowDynamicOrKinematic = value;
}

bool JPH_BodyCreationSettings_GetIsSensor(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mIsSensor;
}

void JPH_BodyCreationSettings_SetIsSensor(JPH_BodyCreationSettings* settings, bool value)
{
	AsBodyCreationSettings(settings)->mIsSensor = value;
}

bool JPH_BodyCreationSettings_GetCollideKinematicVsNonDynamic(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mCollideKinematicVsNonDynamic;
}

void JPH_BodyCreationSettings_SetCollideKinematicVsNonDynamic(JPH_BodyCreationSettings* settings, bool value)
{
	AsBodyCreationSettings(settings)->mCollideKinematicVsNonDynamic = value;
}

bool JPH_BodyCreationSettings_GetUseManifoldReduction(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mUseManifoldReduction;
}

void JPH_BodyCreationSettings_SetUseManifoldReduction(JPH_BodyCreationSettings* settings, bool value)
{
	AsBodyCreationSettings(settings)->mUseManifoldReduction = value;
}

bool JPH_BodyCreationSettings_GetApplyGyroscopicForce(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mApplyGyroscopicForce;
}

void JPH_BodyCreationSettings_SetApplyGyroscopicForce(JPH_BodyCreationSettings* settings, bool value)
{
	AsBodyCreationSettings(settings)->mApplyGyroscopicForce = value;
}

JPH_MotionQuality JPH_BodyCreationSettings_GetMotionQuality(const JPH_BodyCreationSettings* settings)
{
	return static_cast<JPH_MotionQuality>(AsBodyCreationSettings(settings)->mMotionQuality);
}

void JPH_BodyCreationSettings_SetMotionQuality(JPH_BodyCreationSettings* settings, JPH_MotionQuality value)
{
	AsBodyCreationSettings(settings)->mMotionQuality = (JPH::EMotionQuality)value;
}

bool JPH_BodyCreationSettings_GetEnhancedInternalEdgeRemoval(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mEnhancedInternalEdgeRemoval;
}

void JPH_BodyCreationSettings_SetEnhancedInternalEdgeRemoval(JPH_BodyCreationSettings* settings, bool value)
{
	AsBodyCreationSettings(settings)->mEnhancedInternalEdgeRemoval = value;
}

bool JPH_BodyCreationSettings_GetAllowSleeping(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mAllowSleeping;
}

void JPH_BodyCreationSettings_SetAllowSleeping(JPH_BodyCreationSettings* settings, bool value)
{
	AsBodyCreationSettings(settings)->mAllowSleeping = value;
}

float JPH_BodyCreationSettings_GetFriction(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mFriction;
}

void JPH_BodyCreationSettings_SetFriction(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mFriction = value;
}

float JPH_BodyCreationSettings_GetRestitution(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mRestitution;
}

void JPH_BodyCreationSettings_SetRestitution(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mRestitution = value;
}

float JPH_BodyCreationSettings_GetLinearDamping(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mLinearDamping;
}

void JPH_BodyCreationSettings_SetLinearDamping(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mLinearDamping = value;
}

float JPH_BodyCreationSettings_GetAngularDamping(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mAngularDamping;
}

void JPH_BodyCreationSettings_SetAngularDamping(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mAngularDamping = value;
}

float JPH_BodyCreationSettings_GetMaxLinearVelocity(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mMaxLinearVelocity;
}

void JPH_BodyCreationSettings_SetMaxLinearVelocity(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mMaxLinearVelocity = value;
}

float JPH_BodyCreationSettings_GetMaxAngularVelocity(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mMaxAngularVelocity;
}

void JPH_BodyCreationSettings_SetMaxAngularVelocity(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mMaxAngularVelocity = value;
}

float JPH_BodyCreationSettings_GetGravityFactor(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mGravityFactor;
}

void JPH_BodyCreationSettings_SetGravityFactor(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mGravityFactor = value;
}

uint32_t JPH_BodyCreationSettings_GetNumVelocityStepsOverride(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mNumVelocityStepsOverride;
}

void JPH_BodyCreationSettings_SetNumVelocityStepsOverride(JPH_BodyCreationSettings* settings, uint32_t value)
{
	AsBodyCreationSettings(settings)->mNumVelocityStepsOverride = value;
}

uint32_t JPH_BodyCreationSettings_GetNumPositionStepsOverride(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mNumPositionStepsOverride;
}

void JPH_BodyCreationSettings_SetNumPositionStepsOverride(JPH_BodyCreationSettings* settings, uint32_t value)
{
	AsBodyCreationSettings(settings)->mNumPositionStepsOverride = value;
}

JPH_OverrideMassProperties JPH_BodyCreationSettings_GetOverrideMassProperties(const JPH_BodyCreationSettings* settings)
{
	return static_cast<JPH_OverrideMassProperties>(AsBodyCreationSettings(settings)->mOverrideMassProperties);
}

void JPH_BodyCreationSettings_SetOverrideMassProperties(JPH_BodyCreationSettings* settings, JPH_OverrideMassProperties value)
{
	AsBodyCreationSettings(settings)->mOverrideMassProperties = static_cast<JPH::EOverrideMassProperties>(value);
}

float JPH_BodyCreationSettings_GetInertiaMultiplier(const JPH_BodyCreationSettings* settings)
{
	return AsBodyCreationSettings(settings)->mInertiaMultiplier;
}

void JPH_BodyCreationSettings_SetInertiaMultiplier(JPH_BodyCreationSettings* settings, float value)
{
	AsBodyCreationSettings(settings)->mInertiaMultiplier = value;
}

void JPH_BodyCreationSettings_GetMassPropertiesOverride(const JPH_BodyCreationSettings* settings, JPH_MassProperties* result)
{
	FromJolt(AsBodyCreationSettings(settings)->mMassPropertiesOverride, result);
}

void JPH_BodyCreationSettings_SetMassPropertiesOverride(JPH_BodyCreationSettings* settings, const JPH_MassProperties* massProperties)
{
	AsBodyCreationSettings(settings)->mMassPropertiesOverride = ToJolt(massProperties);
}

/* JPH_SoftBodySharedSettings */
JPH_SoftBodySharedSettings* JPH_SoftBodySharedSettings_Create(void)
{
	auto settings = new JPH::SoftBodySharedSettings();
	// Jolt requires at least one material to resolve face collisions
	settings->mMaterials.push_back(JPH::PhysicsMaterial::sDefault);
	settings->AddRef();
	return ToSoftBodySharedSettings(settings);
}

void JPH_SoftBodySharedSettings_Destroy(JPH_SoftBodySharedSettings* settings)
{
	if (settings)
	{
		AsSoftBodySharedSettings(settings)->Release();
	}
}

void JPH_SoftBodySharedSettings_AddVertex(JPH_SoftBodySharedSettings* settings, const JPH_SoftVertex* vertex)
{
	JPH::SoftBodySharedSettings::Vertex v{};
	v.mPosition = ToJoltFloat3(vertex->position);
	v.mVelocity = ToJoltFloat3(vertex->velocity);
	v.mInvMass = vertex->invMass;
	AsSoftBodySharedSettings(settings)->mVertices.push_back(v);
}

void JPH_SoftBodySharedSettings_AddVertices(JPH_SoftBodySharedSettings* settings, const JPH_SoftVertex* vertices, uint32_t count)
{
	if (!settings || !vertices || count == 0) 
		return;

	auto* s = AsSoftBodySharedSettings(settings);

	// Performance: Allocate memory once for the entire batch
	s->mVertices.reserve(s->mVertices.size() + count);

	for (uint32_t i = 0; i < count; i++) 
	{
		JPH::SoftBodySharedSettings::Vertex v{};
		v.mPosition = ToJoltFloat3(vertices[i].position);
		v.mVelocity = ToJoltFloat3(vertices[i].velocity);
		v.mInvMass = vertices[i].invMass;
		s->mVertices.push_back(v);
	}
}

bool JPH_SoftBodySharedSettings_RemoveVertex(JPH_SoftBodySharedSettings* settings, uint32_t index)
{
	if (index < AsSoftBodySharedSettings(settings)->mVertices.size()) 
	{
		AsSoftBodySharedSettings(settings)->mVertices.erase(AsSoftBodySharedSettings(settings)->mVertices.begin() + index);
		return true;
	}
	return false;
}

uint32_t JPH_SoftBodySharedSettings_GetVertexCount(const JPH_SoftBodySharedSettings* settings)
{
	return (uint32_t)AsSoftBodySharedSettings(settings)->mVertices.size();
}

bool JPH_SoftBodySharedSettings_GetVertex(const JPH_SoftBodySharedSettings* settings, uint32_t index, JPH_SoftVertex* outVertex)
{
	auto* joltSettings = AsSoftBodySharedSettings(settings);
	if (index < joltSettings->mVertices.size())
	{
		const auto& joltVertex = joltSettings->mVertices[index];
		FromJolt(joltVertex.mPosition, &outVertex->position);
		FromJolt(joltVertex.mVelocity, &outVertex->velocity);
		outVertex->invMass = joltVertex.mInvMass;
		return true;
	}

	return false;
}

void JPH_SoftBodySharedSettings_AddFace(JPH_SoftBodySharedSettings* settings, const JPH_SoftFace* face)
{
	JPH::SoftBodySharedSettings::Face f{};
	f.mVertex[0] = face->vertex1;
	f.mVertex[1] = face->vertex2;
	f.mVertex[2] = face->vertex3;
	f.mMaterialIndex = face->materialIndex;
	AsSoftBodySharedSettings(settings)->mFaces.push_back(f);
}

void JPH_SoftBodySharedSettings_AddFaces(JPH_SoftBodySharedSettings* settings, const JPH_SoftFace* faces, uint32_t count)
{
	if (!settings || !faces || count == 0) 
		return;

	auto* s = AsSoftBodySharedSettings(settings);

	// Performance: Avoid per-face reallocations
	s->mFaces.reserve(s->mFaces.size() + count);

	for (uint32_t i = 0; i < count; i++)
	{
		JPH::SoftBodySharedSettings::Face f;
		f.mVertex[0] = faces[i].vertex1;
		f.mVertex[1] = faces[i].vertex2;
		f.mVertex[2] = faces[i].vertex3;
		f.mMaterialIndex = faces[i].materialIndex;
		s->mFaces.push_back(f);
	}
}

bool JPH_SoftBodySharedSettings_RemoveFace(JPH_SoftBodySharedSettings* settings, uint32_t index)
{
	if (index < AsSoftBodySharedSettings(settings)->mFaces.size()) 
	{
		AsSoftBodySharedSettings(settings)->mFaces.erase(AsSoftBodySharedSettings(settings)->mFaces.begin() + index);
		return true;
	}
	return false;
}

uint32_t JPH_SoftBodySharedSettings_GetFaceCount(const JPH_SoftBodySharedSettings* settings)
{
	return (uint32_t)AsSoftBodySharedSettings(settings)->mFaces.size();
}

bool JPH_SoftBodySharedSettings_GetFace(const JPH_SoftBodySharedSettings* settings, uint32_t index, JPH_SoftFace* outFace)
{
	auto* joltSettings = AsSoftBodySharedSettings(settings);
	if (index < joltSettings->mFaces.size())
	{
		const auto& joltFace = joltSettings->mFaces[index];
		outFace->vertex1 = joltFace.mVertex[0];
		outFace->vertex2 = joltFace.mVertex[1];
		outFace->vertex3 = joltFace.mVertex[2];
		outFace->materialIndex = joltFace.mMaterialIndex;
		return true;
	}

	return false;
}

void JPH_SoftBodySharedSettings_CreateConstraints(JPH_SoftBodySharedSettings* settings, float compliance, JPH_SoftBodyBendType bendType)
{
	auto* joltSettings = AsSoftBodySharedSettings(settings);
	JPH::Array<JPH::SoftBodySharedSettings::VertexAttributes> attributes;
	attributes.resize(joltSettings->mVertices.size());

	for (auto& attr : attributes) 
	{
		attr.mCompliance = compliance;
		attr.mShearCompliance = compliance;
	}

	joltSettings->CreateConstraints(attributes.data(), (JPH::uint)attributes.size(),
		static_cast<JPH::SoftBodySharedSettings::EBendType>(bendType));
}

void JPH_SoftBodySharedSettings_Optimize(JPH_SoftBodySharedSettings* settings)
{
	AsSoftBodySharedSettings(settings)->Optimize();
}

/* JPH_SoftBodyCreationSettings */
JPH_SoftBodyCreationSettings* JPH_SoftBodyCreationSettings_Create(void)
{
	auto bodyCreationSettings = new JPH::SoftBodyCreationSettings();
	return ToSoftBodyCreationSettings(bodyCreationSettings);
}

JPH_SoftBodyCreationSettings* JPH_SoftBodyCreationSettings_Create2(const JPH_SoftBodySharedSettings* settings, const JPH_RVec3* position, const JPH_Quat* rotation, JPH_ObjectLayer objectLayer)
{
	auto bodyCreationSettings = new JPH::SoftBodyCreationSettings(
		AsSoftBodySharedSettings(settings),
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		objectLayer
	);
	return ToSoftBodyCreationSettings(bodyCreationSettings);
}

void JPH_SoftBodyCreationSettings_Destroy(JPH_SoftBodyCreationSettings* settings)
{
	if (settings)
	{
		delete AsSoftBodyCreationSettings(settings);
	}
}

const JPH_SoftBodySharedSettings* JPH_SoftBodyCreationSettings_GetSettings(const JPH_SoftBodyCreationSettings* settings)
{
	return ToSoftBodySharedSettings(AsSoftBodyCreationSettings(settings)->mSettings.GetPtr());
}

void JPH_SoftBodyCreationSettings_SetSettings(JPH_SoftBodyCreationSettings* settings, const JPH_SoftBodySharedSettings* sharedSettings)
{
	AsSoftBodyCreationSettings(settings)->mSettings = AsSoftBodySharedSettings(sharedSettings);
}

void JPH_SoftBodyCreationSettings_GetPosition(JPH_SoftBodyCreationSettings* settings, JPH_RVec3* result)
{
	FromJolt(AsSoftBodyCreationSettings(settings)->mPosition, result);
}

void JPH_SoftBodyCreationSettings_SetPosition(JPH_SoftBodyCreationSettings* settings, const JPH_RVec3* value)
{
	AsSoftBodyCreationSettings(settings)->mPosition = ToJolt(value);
}

void JPH_SoftBodyCreationSettings_GetRotation(JPH_SoftBodyCreationSettings* settings, JPH_Quat* result)
{
	FromJolt(AsSoftBodyCreationSettings(settings)->mRotation, result);
}

void JPH_SoftBodyCreationSettings_SetRotation(JPH_SoftBodyCreationSettings* settings, const JPH_Quat* value)
{
	AsSoftBodyCreationSettings(settings)->mRotation = ToJolt(value);
}

uint64_t JPH_SoftBodyCreationSettings_GetUserData(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mUserData;
}

void JPH_SoftBodyCreationSettings_SetUserData(JPH_SoftBodyCreationSettings* settings, uint64_t userData)
{
	AsSoftBodyCreationSettings(settings)->mUserData = userData;
}

JPH_ObjectLayer JPH_SoftBodyCreationSettings_GetObjectLayer(const JPH_SoftBodyCreationSettings* settings)
{
	return static_cast<JPH_ObjectLayer>(AsSoftBodyCreationSettings(settings)->mObjectLayer);
}

void JPH_SoftBodyCreationSettings_SetObjectLayer(JPH_SoftBodyCreationSettings* settings, JPH_ObjectLayer value)
{
	AsSoftBodyCreationSettings(settings)->mObjectLayer = static_cast<JPH::ObjectLayer>(value);
}

void JPH_SoftBodyCreationSettings_GetCollisionGroup(const JPH_SoftBodyCreationSettings* settings, JPH_CollisionGroup* result)
{
	FromJolt(AsSoftBodyCreationSettings(settings)->mCollisionGroup, result);
}

void JPH_SoftBodyCreationSettings_SetCollisionGroup(JPH_SoftBodyCreationSettings* settings, const JPH_CollisionGroup* group)
{
	AsSoftBodyCreationSettings(settings)->mCollisionGroup = ToJolt(group);
}

uint32_t JPH_SoftBodyCreationSettings_GetNumIterations(const JPH_SoftBodyCreationSettings* settings)
{
	return settings ? AsSoftBodyCreationSettings(settings)->mNumIterations : 0;
}

void JPH_SoftBodyCreationSettings_SetNumIterations(JPH_SoftBodyCreationSettings* settings, uint32_t iterations)
{
	AsSoftBodyCreationSettings(settings)->mNumIterations = iterations;
}

float JPH_SoftBodyCreationSettings_GetLinearDamping(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mLinearDamping;
}

void JPH_SoftBodyCreationSettings_SetLinearDamping(JPH_SoftBodyCreationSettings* settings, float value)
{
	AsSoftBodyCreationSettings(settings)->mLinearDamping = value;
}

float JPH_SoftBodyCreationSettings_GetMaxLinearVelocity(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mMaxLinearVelocity;
}

void JPH_SoftBodyCreationSettings_SetMaxLinearVelocity(JPH_SoftBodyCreationSettings* settings, float value)
{
	AsSoftBodyCreationSettings(settings)->mMaxLinearVelocity = value;
}

float JPH_SoftBodyCreationSettings_GetRestitution(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mRestitution;
}

void JPH_SoftBodyCreationSettings_SetRestitution(JPH_SoftBodyCreationSettings* settings, float value)
{
	AsSoftBodyCreationSettings(settings)->mRestitution = value;
}

float JPH_SoftBodyCreationSettings_GetFriction(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mFriction;
}

void JPH_SoftBodyCreationSettings_SetFriction(JPH_SoftBodyCreationSettings* settings, float value)
{
	AsSoftBodyCreationSettings(settings)->mFriction = value;
}

float JPH_SoftBodyCreationSettings_GetPressure(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mPressure;
}

void JPH_SoftBodyCreationSettings_SetPressure(JPH_SoftBodyCreationSettings* settings, float value)
{
	AsSoftBodyCreationSettings(settings)->mPressure = value;
}

float JPH_SoftBodyCreationSettings_GetGravityFactor(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mGravityFactor;
}

void JPH_SoftBodyCreationSettings_SetGravityFactor(JPH_SoftBodyCreationSettings* settings, float value)
{
	AsSoftBodyCreationSettings(settings)->mGravityFactor = value;
}

float JPH_SoftBodyCreationSettings_GetVertexRadius(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mVertexRadius;
}

void JPH_SoftBodyCreationSettings_SetVertexRadius(JPH_SoftBodyCreationSettings* settings, float value)
{
	AsSoftBodyCreationSettings(settings)->mVertexRadius = value;
}

bool JPH_SoftBodyCreationSettings_GetUpdatePosition(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mUpdatePosition;
}

void JPH_SoftBodyCreationSettings_SetUpdatePosition(JPH_SoftBodyCreationSettings* settings, bool value)
{
	AsSoftBodyCreationSettings(settings)->mUpdatePosition = value;
}

bool JPH_SoftBodyCreationSettings_GetMakeRotationIdentity(const JPH_SoftBodyCreationSettings* settings)
{
	return  AsSoftBodyCreationSettings(settings)->mMakeRotationIdentity;
}

void JPH_SoftBodyCreationSettings_SetMakeRotationIdentity(JPH_SoftBodyCreationSettings* settings, bool value)
{
	AsSoftBodyCreationSettings(settings)->mMakeRotationIdentity = value;
}

bool JPH_SoftBodyCreationSettings_GetAllowSleeping(const JPH_SoftBodyCreationSettings* settings)
{
	return  AsSoftBodyCreationSettings(settings)->mAllowSleeping;
}

void JPH_SoftBodyCreationSettings_SetAllowSleeping(JPH_SoftBodyCreationSettings* settings, bool value)
{
	AsSoftBodyCreationSettings(settings)->mAllowSleeping = value;
}

bool JPH_SoftBodyCreationSettings_GetFacesDoubleSided(const JPH_SoftBodyCreationSettings* settings)
{
	return AsSoftBodyCreationSettings(settings)->mFacesDoubleSided;
}

void JPH_SoftBodyCreationSettings_SetFacesDoubleSided(JPH_SoftBodyCreationSettings* settings, bool value)
{
	AsSoftBodyCreationSettings(settings)->mFacesDoubleSided = value;
}

/* JPH_ConstraintSettings */
void JPH_ConstraintSettings_Init(const ConstraintSettings& joltSettings, JPH_ConstraintSettings* settings)
{
	// Copy defaults from jolt 
	settings->enabled = joltSettings.mEnabled;
	settings->constraintPriority = joltSettings.mConstraintPriority;
	settings->numVelocityStepsOverride = joltSettings.mNumVelocityStepsOverride;
	settings->numPositionStepsOverride = joltSettings.mNumPositionStepsOverride;
	settings->drawConstraintSize = joltSettings.mDrawConstraintSize;
	settings->userData = joltSettings.mUserData;
}

void JPH_ConstraintSettings_ToJolt(ConstraintSettings* joltSettings, const JPH_ConstraintSettings* settings)
{
	// Copy settings to jolt 
	joltSettings->mEnabled = settings->enabled;
	joltSettings->mConstraintPriority = settings->constraintPriority;
	joltSettings->mNumVelocityStepsOverride = settings->numVelocityStepsOverride;
	joltSettings->mNumPositionStepsOverride = settings->numPositionStepsOverride;
	joltSettings->mDrawConstraintSize = settings->drawConstraintSize;
	joltSettings->mUserData = settings->userData;
}

/* JPH_Constraint */
void JPH_Constraint_Destroy(JPH_Constraint* constraint)
{
	if (constraint)
	{
		AsConstraint(constraint)->Release();
	}
}

JPH_ConstraintType JPH_Constraint_GetType(const JPH_Constraint* constraint)
{
	return static_cast<JPH_ConstraintType>(AsConstraint(constraint)->GetType());
}

JPH_ConstraintSubType JPH_Constraint_GetSubType(const JPH_Constraint* constraint)
{
	return static_cast<JPH_ConstraintSubType>(AsConstraint(constraint)->GetSubType());
}

uint32_t JPH_Constraint_GetConstraintPriority(const JPH_Constraint* constraint)
{
	return AsConstraint(constraint)->GetConstraintPriority();
}

void JPH_Constraint_SetConstraintPriority(JPH_Constraint* constraint, uint32_t priority)
{
	return AsConstraint(constraint)->SetConstraintPriority(priority);
}

uint32_t JPH_Constraint_GetNumVelocityStepsOverride(const JPH_Constraint* constraint)
{
	return AsConstraint(constraint)->GetNumVelocityStepsOverride();
}

void JPH_Constraint_SetNumVelocityStepsOverride(JPH_Constraint* constraint, uint32_t value)
{
	AsConstraint(constraint)->SetNumVelocityStepsOverride(value);
}

uint32_t JPH_Constraint_GetNumPositionStepsOverride(const JPH_Constraint* constraint)
{
	return AsConstraint(constraint)->GetNumPositionStepsOverride();
}

void JPH_Constraint_SetNumPositionStepsOverride(JPH_Constraint* constraint, uint32_t value)
{
	AsConstraint(constraint)->SetNumPositionStepsOverride(value);
}

bool JPH_Constraint_GetEnabled(const JPH_Constraint* constraint)
{
	return AsConstraint(constraint)->GetEnabled();
}

void JPH_Constraint_SetEnabled(JPH_Constraint* constraint, bool enabled)
{
	AsConstraint(constraint)->SetEnabled(enabled);
}

uint64_t JPH_Constraint_GetUserData(const JPH_Constraint* constraint)
{
	return AsConstraint(constraint)->GetUserData();
}

void JPH_Constraint_SetUserData(JPH_Constraint* constraint, uint64_t userData)
{
	AsConstraint(constraint)->SetUserData(userData);
}

void JPH_Constraint_NotifyShapeChanged(JPH_Constraint* constraint, JPH_BodyID bodyID, JPH_Vec3* deltaCOM)
{
	AsConstraint(constraint)->NotifyShapeChanged(JPH::BodyID(bodyID), ToJolt(deltaCOM));
}

void JPH_Constraint_ResetWarmStart(JPH_Constraint* constraint)
{
	AsConstraint(constraint)->ResetWarmStart();
}

bool JPH_Constraint_IsActive(const JPH_Constraint* constraint)
{
	return AsConstraint(constraint)->IsActive();
}

void JPH_Constraint_SetupVelocityConstraint(JPH_Constraint* constraint, float deltaTime)
{
	AsConstraint(constraint)->SetupVelocityConstraint(deltaTime);
}

void JPH_Constraint_WarmStartVelocityConstraint(JPH_Constraint* constraint, float warmStartImpulseRatio)
{
	AsConstraint(constraint)->WarmStartVelocityConstraint(warmStartImpulseRatio);
}

bool JPH_Constraint_SolveVelocityConstraint(JPH_Constraint* constraint, float deltaTime)
{
	return AsConstraint(constraint)->SolveVelocityConstraint(deltaTime);
}

bool JPH_Constraint_SolvePositionConstraint(JPH_Constraint* constraint, float deltaTime, float baumgarte)
{
	return AsConstraint(constraint)->SolvePositionConstraint(deltaTime, baumgarte);
}

/* JPH_TwoBodyConstraint */
JPH_Body* JPH_TwoBodyConstraint_GetBody1(const JPH_TwoBodyConstraint* constraint)
{
	auto joltBody = AsTwoBodyConstraint(constraint)->GetBody1();
	return reinterpret_cast<JPH_Body*>(joltBody);
}

JPH_Body* JPH_TwoBodyConstraint_GetBody2(const JPH_TwoBodyConstraint* constraint)
{
	auto joltBody = AsTwoBodyConstraint(constraint)->GetBody2();
	return reinterpret_cast<JPH_Body*>(joltBody);
}

void JPH_TwoBodyConstraint_GetConstraintToBody1Matrix(const JPH_TwoBodyConstraint* constraint, JPH_Mat4* result)
{
	auto joltMatrix = AsTwoBodyConstraint(constraint)->GetConstraintToBody1Matrix();
	FromJolt(joltMatrix, result);
}

void JPH_TwoBodyConstraint_GetConstraintToBody2Matrix(const JPH_TwoBodyConstraint* constraint, JPH_Mat4* result)
{
	auto joltMatrix = AsTwoBodyConstraint(constraint)->GetConstraintToBody2Matrix();
	FromJolt(joltMatrix, result);
}

/* JPH_FixedConstraintSettings */
void JPH_FixedConstraintSettings_FromJolt(JPH_FixedConstraintSettings* settings, const JPH::FixedConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	settings->autoDetectPoint = joltSettings.mAutoDetectPoint;
	FromJolt(joltSettings.mPoint1, &settings->point1);
	FromJolt(joltSettings.mAxisX1, &settings->axisX1);
	FromJolt(joltSettings.mAxisY1, &settings->axisY1);
	FromJolt(joltSettings.mPoint2, &settings->point2);
	FromJolt(joltSettings.mAxisX2, &settings->axisX2);
	FromJolt(joltSettings.mAxisY2, &settings->axisY2);
}

void JPH_FixedConstraintSettings_ToJolt(FixedConstraintSettings* joltSettings, const JPH_FixedConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mAutoDetectPoint = settings->autoDetectPoint;
	joltSettings->mPoint1 = ToJolt(settings->point1);
	joltSettings->mAxisX1 = ToJolt(settings->axisX1);
	joltSettings->mAxisY1 = ToJolt(settings->axisY1);
	joltSettings->mPoint2 = ToJolt(settings->point2);
	joltSettings->mAxisX2 = ToJolt(settings->axisX2);
	joltSettings->mAxisY2 = ToJolt(settings->axisY2);
}

void JPH_FixedConstraintSettings_Init(JPH_FixedConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_FixedConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	JPH::FixedConstraintSettings joltSettings;
	JPH_FixedConstraintSettings_FromJolt(settings, joltSettings);
}

JPH_FixedConstraint* JPH_FixedConstraint_Create(const JPH_FixedConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	FixedConstraintSettings joltSettings;
	JPH_FixedConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	FixedConstraint* constraint = static_cast<FixedConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToFixedConstraint(constraint);
}

/* JPH_FixedConstraint */
void JPH_FixedConstraint_GetSettings(const JPH_FixedConstraint* constraint, JPH_FixedConstraintSettings* settings)
{
	JPH_ASSERT(settings);

	Ref<FixedConstraintSettings> joltSettings = StaticCast<FixedConstraintSettings>(AsFixedConstraint(constraint)->GetConstraintSettings());
	JPH_FixedConstraintSettings_FromJolt(settings, *joltSettings);
}

void JPH_FixedConstraint_GetTotalLambdaPosition(const JPH_FixedConstraint* constraint, JPH_Vec3* result)
{
	auto lambda = AsFixedConstraint(constraint)->GetTotalLambdaPosition();
	FromJolt(lambda, result);
}

void JPH_FixedConstraint_GetTotalLambdaRotation(const JPH_FixedConstraint* constraint, JPH_Vec3* result)
{
	auto lambda = AsFixedConstraint(constraint)->GetTotalLambdaRotation();
	FromJolt(lambda, result);
}

/* JPH_DistanceConstraintSettings */
void JPH_DistanceConstraintSettings_FromJolt(JPH_DistanceConstraintSettings* settings, const JPH::DistanceConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	FromJolt(joltSettings.mPoint1, &settings->point1);
	FromJolt(joltSettings.mPoint2, &settings->point2);
	settings->minDistance = joltSettings.mMinDistance;
	settings->maxDistance = joltSettings.mMaxDistance;
	FromJolt(joltSettings.mLimitsSpringSettings, &settings->limitsSpringSettings);
}

void JPH_DistanceConstraintSettings_ToJolt(DistanceConstraintSettings* joltSettings, const JPH_DistanceConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mPoint1 = ToJolt(settings->point1);
	joltSettings->mPoint2 = ToJolt(settings->point2);
	joltSettings->mMinDistance = settings->minDistance;
	joltSettings->mMaxDistance = settings->maxDistance;
	joltSettings->mLimitsSpringSettings = ToJolt(&settings->limitsSpringSettings);
}

void JPH_DistanceConstraintSettings_Init(JPH_DistanceConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_DistanceConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	JPH::DistanceConstraintSettings joltSettings;
	JPH_DistanceConstraintSettings_FromJolt(settings, joltSettings);
}

JPH_DistanceConstraint* JPH_DistanceConstraint_Create(const JPH_DistanceConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	DistanceConstraintSettings joltSettings;
	JPH_DistanceConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	DistanceConstraint* constraint = static_cast<DistanceConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToDistanceConstraint(constraint);
}

void JPH_DistanceConstraint_GetSettings(const JPH_DistanceConstraint* constraint, JPH_DistanceConstraintSettings* settings)
{
	JPH_ASSERT(settings);

	Ref<DistanceConstraintSettings> joltSettings = StaticCast<DistanceConstraintSettings>(AsDistanceConstraint(constraint)->GetConstraintSettings());
	JPH_DistanceConstraintSettings_FromJolt(settings, *joltSettings);
}

void JPH_DistanceConstraint_SetDistance(JPH_DistanceConstraint* constraint, float minDistance, float maxDistance)
{
	reinterpret_cast<JPH::DistanceConstraint*>(constraint)->SetDistance(minDistance, maxDistance);
}

float JPH_DistanceConstraint_GetMinDistance(JPH_DistanceConstraint* constraint)
{
	return reinterpret_cast<JPH::DistanceConstraint*>(constraint)->GetMinDistance();
}

float JPH_DistanceConstraint_GetMaxDistance(JPH_DistanceConstraint* constraint)
{
	return reinterpret_cast<JPH::DistanceConstraint*>(constraint)->GetMaxDistance();
}

void JPH_DistanceConstraint_GetLimitsSpringSettings(JPH_DistanceConstraint* constraint, JPH_SpringSettings* result)
{
	auto joltConstraint = reinterpret_cast<JPH::DistanceConstraint*>(constraint);
	FromJolt(joltConstraint->GetLimitsSpringSettings(), result);
}

void JPH_DistanceConstraint_SetLimitsSpringSettings(JPH_DistanceConstraint* constraint, JPH_SpringSettings* settings)
{
	auto joltConstraint = reinterpret_cast<JPH::DistanceConstraint*>(constraint);
	joltConstraint->SetLimitsSpringSettings(ToJolt(settings));
}

float JPH_DistanceConstraint_GetTotalLambdaPosition(const JPH_DistanceConstraint* constraint)
{
	JPH_ASSERT(constraint);
	auto joltConstraint = reinterpret_cast<const JPH::DistanceConstraint*>(constraint);
	return joltConstraint->GetTotalLambdaPosition();
}

/* JPH_PointConstraintSettings */
void JPH_PointConstraintSettings_FromJolt(JPH_PointConstraintSettings* settings, const PointConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	FromJolt(joltSettings.mPoint1, &settings->point1);
	FromJolt(joltSettings.mPoint2, &settings->point2);
}

void JPH_PointConstraintSettings_ToJolt(PointConstraintSettings* joltSettings, const JPH_PointConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mPoint1 = ToJolt(settings->point1);
	joltSettings->mPoint2 = ToJolt(settings->point2);
}

void JPH_PointConstraintSettings_Init(JPH_PointConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_PointConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	PointConstraintSettings joltSettings;
	JPH_PointConstraintSettings_FromJolt(settings, joltSettings);
}

JPH_PointConstraint* JPH_PointConstraint_Create(const JPH_PointConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	PointConstraintSettings joltSettings;
	JPH_PointConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	PointConstraint* constraint = static_cast<PointConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToPointConstraint(constraint);
}

void JPH_PointConstraint_GetSettings(const JPH_PointConstraint* constraint, JPH_PointConstraintSettings* settings)
{
	JPH_ASSERT(settings);

	Ref<PointConstraintSettings> joltSettings = StaticCast<PointConstraintSettings>(AsPointConstraint(constraint)->GetConstraintSettings());
	JPH_PointConstraintSettings_FromJolt(settings, *joltSettings);
}

void JPH_PointConstraint_SetPoint1(JPH_PointConstraint* constraint, JPH_ConstraintSpace space, JPH_RVec3* value)
{
	AsPointConstraint(constraint)->SetPoint1(static_cast<JPH::EConstraintSpace>(space), ToJolt(value));
}

void JPH_PointConstraint_SetPoint2(JPH_PointConstraint* constraint, JPH_ConstraintSpace space, JPH_RVec3* value)
{
	AsPointConstraint(constraint)->SetPoint2(static_cast<JPH::EConstraintSpace>(space), ToJolt(value));
}

void JPH_PointConstraint_GetLocalSpacePoint1(const JPH_PointConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsPointConstraint(constraint)->GetLocalSpacePoint1(), result);
}

void JPH_PointConstraint_GetLocalSpacePoint2(const JPH_PointConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsPointConstraint(constraint)->GetLocalSpacePoint2(), result);
}

void JPH_PointConstraint_GetTotalLambdaPosition(const JPH_PointConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsPointConstraint(constraint)->GetTotalLambdaPosition(), result);
}

/* JPH_HingeConstraintSettings */
void JPH_HingeConstraintSettings_FromJolt(JPH_HingeConstraintSettings* settings, const HingeConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	FromJolt(joltSettings.mPoint1, &settings->point1);
	FromJolt(joltSettings.mHingeAxis1, &settings->hingeAxis1);
	FromJolt(joltSettings.mNormalAxis1, &settings->normalAxis1);
	FromJolt(joltSettings.mPoint2, &settings->point2);
	FromJolt(joltSettings.mHingeAxis2, &settings->hingeAxis2);
	FromJolt(joltSettings.mNormalAxis2, &settings->normalAxis2);
	settings->limitsMin = joltSettings.mLimitsMin;
	settings->limitsMax = joltSettings.mLimitsMax;
	FromJolt(joltSettings.mLimitsSpringSettings, &settings->limitsSpringSettings);
	settings->maxFrictionTorque = joltSettings.mMaxFrictionTorque;
	FromJolt(joltSettings.mMotorSettings, &settings->motorSettings);
}

void JPH_HingeConstraintSettings_ToJolt(HingeConstraintSettings* joltSettings, const JPH_HingeConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mPoint1 = ToJolt(settings->point1);
	joltSettings->mHingeAxis1 = ToJolt(settings->hingeAxis1);
	joltSettings->mNormalAxis1 = ToJolt(settings->normalAxis1);
	joltSettings->mPoint2 = ToJolt(settings->point2);
	joltSettings->mHingeAxis2 = ToJolt(settings->hingeAxis2);
	joltSettings->mNormalAxis2 = ToJolt(settings->normalAxis2);
	joltSettings->mLimitsMin = settings->limitsMin;
	joltSettings->mLimitsMax = settings->limitsMax;
	joltSettings->mLimitsSpringSettings = ToJolt(&settings->limitsSpringSettings);
	joltSettings->mMaxFrictionTorque = settings->maxFrictionTorque;
	joltSettings->mMotorSettings = ToJolt(&settings->motorSettings);
}

void JPH_HingeConstraintSettings_Init(JPH_HingeConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_HingeConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	HingeConstraintSettings joltSettings;
	JPH_HingeConstraintSettings_FromJolt(settings, joltSettings);
}

JPH_HingeConstraint* JPH_HingeConstraint_Create(const JPH_HingeConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	HingeConstraintSettings joltSettings;
	JPH_HingeConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	HingeConstraint* constraint = static_cast<HingeConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToHingeConstraint(constraint);
}

void JPH_HingeConstraint_GetSettings(JPH_HingeConstraint* constraint, JPH_HingeConstraintSettings* settings)
{
	Ref<HingeConstraintSettings> joltSettings = StaticCast<HingeConstraintSettings>(AsHingeConstraint(constraint)->GetConstraintSettings());
	JPH_HingeConstraintSettings_FromJolt(settings, *joltSettings);
}

void JPH_HingeConstraint_GetLocalSpacePoint1(const JPH_HingeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetLocalSpacePoint1(), result);
}

void JPH_HingeConstraint_GetLocalSpacePoint2(const JPH_HingeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetLocalSpacePoint2(), result);
}

void JPH_HingeConstraint_GetLocalSpaceHingeAxis1(const JPH_HingeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetLocalSpaceHingeAxis1(), result);
}

void JPH_HingeConstraint_GetLocalSpaceHingeAxis2(const JPH_HingeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetLocalSpaceHingeAxis2(), result);
}

void JPH_HingeConstraint_GetLocalSpaceNormalAxis1(const JPH_HingeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetLocalSpaceNormalAxis1(), result);
}

void JPH_HingeConstraint_GetLocalSpaceNormalAxis2(const JPH_HingeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetLocalSpaceNormalAxis2(), result);
}

float JPH_HingeConstraint_GetCurrentAngle(JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetCurrentAngle();
}

void JPH_HingeConstraint_SetMaxFrictionTorque(JPH_HingeConstraint* constraint, float frictionTorque)
{
	AsHingeConstraint(constraint)->SetMaxFrictionTorque(frictionTorque);
}

float JPH_HingeConstraint_GetMaxFrictionTorque(JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetMaxFrictionTorque();
}

void JPH_HingeConstraint_SetMotorSettings(JPH_HingeConstraint* constraint, JPH_MotorSettings* settings)
{
	JPH::MotorSettings& joltSettings = AsHingeConstraint(constraint)->GetMotorSettings();
	joltSettings = ToJolt(settings);
}

void JPH_HingeConstraint_GetMotorSettings(JPH_HingeConstraint* constraint, JPH_MotorSettings* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetMotorSettings(), result);
}

void JPH_HingeConstraint_SetMotorState(JPH_HingeConstraint* constraint, JPH_MotorState state)
{
	AsHingeConstraint(constraint)->SetMotorState(static_cast<JPH::EMotorState>(state));
}

JPH_MotorState JPH_HingeConstraint_GetMotorState(JPH_HingeConstraint* constraint)
{
	return static_cast<JPH_MotorState>(AsHingeConstraint(constraint)->GetMotorState());
}

void JPH_HingeConstraint_SetTargetAngularVelocity(JPH_HingeConstraint* constraint, float angularVelocity)
{
	return AsHingeConstraint(constraint)->SetTargetAngularVelocity(angularVelocity);
}

float JPH_HingeConstraint_GetTargetAngularVelocity(JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetTargetAngularVelocity();
}

void JPH_HingeConstraint_SetTargetAngle(JPH_HingeConstraint* constraint, float angle)
{
	return AsHingeConstraint(constraint)->SetTargetAngle(angle);
}

float JPH_HingeConstraint_GetTargetAngle(JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetTargetAngle();
}

void JPH_HingeConstraint_SetLimits(JPH_HingeConstraint* constraint, float inLimitsMin, float inLimitsMax)
{
	return AsHingeConstraint(constraint)->SetLimits(inLimitsMin, inLimitsMax);
}

float JPH_HingeConstraint_GetLimitsMin(JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetLimitsMin();
}

float JPH_HingeConstraint_GetLimitsMax(JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetLimitsMax();
}

bool JPH_HingeConstraint_HasLimits(JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->HasLimits();
}

void JPH_HingeConstraint_GetLimitsSpringSettings(JPH_HingeConstraint* constraint, JPH_SpringSettings* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetLimitsSpringSettings(), result);
}

void JPH_HingeConstraint_SetLimitsSpringSettings(JPH_HingeConstraint* constraint, JPH_SpringSettings* settings)
{
	AsHingeConstraint(constraint)->SetLimitsSpringSettings(ToJolt(settings));
}

void JPH_HingeConstraint_GetTotalLambdaPosition(const JPH_HingeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsHingeConstraint(constraint)->GetTotalLambdaPosition(), result);
}

void JPH_HingeConstraint_GetTotalLambdaRotation(const JPH_HingeConstraint* constraint, float rotation[2])
{
	auto lambda = AsHingeConstraint(constraint)->GetTotalLambdaRotation();
	rotation[0] = lambda[0];
	rotation[1] = lambda[1];
}

float JPH_HingeConstraint_GetTotalLambdaRotationLimits(const JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetTotalLambdaRotationLimits();
}

float JPH_HingeConstraint_GetTotalLambdaMotor(const JPH_HingeConstraint* constraint)
{
	return AsHingeConstraint(constraint)->GetTotalLambdaMotor();
}

/* JPH_SliderConstraintSettings */
void JPH_SliderConstraintSettings_FromJolt(JPH_SliderConstraintSettings* settings, const SliderConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	settings->autoDetectPoint = joltSettings.mAutoDetectPoint;

	FromJolt(joltSettings.mPoint1, &settings->point1);
	FromJolt(joltSettings.mSliderAxis1, &settings->sliderAxis1);
	FromJolt(joltSettings.mNormalAxis1, &settings->normalAxis1);
	FromJolt(joltSettings.mPoint2, &settings->point2);
	FromJolt(joltSettings.mSliderAxis2, &settings->sliderAxis2);
	FromJolt(joltSettings.mNormalAxis2, &settings->normalAxis2);
	settings->limitsMin = joltSettings.mLimitsMin;
	settings->limitsMax = joltSettings.mLimitsMax;
	FromJolt(joltSettings.mLimitsSpringSettings, &settings->limitsSpringSettings);
	settings->maxFrictionForce = joltSettings.mMaxFrictionForce;
	FromJolt(joltSettings.mMotorSettings, &settings->motorSettings);
}

void JPH_SliderConstraintSettings_ToJolt(SliderConstraintSettings* joltSettings, const JPH_SliderConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mAutoDetectPoint = settings->autoDetectPoint;
	joltSettings->mPoint1 = ToJolt(settings->point1);
	joltSettings->mSliderAxis1 = ToJolt(settings->sliderAxis1);
	joltSettings->mNormalAxis1 = ToJolt(settings->normalAxis1);
	joltSettings->mPoint2 = ToJolt(settings->point2);
	joltSettings->mSliderAxis2 = ToJolt(settings->sliderAxis2);
	joltSettings->mNormalAxis2 = ToJolt(settings->normalAxis2);
	joltSettings->mLimitsMin = settings->limitsMin;
	joltSettings->mLimitsMax = settings->limitsMax;
	joltSettings->mLimitsSpringSettings = ToJolt(&settings->limitsSpringSettings);
	joltSettings->mMaxFrictionForce = settings->maxFrictionForce;
	joltSettings->mMotorSettings = ToJolt(&settings->motorSettings);
}

void JPH_SliderConstraintSettings_Init(JPH_SliderConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_SliderConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	SliderConstraintSettings joltSettings;
	JPH_SliderConstraintSettings_FromJolt(settings, joltSettings);
}

void JPH_SliderConstraintSettings_SetSliderAxis(JPH_SliderConstraintSettings* settings, const JPH_Vec3* axis)
{
	JPH_ASSERT(settings);

	Vec3 joltAxis = ToJolt(axis);
	FromJolt(joltAxis, &settings->sliderAxis1);
	FromJolt(joltAxis, &settings->sliderAxis2);

	FromJolt(joltAxis.GetNormalizedPerpendicular(), &settings->normalAxis1);
	FromJolt(joltAxis.GetNormalizedPerpendicular(), &settings->normalAxis2);
}

JPH_SliderConstraint* JPH_SliderConstraint_Create(const JPH_SliderConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	SliderConstraintSettings joltSettings;
	JPH_SliderConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	SliderConstraint* constraint = static_cast<SliderConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToSliderConstraint(constraint);
}

void JPH_SliderConstraint_GetSettings(JPH_SliderConstraint* constraint, JPH_SliderConstraintSettings* settings)
{
	Ref<SliderConstraintSettings> joltSettings = StaticCast<SliderConstraintSettings>(AsSliderConstraint(constraint)->GetConstraintSettings());
	JPH_SliderConstraintSettings_FromJolt(settings, *joltSettings);
}

float JPH_SliderConstraint_GetCurrentPosition(JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetCurrentPosition();
}

void JPH_SliderConstraint_SetMaxFrictionForce(JPH_SliderConstraint* constraint, float frictionForce)
{
	AsSliderConstraint(constraint)->SetMaxFrictionForce(frictionForce);
}

float JPH_SliderConstraint_GetMaxFrictionForce(JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetMaxFrictionForce();
}

void JPH_SliderConstraint_SetMotorSettings(JPH_SliderConstraint* constraint, JPH_MotorSettings* settings)
{
	JPH::MotorSettings& joltSettings = AsSliderConstraint(constraint)->GetMotorSettings();
	joltSettings = ToJolt(settings);
}

void JPH_SliderConstraint_GetMotorSettings(const JPH_SliderConstraint* constraint, JPH_MotorSettings* result)
{
	FromJolt(AsSliderConstraint(constraint)->GetMotorSettings(), result);
}

void JPH_SliderConstraint_SetMotorState(JPH_SliderConstraint* constraint, JPH_MotorState state)
{
	AsSliderConstraint(constraint)->SetMotorState(static_cast<JPH::EMotorState>(state));
}

JPH_MotorState JPH_SliderConstraint_GetMotorState(JPH_SliderConstraint* constraint)
{
	return static_cast<JPH_MotorState>(AsSliderConstraint(constraint)->GetMotorState());
}

void JPH_SliderConstraint_SetTargetVelocity(JPH_SliderConstraint* constraint, float velocity)
{
	return AsSliderConstraint(constraint)->SetTargetVelocity(velocity);
}

float JPH_SliderConstraint_GetTargetVelocity(JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetTargetVelocity();
}

void JPH_SliderConstraint_SetTargetPosition(JPH_SliderConstraint* constraint, float position)
{
	return AsSliderConstraint(constraint)->SetTargetPosition(position);
}

float JPH_SliderConstraint_GetTargetPosition(JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetTargetPosition();
}

void JPH_SliderConstraint_SetLimits(JPH_SliderConstraint* constraint, float inLimitsMin, float inLimitsMax)
{
	return AsSliderConstraint(constraint)->SetLimits(inLimitsMin, inLimitsMax);
}

float JPH_SliderConstraint_GetLimitsMin(JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetLimitsMin();
}

float JPH_SliderConstraint_GetLimitsMax(JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetLimitsMax();
}

bool JPH_SliderConstraint_HasLimits(JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->HasLimits();
}

void JPH_SliderConstraint_GetLimitsSpringSettings(JPH_SliderConstraint* constraint, JPH_SpringSettings* result)
{
	FromJolt(AsSliderConstraint(constraint)->GetLimitsSpringSettings(), result);
}

void JPH_SliderConstraint_SetLimitsSpringSettings(JPH_SliderConstraint* constraint, JPH_SpringSettings* settings)
{
	AsSliderConstraint(constraint)->SetLimitsSpringSettings(ToJolt(settings));
}

void JPH_SliderConstraint_GetTotalLambdaPosition(const JPH_SliderConstraint* constraint, float position[2])
{
	auto lambda = AsSliderConstraint(constraint)->GetTotalLambdaPosition();
	position[0] = lambda[0];
	position[1] = lambda[1];
}

float JPH_SliderConstraint_GetTotalLambdaPositionLimits(const JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetTotalLambdaPositionLimits();
}

void JPH_SliderConstraint_GetTotalLambdaRotation(const JPH_SliderConstraint* constraint, JPH_Vec3* result)
{
	auto lambda = AsSliderConstraint(constraint)->GetTotalLambdaRotation();
	FromJolt(lambda, result);
}

float JPH_SliderConstraint_GetTotalLambdaMotor(const JPH_SliderConstraint* constraint)
{
	return AsSliderConstraint(constraint)->GetTotalLambdaMotor();
}

/* JPH_ConeConstraintSettings */
void JPH_ConeConstraintSettings_FromJolt(JPH_ConeConstraintSettings* settings, const ConeConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	FromJolt(joltSettings.mPoint1, &settings->point1);
	FromJolt(joltSettings.mTwistAxis1, &settings->twistAxis1);
	FromJolt(joltSettings.mPoint2, &settings->point2);
	FromJolt(joltSettings.mTwistAxis2, &settings->twistAxis2);
	settings->halfConeAngle = joltSettings.mHalfConeAngle;
}

void JPH_ConeConstraintSettings_ToJolt(ConeConstraintSettings* joltSettings, const JPH_ConeConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mPoint1 = ToJolt(settings->point1);
	joltSettings->mTwistAxis1 = ToJolt(settings->twistAxis1);
	joltSettings->mPoint2 = ToJolt(settings->point2);
	joltSettings->mTwistAxis2 = ToJolt(settings->twistAxis2);
	joltSettings->mHalfConeAngle = settings->halfConeAngle;
}

void JPH_ConeConstraintSettings_Init(JPH_ConeConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_ConeConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	ConeConstraintSettings joltSettings;
	JPH_ConeConstraintSettings_FromJolt(settings, joltSettings);
}

JPH_ConeConstraint* JPH_ConeConstraint_Create(const JPH_ConeConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	ConeConstraintSettings joltSettings;
	JPH_ConeConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	ConeConstraint* constraint = static_cast<ConeConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToConeConstraint(constraint);
}

void JPH_ConeConstraint_GetSettings(JPH_ConeConstraint* constraint, JPH_ConeConstraintSettings* settings)
{
	Ref<ConeConstraintSettings> joltSettings = StaticCast<ConeConstraintSettings>(AsConeConstraint(constraint)->GetConstraintSettings());
	JPH_ConeConstraintSettings_FromJolt(settings, *joltSettings);
}

void JPH_ConeConstraint_SetHalfConeAngle(JPH_ConeConstraint* constraint, float halfConeAngle)
{
	AsConeConstraint(constraint)->SetHalfConeAngle(halfConeAngle);
}

float JPH_ConeConstraint_GetCosHalfConeAngle(const JPH_ConeConstraint* constraint)
{
	return AsConeConstraint(constraint)->GetCosHalfConeAngle();
}

void JPH_ConeConstraint_GetTotalLambdaPosition(const JPH_ConeConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsConeConstraint(constraint)->GetTotalLambdaPosition(), result);
}

float JPH_ConeConstraint_GetTotalLambdaRotation(const JPH_ConeConstraint* constraint)
{
	return AsConeConstraint(constraint)->GetTotalLambdaRotation();
}

/* JPH_SwingTwistConstraintSettings */
void JPH_SwingTwistConstraintSettings_FromJolt(JPH_SwingTwistConstraintSettings* settings, const SwingTwistConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	FromJolt(joltSettings.mPosition1, &settings->position1);
	FromJolt(joltSettings.mTwistAxis1, &settings->twistAxis1);
	FromJolt(joltSettings.mPlaneAxis1, &settings->planeAxis1);
	FromJolt(joltSettings.mPosition2, &settings->position2);
	FromJolt(joltSettings.mTwistAxis2, &settings->twistAxis2);
	FromJolt(joltSettings.mPlaneAxis2, &settings->planeAxis2);
	settings->swingType = static_cast<JPH_SwingType>(joltSettings.mSwingType);
	settings->normalHalfConeAngle = joltSettings.mNormalHalfConeAngle;
	settings->planeHalfConeAngle = joltSettings.mPlaneHalfConeAngle;

	settings->twistMinAngle = joltSettings.mTwistMinAngle;
	settings->twistMaxAngle = joltSettings.mTwistMaxAngle;
	settings->maxFrictionTorque = joltSettings.mMaxFrictionTorque;

	FromJolt(joltSettings.mSwingMotorSettings, &settings->swingMotorSettings);
	FromJolt(joltSettings.mTwistMotorSettings, &settings->twistMotorSettings);
}

void JPH_SwingTwistConstraintSettings_ToJolt(SwingTwistConstraintSettings* joltSettings, const JPH_SwingTwistConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mPosition1 = ToJolt(settings->position1);
	joltSettings->mTwistAxis1 = ToJolt(settings->twistAxis1);
	joltSettings->mPlaneAxis1 = ToJolt(settings->planeAxis1);
	joltSettings->mPosition2 = ToJolt(settings->position2);
	joltSettings->mTwistAxis2 = ToJolt(settings->twistAxis2);
	joltSettings->mPlaneAxis2 = ToJolt(settings->planeAxis2);
	joltSettings->mSwingType = static_cast<ESwingType>(settings->swingType);
	joltSettings->mNormalHalfConeAngle = settings->normalHalfConeAngle;
	joltSettings->mPlaneHalfConeAngle = settings->planeHalfConeAngle;
	joltSettings->mTwistMinAngle = settings->twistMinAngle;
	joltSettings->mTwistMaxAngle = settings->twistMaxAngle;
	joltSettings->mMaxFrictionTorque = settings->maxFrictionTorque;
	joltSettings->mSwingMotorSettings = ToJolt(&settings->swingMotorSettings);
	joltSettings->mTwistMotorSettings = ToJolt(&settings->twistMotorSettings);
}

void JPH_SwingTwistConstraintSettings_Init(JPH_SwingTwistConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_SwingTwistConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	SwingTwistConstraintSettings joltSettings;
	JPH_SwingTwistConstraintSettings_FromJolt(settings, joltSettings);
}

JPH_SwingTwistConstraint* JPH_SwingTwistConstraint_Create(const JPH_SwingTwistConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	SwingTwistConstraintSettings joltSettings;
	JPH_SwingTwistConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	SwingTwistConstraint* constraint = static_cast<SwingTwistConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToSwingTwistConstraint(constraint);
}

void JPH_SwingTwistConstraint_GetSettings(JPH_SwingTwistConstraint* constraint, JPH_SwingTwistConstraintSettings* settings)
{
	Ref<SwingTwistConstraintSettings> joltSettings = StaticCast<SwingTwistConstraintSettings>(AsSwingTwistConstraint(constraint)->GetConstraintSettings());
	JPH_SwingTwistConstraintSettings_FromJolt(settings, *joltSettings);
}

float JPH_SwingTwistConstraint_GetNormalHalfConeAngle(JPH_SwingTwistConstraint* constraint)
{
	return AsSwingTwistConstraint(constraint)->GetNormalHalfConeAngle();
}

void JPH_SwingTwistConstraint_GetTotalLambdaPosition(const JPH_SwingTwistConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSwingTwistConstraint(constraint)->GetTotalLambdaPosition(), result);
}

float JPH_SwingTwistConstraint_GetTotalLambdaTwist(const JPH_SwingTwistConstraint* constraint)
{
	return AsSwingTwistConstraint(constraint)->GetTotalLambdaTwist();
}

float JPH_SwingTwistConstraint_GetTotalLambdaSwingY(const JPH_SwingTwistConstraint* constraint)
{
	JPH_ASSERT(constraint);
	auto joltConstraint = reinterpret_cast<const JPH::SwingTwistConstraint*>(constraint);
	return joltConstraint->GetTotalLambdaSwingY();
}

float JPH_SwingTwistConstraint_GetTotalLambdaSwingZ(const JPH_SwingTwistConstraint* constraint)
{
	JPH_ASSERT(constraint);
	auto joltConstraint = reinterpret_cast<const JPH::SwingTwistConstraint*>(constraint);
	return joltConstraint->GetTotalLambdaSwingZ();
}

void JPH_SwingTwistConstraint_GetTotalLambdaMotor(const JPH_SwingTwistConstraint* constraint, JPH_Vec3* result)
{
	JPH_ASSERT(constraint);
	auto joltConstraint = reinterpret_cast<const JPH::SwingTwistConstraint*>(constraint);
	auto lambda = joltConstraint->GetTotalLambdaMotor();
	FromJolt(lambda, result);
}

/* JPH_SixDOFConstraintSettings */
void JPH_SixDOFConstraintSettings_FromJolt(JPH_SixDOFConstraintSettings* settings, const SixDOFConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	FromJolt(joltSettings.mPosition1, &settings->position1);
	FromJolt(joltSettings.mAxisX1, &settings->axisX1);
	FromJolt(joltSettings.mAxisY1, &settings->axisY1);
	FromJolt(joltSettings.mPosition2, &settings->position2);
	FromJolt(joltSettings.mAxisX2, &settings->axisX2);
	FromJolt(joltSettings.mAxisY2, &settings->axisY2);

	for (uint32_t i = 0; i < SixDOFConstraintSettings::EAxis::Num; ++i)
	{
		settings->maxFriction[i] = joltSettings.mMaxFriction[i];
		settings->limitMin[i] = joltSettings.mLimitMin[i];
		settings->limitMax[i] = joltSettings.mLimitMax[i];
		FromJolt(joltSettings.mMotorSettings[i], &settings->motorSettings[i]);
	}

	settings->swingType = static_cast<JPH_SwingType>(joltSettings.mSwingType);
	for (uint32_t i = 0; i < SixDOFConstraintSettings::EAxis::NumTranslation; ++i)
	{
		FromJolt(joltSettings.mLimitsSpringSettings[i], &settings->limitsSpringSettings[i]);
	}
}

void JPH_SixDOFConstraintSettings_ToJolt(SixDOFConstraintSettings* joltSettings, const JPH_SixDOFConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mPosition1 = ToJolt(settings->position1);
	joltSettings->mAxisX1 = ToJolt(settings->axisX1);
	joltSettings->mAxisY1 = ToJolt(settings->axisY1);
	joltSettings->mPosition2 = ToJolt(settings->position2);
	joltSettings->mAxisX2 = ToJolt(settings->axisX2);
	joltSettings->mAxisY2 = ToJolt(settings->axisY2);

	for (uint32_t i = 0; i < SixDOFConstraintSettings::EAxis::Num; ++i)
	{
		joltSettings->mMaxFriction[i] = settings->maxFriction[i];
		joltSettings->mLimitMin[i] = settings->limitMin[i];
		joltSettings->mLimitMax[i] = settings->limitMax[i];
		joltSettings->mMotorSettings[i] = ToJolt(&settings->motorSettings[i]);
	}

	joltSettings->mSwingType = static_cast<ESwingType>(settings->swingType);

	for (uint32_t i = 0; i < SixDOFConstraintSettings::EAxis::NumTranslation; ++i)
	{
		joltSettings->mLimitsSpringSettings[i] = ToJolt(&settings->limitsSpringSettings[i]);
	}
}

void JPH_SixDOFConstraintSettings_Init(JPH_SixDOFConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_SixDOFConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	SixDOFConstraintSettings joltSettings;
	JPH_SixDOFConstraintSettings_FromJolt(settings, joltSettings);
}

void JPH_SixDOFConstraintSettings_MakeFreeAxis(JPH_SixDOFConstraintSettings* settings, JPH_SixDOFConstraintAxis axis)
{
	settings->limitMin[axis] = -FLT_MAX;
	settings->limitMax[axis] = FLT_MAX;
}

bool JPH_SixDOFConstraintSettings_IsFreeAxis(const JPH_SixDOFConstraintSettings* settings, JPH_SixDOFConstraintAxis axis)
{
	return settings->limitMin[axis] == -FLT_MAX && settings->limitMax[axis] == FLT_MAX;
}

void JPH_SixDOFConstraintSettings_MakeFixedAxis(JPH_SixDOFConstraintSettings* settings, JPH_SixDOFConstraintAxis axis)
{
	settings->limitMin[axis] = FLT_MAX;
	settings->limitMax[axis] = -FLT_MAX;
}

bool JPH_SixDOFConstraintSettings_IsFixedAxis(const JPH_SixDOFConstraintSettings* settings, JPH_SixDOFConstraintAxis axis)
{
	return settings->limitMin[axis] >= settings->limitMax[axis];
}

void JPH_SixDOFConstraintSettings_SetLimitedAxis(JPH_SixDOFConstraintSettings* settings, JPH_SixDOFConstraintAxis axis, float min, float max)
{
	settings->limitMin[axis] = min;
	settings->limitMax[axis] = max;
}

JPH_SixDOFConstraint* JPH_SixDOFConstraint_Create(const JPH_SixDOFConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	SixDOFConstraintSettings joltSettings;
	JPH_SixDOFConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	SixDOFConstraint* constraint = static_cast<SixDOFConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToSixDOFConstraint(constraint);
}

void JPH_SixDOFConstraint_GetSettings(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintSettings* settings)
{
	Ref<SixDOFConstraintSettings> joltSettings = StaticCast<SixDOFConstraintSettings>(AsSixDOFConstraint(constraint)->GetConstraintSettings());
	JPH_SixDOFConstraintSettings_FromJolt(settings, *joltSettings);
}

float JPH_SixDOFConstraint_GetLimitsMin(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis)
{
	return AsSixDOFConstraint(constraint)->GetLimitsMin(static_cast<JPH::SixDOFConstraint::EAxis>(axis));
}

float JPH_SixDOFConstraint_GetLimitsMax(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis)
{
	return AsSixDOFConstraint(constraint)->GetLimitsMax(static_cast<JPH::SixDOFConstraint::EAxis>(axis));
}

void JPH_SixDOFConstraint_GetTotalLambdaPosition(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTotalLambdaPosition(), result);
}

void JPH_SixDOFConstraint_GetTotalLambdaRotation(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTotalLambdaRotation(), result);
}

void JPH_SixDOFConstraint_GetTotalLambdaMotorTranslation(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTotalLambdaMotorTranslation(), result);
}

void JPH_SixDOFConstraint_GetTotalLambdaMotorRotation(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTotalLambdaMotorRotation(), result);
}

void JPH_SixDOFConstraint_GetTranslationLimitsMin(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTranslationLimitsMin(), result);
}

void JPH_SixDOFConstraint_GetTranslationLimitsMax(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTranslationLimitsMax(), result);
}

void JPH_SixDOFConstraint_GetRotationLimitsMin(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetRotationLimitsMin(), result);
}

void JPH_SixDOFConstraint_GetRotationLimitsMax(const JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetRotationLimitsMax(), result);
}

bool JPH_SixDOFConstraint_IsFixedAxis(const JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis)
{
	return AsSixDOFConstraint(constraint)->IsFixedAxis(static_cast<JPH::SixDOFConstraint::EAxis>(axis));
}

bool JPH_SixDOFConstraint_IsFreeAxis(const JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis)
{
	return AsSixDOFConstraint(constraint)->IsFreeAxis(static_cast<JPH::SixDOFConstraint::EAxis>(axis));
}

void JPH_SixDOFConstraint_GetLimitsSpringSettings(JPH_SixDOFConstraint* constraint, JPH_SpringSettings* result, JPH_SixDOFConstraintAxis axis)
{
	auto joltConstraint = reinterpret_cast<JPH::SixDOFConstraint*>(constraint);
	FromJolt(joltConstraint->GetLimitsSpringSettings(static_cast<JPH::SixDOFConstraint::EAxis>(axis)), result);
}

void JPH_SixDOFConstraint_SetLimitsSpringSettings(JPH_SixDOFConstraint* constraint, JPH_SpringSettings* settings, JPH_SixDOFConstraintAxis axis)
{
	auto joltConstraint = reinterpret_cast<JPH::SixDOFConstraint*>(constraint);
	joltConstraint->SetLimitsSpringSettings(static_cast<JPH::SixDOFConstraint::EAxis>(axis), ToJolt(settings));
}

void JPH_SixDOFConstraint_SetMaxFriction(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis, float inFriction)
{
	AsSixDOFConstraint(constraint)->SetMaxFriction(static_cast<JPH::SixDOFConstraint::EAxis>(axis), inFriction);
}

float JPH_SixDOFConstraint_GetMaxFriction(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis)
{
	return AsSixDOFConstraint(constraint)->GetMaxFriction(static_cast<JPH::SixDOFConstraint::EAxis>(axis));
}

void JPH_SixDOFConstraint_GetRotationInConstraintSpace(JPH_SixDOFConstraint* constraint, JPH_Quat* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetRotationInConstraintSpace(), result);
}

void JPH_SixDOFConstraint_GetMotorSettings(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis, JPH_MotorSettings* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetMotorSettings(static_cast<JPH::SixDOFConstraint::EAxis>(axis)), result);
}

void JPH_SixDOFConstraint_SetMotorState(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis, JPH_MotorState state)
{
	AsSixDOFConstraint(constraint)->SetMotorState(static_cast<JPH::SixDOFConstraint::EAxis>(axis), static_cast<JPH::EMotorState>(state));
}

JPH_MotorState JPH_SixDOFConstraint_GetMotorState(JPH_SixDOFConstraint* constraint, JPH_SixDOFConstraintAxis axis)
{
	return static_cast<JPH_MotorState>(AsSixDOFConstraint(constraint)->GetMotorState(static_cast<JPH::SixDOFConstraint::EAxis>(axis)));
}

void JPH_SixDOFConstraint_SetTargetVelocityCS(JPH_SixDOFConstraint* constraint, JPH_Vec3* inVelocity)
{
	AsSixDOFConstraint(constraint)->SetTargetVelocityCS(ToJolt(inVelocity));
}

void JPH_SixDOFConstraint_GetTargetVelocityCS(JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTargetVelocityCS(), result);
}

void JPH_SixDOFConstraint_SetTargetAngularVelocityCS(JPH_SixDOFConstraint* constraint, JPH_Vec3* inAngularVelocity)
{
	AsSixDOFConstraint(constraint)->SetTargetAngularVelocityCS(ToJolt(inAngularVelocity));
}

void JPH_SixDOFConstraint_GetTargetAngularVelocityCS(JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTargetAngularVelocityCS(), result);
}

void JPH_SixDOFConstraint_SetTargetPositionCS(JPH_SixDOFConstraint* constraint, JPH_Vec3* inPosition)
{
	AsSixDOFConstraint(constraint)->SetTargetPositionCS(ToJolt(inPosition));
}

void JPH_SixDOFConstraint_GetTargetPositionCS(JPH_SixDOFConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTargetPositionCS(), result);
}

void JPH_SixDOFConstraint_SetTargetOrientationCS(JPH_SixDOFConstraint* constraint, JPH_Quat* inOrientation)
{
	AsSixDOFConstraint(constraint)->SetTargetOrientationCS(ToJolt(inOrientation));
}

void JPH_SixDOFConstraint_GetTargetOrientationCS(JPH_SixDOFConstraint* constraint, JPH_Quat* result)
{
	FromJolt(AsSixDOFConstraint(constraint)->GetTargetOrientationCS(), result);
}

void JPH_SixDOFConstraint_SetTargetOrientationBS(JPH_SixDOFConstraint* constraint, JPH_Quat* inOrientation)
{
	AsSixDOFConstraint(constraint)->SetTargetOrientationBS(ToJolt(inOrientation));
}

/* JPH_GearConstraint */
void JPH_GearConstraintSettings_FromJolt(JPH_GearConstraintSettings* settings, const GearConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	settings->space = static_cast<JPH_ConstraintSpace>(joltSettings.mSpace);
	FromJolt(joltSettings.mHingeAxis1, &settings->hingeAxis1);
	FromJolt(joltSettings.mHingeAxis2, &settings->hingeAxis2);
	settings->ratio = joltSettings.mRatio;
}

void JPH_GearConstraintSettings_ToJolt(GearConstraintSettings* joltSettings, const JPH_GearConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mSpace = static_cast<EConstraintSpace>(settings->space);
	joltSettings->mHingeAxis1 = ToJolt(settings->hingeAxis1);
	joltSettings->mHingeAxis2 = ToJolt(settings->hingeAxis2);
	joltSettings->mRatio = settings->ratio;
}

JPH_CAPI void JPH_GearConstraintSettings_Init(JPH_GearConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_GearConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	GearConstraintSettings joltSettings;
	JPH_GearConstraintSettings_FromJolt(settings, joltSettings);
}

JPH_GearConstraint* JPH_GearConstraint_Create(const JPH_GearConstraintSettings* settings, JPH_Body* body1, JPH_Body* body2)
{
	GearConstraintSettings joltSettings;
	JPH_GearConstraintSettings_ToJolt(&joltSettings, settings);

	JPH::Body* joltBody1 = reinterpret_cast<JPH::Body*>(body1);
	JPH::Body* joltBody2 = reinterpret_cast<JPH::Body*>(body2);

	GearConstraint* constraint = static_cast<GearConstraint*>(joltSettings.Create(*joltBody1, *joltBody2));
	if (!constraint)
	{
		return nullptr;
	}

	constraint->AddRef();
	return ToGearConstraint(constraint);
}

void JPH_GearConstraint_GetSettings(JPH_GearConstraint* constraint, JPH_GearConstraintSettings* settings)
{
	Ref<GearConstraintSettings> joltSettings = StaticCast<GearConstraintSettings>(AsGearConstraint(constraint)->GetConstraintSettings());
	JPH_GearConstraintSettings_FromJolt(settings, *joltSettings);
}

void JPH_GearConstraint_SetConstraints(JPH_GearConstraint* constraint, const JPH_Constraint* gear1, const JPH_Constraint* gear2)
{
	AsGearConstraint(constraint)->SetConstraints(AsConstraint(gear1), AsConstraint(gear2));
}

float JPH_GearConstraint_GetTotalLambda(const JPH_GearConstraint* constraint)
{
	return AsGearConstraint(constraint)->GetTotalLambda();
}

/* JPH_MotionProperties */
JPH_AllowedDOFs JPH_MotionProperties_GetAllowedDOFs(const JPH_MotionProperties* properties)
{
	return static_cast<JPH_AllowedDOFs>(reinterpret_cast<const JPH::MotionProperties*>(properties)->GetAllowedDOFs());
}

void JPH_MotionProperties_SetLinearDamping(JPH_MotionProperties* properties, float damping)
{
	reinterpret_cast<JPH::MotionProperties*>(properties)->SetLinearDamping(damping);
}

float JPH_MotionProperties_GetLinearDamping(const JPH_MotionProperties* properties)
{
	return reinterpret_cast<const JPH::MotionProperties*>(properties)->GetLinearDamping();
}

void JPH_MotionProperties_SetAngularDamping(JPH_MotionProperties* properties, float damping)
{
	reinterpret_cast<JPH::MotionProperties*>(properties)->SetAngularDamping(damping);
}

float JPH_MotionProperties_GetAngularDamping(const JPH_MotionProperties* properties)
{
	return reinterpret_cast<const JPH::MotionProperties*>(properties)->GetAngularDamping();
}

void JPH_MotionProperties_SetMassProperties(JPH_MotionProperties* properties, JPH_AllowedDOFs allowedDOFs, const JPH_MassProperties* massProperties)
{
	reinterpret_cast<JPH::MotionProperties*>(properties)->SetMassProperties(
		static_cast<EAllowedDOFs>(allowedDOFs),
		ToJolt(massProperties));
}

float JPH_MotionProperties_GetInverseMassUnchecked(JPH_MotionProperties* properties)
{
	return reinterpret_cast<JPH::MotionProperties*>(properties)->GetInverseMassUnchecked();
}

void JPH_MotionProperties_SetInverseMass(JPH_MotionProperties* properties, float inverseMass)
{
	reinterpret_cast<JPH::MotionProperties*>(properties)->SetInverseMass(inverseMass);
}

void JPH_MotionProperties_GetInverseInertiaDiagonal(JPH_MotionProperties* properties, JPH_Vec3* result)
{
	FromJolt(reinterpret_cast<JPH::MotionProperties*>(properties)->GetInverseInertiaDiagonal(), result);
}

void JPH_MotionProperties_GetInertiaRotation(JPH_MotionProperties* properties, JPH_Quat* result)
{
	FromJolt(reinterpret_cast<JPH::MotionProperties*>(properties)->GetInertiaRotation(), result);
}

void JPH_MotionProperties_SetInverseInertia(JPH_MotionProperties* properties, JPH_Vec3* diagonal, JPH_Quat* rot)
{
	reinterpret_cast<JPH::MotionProperties*>(properties)->SetInverseInertia(ToJolt(diagonal), ToJolt(rot));
}

void JPH_MotionProperties_ScaleToMass(JPH_MotionProperties* properties, float mass)
{
	reinterpret_cast<JPH::MotionProperties*>(properties)->ScaleToMass(mass);
}

const JPH_BroadPhaseQuery* JPH_PhysicsSystem_GetBroadPhaseQuery(const JPH_PhysicsSystem* system)
{
	JPH_ASSERT(system);

	return reinterpret_cast<const JPH_BroadPhaseQuery*>(&system->physicsSystem->GetBroadPhaseQuery());
}

const JPH_NarrowPhaseQuery* JPH_PhysicsSystem_GetNarrowPhaseQuery(const JPH_PhysicsSystem* system)
{
	JPH_ASSERT(system);

	return reinterpret_cast<const JPH_NarrowPhaseQuery*>(&system->physicsSystem->GetNarrowPhaseQuery());
}
const JPH_NarrowPhaseQuery* JPH_PhysicsSystem_GetNarrowPhaseQueryNoLock(const JPH_PhysicsSystem* system)
{
	JPH_ASSERT(system);

	return reinterpret_cast<const JPH_NarrowPhaseQuery*>(&system->physicsSystem->GetNarrowPhaseQueryNoLock());
}

void JPH_PhysicsSystem_SetContactListener(JPH_PhysicsSystem* system, JPH_ContactListener* listener)
{
	JPH_ASSERT(system);

	auto joltListener = reinterpret_cast<JPH::ContactListener*>(listener);
	system->physicsSystem->SetContactListener(joltListener);
}

void JPH_PhysicsSystem_SetBodyActivationListener(JPH_PhysicsSystem* system, JPH_BodyActivationListener* listener)
{
	JPH_ASSERT(system);

	auto joltListener = reinterpret_cast<JPH::BodyActivationListener*>(listener);
	system->physicsSystem->SetBodyActivationListener(joltListener);
}

void JPH_PhysicsSystem_SetSimShapeFilter(JPH_PhysicsSystem* system, const JPH_SimShapeFilter* filter)
{
	JPH_ASSERT(system);

	auto joltFilter = reinterpret_cast<const JPH::SimShapeFilter*>(filter);
	system->physicsSystem->SetSimShapeFilter(joltFilter);
}

bool JPH_PhysicsSystem_WereBodiesInContact(const JPH_PhysicsSystem* system, JPH_BodyID body1, JPH_BodyID body2)
{
	JPH_ASSERT(system);

	return system->physicsSystem->WereBodiesInContact(JPH::BodyID(body1), JPH::BodyID(body2));
}

uint32_t JPH_PhysicsSystem_GetNumBodies(const JPH_PhysicsSystem* system)
{
	JPH_ASSERT(system);

	return system->physicsSystem->GetNumBodies();
}

uint32_t JPH_PhysicsSystem_GetNumActiveBodies(const JPH_PhysicsSystem* system, JPH_BodyType type)
{
	JPH_ASSERT(system);

	return system->physicsSystem->GetNumActiveBodies(static_cast<JPH::EBodyType>(type));
}

uint32_t JPH_PhysicsSystem_GetMaxBodies(const JPH_PhysicsSystem* system)
{
	JPH_ASSERT(system);

	return system->physicsSystem->GetMaxBodies();
}

uint32_t JPH_PhysicsSystem_GetNumConstraints(const JPH_PhysicsSystem* system)
{
	JPH_ASSERT(system);

	return (uint32_t)system->physicsSystem->GetConstraints().size();
}

void JPH_PhysicsSystem_SetGravity(JPH_PhysicsSystem* system, const JPH_Vec3* value)
{
	JPH_ASSERT(system);

	system->physicsSystem->SetGravity(ToJolt(value));
}

void JPH_PhysicsSystem_GetGravity(JPH_PhysicsSystem* system, JPH_Vec3* result)
{
	JPH_ASSERT(system);

	auto joltVector = system->physicsSystem->GetGravity();
	FromJolt(joltVector, result);
}

void JPH_PhysicsSystem_AddConstraint(JPH_PhysicsSystem* system, JPH_Constraint* constraint)
{
	JPH_ASSERT(system);
	JPH_ASSERT(constraint);

	auto joltConstraint = reinterpret_cast<JPH::Constraint*>(constraint);
	system->physicsSystem->AddConstraint(joltConstraint);
}

void JPH_PhysicsSystem_RemoveConstraint(JPH_PhysicsSystem* system, JPH_Constraint* constraint)
{
	JPH_ASSERT(system);
	JPH_ASSERT(constraint);

	auto joltConstraint = reinterpret_cast<JPH::Constraint*>(constraint);
	system->physicsSystem->RemoveConstraint(joltConstraint);
}

void JPH_PhysicsSystem_AddConstraints(JPH_PhysicsSystem* system, JPH_Constraint** constraints, uint32_t count)
{
	JPH_ASSERT(system);
	JPH_ASSERT(constraints);
	JPH_ASSERT(count > 0);

	Array<Constraint*> joltConstraints;
	joltConstraints.reserve(count);
	for (uint32_t i = 0; i < count; ++i)
	{
		auto joltConstraint = reinterpret_cast<JPH::Constraint*>(constraints[i]);
		joltConstraints.push_back(joltConstraint);
	}

	system->physicsSystem->AddConstraints(joltConstraints.data(), (int)count);
}

void JPH_PhysicsSystem_RemoveConstraints(JPH_PhysicsSystem* system, JPH_Constraint** constraints, uint32_t count)
{
	JPH_ASSERT(system);
	JPH_ASSERT(constraints);
	JPH_ASSERT(count > 0);

	Array<Constraint*> joltConstraints;
	joltConstraints.reserve(count);
	for (uint32_t i = 0; i < count; ++i)
	{
		auto joltConstraint = reinterpret_cast<JPH::Constraint*>(constraints[i]);
		joltConstraints.push_back(joltConstraint);
	}

	system->physicsSystem->RemoveConstraints(joltConstraints.data(), (int)count);
}

void JPH_PhysicsSystem_AddStepListener(JPH_PhysicsSystem* system, JPH_PhysicsStepListener* listener)
{
	JPH_ASSERT(system);
	JPH_ASSERT(listener);

	system->physicsSystem->AddStepListener(AsPhysicsStepListener(listener));
}

void JPH_PhysicsSystem_RemoveStepListener(JPH_PhysicsSystem* system, JPH_PhysicsStepListener* listener)
{
	JPH_ASSERT(system);
	JPH_ASSERT(listener);

	system->physicsSystem->RemoveStepListener(AsPhysicsStepListener(listener));
}

void JPH_PhysicsSystem_GetBodies(const JPH_PhysicsSystem* system, JPH_BodyID* ids, uint32_t count)
{
	JPH_ASSERT(system);
	JPH_ASSERT(ids);

	JPH::BodyIDVector bodies;
	system->physicsSystem->GetBodies(bodies);

	const uint32_t copyCount = std::min(count, (uint32_t)bodies.size());
	for (uint32_t i = 0; i < count; i++)
	{
		ids[i] = bodies[i].GetIndexAndSequenceNumber();
	}
}

JPH_CAPI void JPH_PhysicsSystem_GetActiveBodies(const JPH_PhysicsSystem* system, JPH_BodyType type, JPH_BodyID* ids, uint32_t count)
{
	JPH::BodyIDVector activeBodies;
	system->physicsSystem->GetActiveBodies(static_cast<JPH::EBodyType>(type), activeBodies);

	const uint32_t copyCount = std::min(count, (uint32_t)activeBodies.size());
	for (uint32_t i = 0; i < copyCount; i++)
	{
		ids[i] = activeBodies[i].GetIndexAndSequenceNumber();
	}
}

JPH_CAPI const JPH_BodyID* JPH_PhysicsSystem_GetActiveBodiesUnsafe(const JPH_PhysicsSystem* system, JPH_BodyType type)
{
	// Returns a direct pointer to Jolt's internal BodyID array
	return reinterpret_cast<const JPH_BodyID*>(system->physicsSystem->GetActiveBodiesUnsafe(static_cast<JPH::EBodyType>(type)));
}

void JPH_PhysicsSystem_GetConstraints(const JPH_PhysicsSystem* system, const JPH_Constraint** constraints, uint32_t count)
{
	JPH_ASSERT(constraints);

	JPH::Constraints list = system->physicsSystem->GetConstraints();

	for (uint32_t i = 0; i < count && i < list.size(); i++)
	{
		constraints[i] = ToConstraint(list[i].GetPtr());
	}
}

void JPH_PhysicsSystem_ActivateBodiesInAABox(JPH_PhysicsSystem* system, const JPH_AABox* box, JPH_ObjectLayer layer)
{
	auto joltLayer = static_cast<JPH::ObjectLayer>(layer);

	system->physicsSystem->GetBodyInterface().ActivateBodiesInAABox(
		ToJolt(box),
		system->physicsSystem->GetDefaultBroadPhaseLayerFilter(joltLayer),
		system->physicsSystem->GetDefaultLayerFilter(joltLayer)
	);
}

#ifdef JPH_DEBUG_RENDERER
static inline BodyManager::DrawSettings ToJolt(const JPH_DrawSettings* settings)
{
	BodyManager::DrawSettings result{};
	if (!settings)
		return result;
	result.mDrawGetSupportFunction = settings->drawGetSupportFunction;
	result.mDrawSupportDirection = settings->drawSupportDirection;
	result.mDrawGetSupportingFace = settings->drawGetSupportingFace;
	result.mDrawShape = settings->drawShape;
	result.mDrawShapeWireframe = settings->drawShapeWireframe;
	result.mDrawShapeColor = static_cast<BodyManager::EShapeColor>(settings->drawShapeColor);
	result.mDrawBoundingBox = settings->drawBoundingBox;
	result.mDrawCenterOfMassTransform = settings->drawCenterOfMassTransform;
	result.mDrawWorldTransform = settings->drawWorldTransform;
	result.mDrawVelocity = settings->drawVelocity;
	result.mDrawMassAndInertia = settings->drawMassAndInertia;
	result.mDrawSleepStats = settings->drawSleepStats;
	result.mDrawSoftBodyVertices = settings->drawSoftBodyVertices;
	result.mDrawSoftBodyVertexVelocities = settings->drawSoftBodyVertexVelocities;
	result.mDrawSoftBodyEdgeConstraints = settings->drawSoftBodyEdgeConstraints;
	result.mDrawSoftBodyBendConstraints = settings->drawSoftBodyBendConstraints;
	result.mDrawSoftBodyVolumeConstraints = settings->drawSoftBodyVolumeConstraints;
	result.mDrawSoftBodySkinConstraints = settings->drawSoftBodySkinConstraints;
	result.mDrawSoftBodyLRAConstraints = settings->drawSoftBodyLRAConstraints;
	result.mDrawSoftBodyPredictedBounds = settings->drawSoftBodyPredictedBounds;
	result.mDrawSoftBodyConstraintColor = static_cast<ESoftBodyConstraintColor>(settings->drawSoftBodyConstraintColor);
	return result;
}

void JPH_PhysicsSystem_DrawBodies(JPH_PhysicsSystem* system, const JPH_DrawSettings* settings, JPH_DebugRenderer* renderer, const JPH_BodyDrawFilter* bodyFilter)
{
	BodyManager::DrawSettings joltSettings = ToJolt(settings);
	const BodyDrawFilter* bodyDrawFilter = (bodyFilter != nullptr) ? (reinterpret_cast<const BodyDrawFilter*>(bodyFilter)) : nullptr;
	system->physicsSystem->DrawBodies(joltSettings, reinterpret_cast<DebugRenderer*>(renderer), bodyDrawFilter);
}

void JPH_PhysicsSystem_DrawConstraints(JPH_PhysicsSystem* system, JPH_DebugRenderer* renderer)
{
	system->physicsSystem->DrawConstraints(reinterpret_cast<DebugRenderer*>(renderer));
}

void JPH_PhysicsSystem_DrawConstraintLimits(JPH_PhysicsSystem* system, JPH_DebugRenderer* renderer)
{
	system->physicsSystem->DrawConstraintLimits(reinterpret_cast<DebugRenderer*>(renderer));
}

void JPH_PhysicsSystem_DrawConstraintReferenceFrame(JPH_PhysicsSystem* system, JPH_DebugRenderer* renderer)
{
	system->physicsSystem->DrawConstraintReferenceFrame(reinterpret_cast<DebugRenderer*>(renderer));
}
#endif

/* PhysicsStepListener */
class ManagedPhysicsStepListener final : public JPH::PhysicsStepListener
{
public:
	static const JPH_PhysicsStepListener_Procs* s_Procs;
	void* userData = nullptr;

	ManagedPhysicsStepListener(void* userData_)
		: userData(userData_)
	{

	}

	void OnStep(const PhysicsStepListenerContext& inContext) override
	{
		if (s_Procs != nullptr
			&& s_Procs->OnStep)
		{
			JPH_PhysicsStepListenerContext context{};
			context.deltaTime = inContext.mDeltaTime;
			context.isFirstStep = inContext.mIsFirstStep;
			context.isLastStep = inContext.mIsLastStep;
			context.physicsSystem = s_PhysicsSystems[inContext.mPhysicsSystem];
			return s_Procs->OnStep(userData, &context);
		}
	}
};

const JPH_PhysicsStepListener_Procs* ManagedPhysicsStepListener::s_Procs = nullptr;

void JPH_PhysicsStepListener_SetProcs(const JPH_PhysicsStepListener_Procs* procs)
{
	ManagedPhysicsStepListener::s_Procs = procs;
}

JPH_PhysicsStepListener* JPH_PhysicsStepListener_Create(void* userData)
{
	auto listener = new ManagedPhysicsStepListener(userData);
	return ToPhysicsStepListener(listener);
}

void JPH_PhysicsStepListener_Destroy(JPH_PhysicsStepListener* listener)
{
	if (listener)
	{
		delete reinterpret_cast<ManagedPhysicsStepListener*>(listener);
	}
}

JPH_Body* JPH_BodyInterface_CreateBody(JPH_BodyInterface* bodyInterface, const JPH_BodyCreationSettings* settings)
{
	auto body = AsBodyInterface(bodyInterface)->CreateBody(*AsBodyCreationSettings(settings));
	return ToBody(body);
}

JPH_Body* JPH_BodyInterface_CreateBodyWithID(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, const JPH_BodyCreationSettings* settings)
{
	auto body = AsBodyInterface(bodyInterface)->CreateBodyWithID(
		JPH::BodyID(bodyID),
		*AsBodyCreationSettings(settings)
	);
	return ToBody(body);
}

JPH_Body* JPH_BodyInterface_CreateBodyWithoutID(JPH_BodyInterface* bodyInterface, const JPH_BodyCreationSettings* settings)
{
	auto body = AsBodyInterface(bodyInterface)->CreateBodyWithoutID(*AsBodyCreationSettings(settings));
	return ToBody(body);
}

void JPH_BodyInterface_DestroyBodyWithoutID(JPH_BodyInterface* bodyInterface, JPH_Body* body)
{
	AsBodyInterface(bodyInterface)->DestroyBodyWithoutID(AsBody(body));
}

bool JPH_BodyInterface_AssignBodyID(JPH_BodyInterface* bodyInterface, JPH_Body* body)
{
	return AsBodyInterface(bodyInterface)->AssignBodyID(AsBody(body));
}

bool JPH_BodyInterface_AssignBodyID2(JPH_BodyInterface* bodyInterface, JPH_Body* body, JPH_BodyID bodyID)
{
	return AsBodyInterface(bodyInterface)->AssignBodyID(AsBody(body), JPH::BodyID(bodyID));
}

JPH_Body* JPH_BodyInterface_UnassignBodyID(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	auto body = AsBodyInterface(bodyInterface)->UnassignBodyID(JPH::BodyID(bodyID));
	return ToBody(body);
}

JPH_BodyID JPH_BodyInterface_CreateAndAddBody(JPH_BodyInterface* bodyInterface, const JPH_BodyCreationSettings* settings, JPH_Activation activationMode)
{
	JPH::BodyID bodyID = AsBodyInterface(bodyInterface)->CreateAndAddBody(
		*reinterpret_cast<const JPH::BodyCreationSettings*>(settings),
		(JPH::EActivation)activationMode
	);

	return bodyID.GetIndexAndSequenceNumber();
}

void JPH_BodyInterface_DestroyBody(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	AsBodyInterface(bodyInterface)->DestroyBody(JPH::BodyID(bodyID));
}

JPH_Body* JPH_BodyInterface_CreateSoftBody(JPH_BodyInterface* bodyInterface, const JPH_SoftBodyCreationSettings* settings)
{
	JPH::Body* body = AsBodyInterface(bodyInterface)->CreateSoftBody(*AsSoftBodyCreationSettings(settings));
	return ToBody(body);
}

JPH_Body* JPH_BodyInterface_CreateSoftBodyWithID(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, const JPH_SoftBodyCreationSettings* settings)
{
	JPH::Body* body = AsBodyInterface(bodyInterface)->CreateSoftBodyWithID(JPH::BodyID(bodyID), *AsSoftBodyCreationSettings(settings));
	return ToBody(body);
}

JPH_Body* JPH_BodyInterface_CreateSoftBodyWithoutID(JPH_BodyInterface* bodyInterface, const JPH_SoftBodyCreationSettings* settings)
{
	JPH::Body* body = AsBodyInterface(bodyInterface)->CreateSoftBodyWithoutID(*AsSoftBodyCreationSettings(settings));
	return ToBody(body);
}

JPH_BodyID JPH_BodyInterface_CreateAndAddSoftBody(JPH_BodyInterface* bodyInterface, const JPH_SoftBodyCreationSettings* settings, JPH_Activation activationMode)
{
	JPH::BodyID bodyID = AsBodyInterface(bodyInterface)->CreateAndAddSoftBody(
		*AsSoftBodyCreationSettings(settings),
		static_cast<JPH::EActivation>(activationMode)
	);
	return bodyID.GetIndexAndSequenceNumber();
}

void JPH_BodyInterface_AddBody(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, JPH_Activation activationMode)
{
	JPH::BodyID joltBodyID(bodyID);
	JPH_ASSERT(!joltBodyID.IsInvalid());

	AsBodyInterface(bodyInterface)->AddBody(joltBodyID, (JPH::EActivation)activationMode);
}

void JPH_BodyInterface_RemoveBody(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	JPH::BodyID joltBodyID(bodyID);
	JPH_ASSERT(!joltBodyID.IsInvalid());

	AsBodyInterface(bodyInterface)->RemoveBody(joltBodyID);
}

void JPH_BodyInterface_RemoveAndDestroyBody(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	JPH::BodyID joltBodyID(bodyID);
	JPH_ASSERT(!joltBodyID.IsInvalid());

	AsBodyInterface(bodyInterface)->RemoveBody(joltBodyID);
	AsBodyInterface(bodyInterface)->DestroyBody(joltBodyID);
}

bool JPH_BodyInterface_IsAdded(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	return AsBodyInterface(bodyInterface)->IsAdded(JPH::BodyID(bodyID));
}

JPH_CAPI const JPH_Body* JPH_PhysicsSystem_GetBodyPtr(const JPH_PhysicsSystem* system, JPH_BodyID bodyID)
{
	return reinterpret_cast<const JPH_Body*>(system->physicsSystem->GetBodyLockInterface().TryGetBody(JPH::BodyID(bodyID)));
}

JPH_BodyType JPH_BodyInterface_GetBodyType(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	return static_cast<JPH_BodyType>(AsBodyInterface(bodyInterface)->GetBodyType(JPH::BodyID(bodyID)));
}

void JPH_BodyInterface_SetLinearVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, const JPH_Vec3* velocity)
{
	AsBodyInterface(bodyInterface)->SetLinearVelocity(JPH::BodyID(bodyID), ToJolt(velocity));
}

void JPH_BodyInterface_GetLinearVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, JPH_Vec3* velocity)
{
	auto joltVector = AsBodyInterface(bodyInterface)->GetLinearVelocity(JPH::BodyID(bodyID));
	FromJolt(joltVector, velocity);
}

void JPH_BodyInterface_GetCenterOfMassPosition(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, JPH_RVec3* position)
{
	auto joltVector = AsBodyInterface(bodyInterface)->GetCenterOfMassPosition(JPH::BodyID(bodyID));
	FromJolt(joltVector, position);
}

JPH_MotionType JPH_BodyInterface_GetMotionType(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	return static_cast<JPH_MotionType>(AsBodyInterface(bodyInterface)->GetMotionType(JPH::BodyID(bodyID)));
}

void JPH_BodyInterface_SetMotionType(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, JPH_MotionType motionType, JPH_Activation activationMode)
{
	AsBodyInterface(bodyInterface)->SetMotionType(
		JPH::BodyID(bodyID),
		static_cast<JPH::EMotionType>(motionType),
		static_cast<JPH::EActivation>(activationMode)
	);
}

float JPH_BodyInterface_GetRestitution(const JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	return AsBodyInterface(bodyInterface)->GetRestitution(JPH::BodyID(bodyID));
}

void JPH_BodyInterface_SetRestitution(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, float restitution)
{
	AsBodyInterface(bodyInterface)->SetRestitution(JPH::BodyID(bodyID), restitution);
}

float JPH_BodyInterface_GetFriction(const JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID)
{
	return AsBodyInterface(bodyInterface)->GetFriction(JPH::BodyID(bodyID));
}

void JPH_BodyInterface_SetFriction(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyID, float friction)
{
	AsBodyInterface(bodyInterface)->SetFriction(JPH::BodyID(bodyID), friction);
}

void JPH_BodyInterface_SetPosition(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RVec3* position, JPH_Activation activationMode)
{
	AsBodyInterface(bodyInterface)->SetPosition(JPH::BodyID(bodyId), ToJolt(position), static_cast<JPH::EActivation>(activationMode));
}

void JPH_BodyInterface_GetPosition(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RVec3* result)
{
	FromJolt(AsBodyInterface(bodyInterface)->GetPosition(JPH::BodyID(bodyId)), result);
}

void JPH_BodyInterface_SetRotation(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Quat* rotation, JPH_Activation activationMode)
{
	AsBodyInterface(bodyInterface)->SetRotation(JPH::BodyID(bodyId), ToJolt(rotation), static_cast<JPH::EActivation>(activationMode));
}

void JPH_BodyInterface_GetRotation(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Quat* result)
{
	FromJolt(AsBodyInterface(bodyInterface)->GetRotation(JPH::BodyID(bodyId)), result);
}

void JPH_BodyInterface_SetPositionAndRotation(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, const JPH_RVec3* position, const JPH_Quat* rotation, JPH_Activation activationMode)
{
	AsBodyInterface(bodyInterface)->SetPositionAndRotation(JPH::BodyID(bodyId), ToJolt(position), ToJolt(rotation), static_cast<JPH::EActivation>(activationMode));
}

void JPH_BodyInterface_SetPositionAndRotationWhenChanged(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, const JPH_RVec3* position, const JPH_Quat* rotation, JPH_Activation activationMode)
{
	AsBodyInterface(bodyInterface)->SetPositionAndRotationWhenChanged(JPH::BodyID(bodyId), ToJolt(position), ToJolt(rotation), static_cast<JPH::EActivation>(activationMode));
}

void JPH_BodyInterface_GetPositionAndRotation(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RVec3* position, JPH_Quat* rotation)
{
	JPH::RVec3 joltPosition;
	JPH::Quat joltRotation;
	AsBodyInterface(bodyInterface)->GetPositionAndRotation(JPH::BodyID(bodyId), joltPosition, joltRotation);
	FromJolt(joltPosition, position);
	FromJolt(joltRotation, rotation);
}

void JPH_BodyInterface_SetPositionRotationAndVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RVec3* position, JPH_Quat* rotation, JPH_Vec3* linearVelocity, JPH_Vec3* angularVelocity)
{
	AsBodyInterface(bodyInterface)->SetPositionRotationAndVelocity(JPH::BodyID(bodyId), ToJolt(position), ToJolt(rotation), ToJolt(linearVelocity), ToJolt(angularVelocity));
}

void JPH_BodyInterface_GetCollisionGroup(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_CollisionGroup* result)
{
	FromJolt(AsBodyInterface(bodyInterface)->GetCollisionGroup(JPH::BodyID(bodyId)), result);
}

void JPH_BodyInterface_SetCollisionGroup(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, const JPH_CollisionGroup* group)
{
	AsBodyInterface(bodyInterface)->SetCollisionGroup(JPH::BodyID(bodyId), ToJolt(group));
}

const JPH_Shape* JPH_BodyInterface_GetShape(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	const JPH::Shape* shape = AsBodyInterface(bodyInterface)->GetShape(JPH::BodyID(bodyId)).GetPtr();
	return ToShape(shape);
}

void JPH_BodyInterface_SetShape(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, const JPH_Shape* shape, bool updateMassProperties, JPH_Activation activationMode)
{
	AsBodyInterface(bodyInterface)->SetShape(JPH::BodyID(bodyId), AsShape(shape), updateMassProperties, static_cast<JPH::EActivation>(activationMode));
}

void JPH_BodyInterface_NotifyShapeChanged(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* previousCenterOfMass, bool updateMassProperties, JPH_Activation activationMode)
{
	AsBodyInterface(bodyInterface)->NotifyShapeChanged(JPH::BodyID(bodyId), ToJolt(previousCenterOfMass), updateMassProperties, static_cast<JPH::EActivation>(activationMode));
}

void JPH_BodyInterface_ActivateBody(JPH_BodyInterface* bodyInterface, const JPH_BodyID bodyId)
{
	AsBodyInterface(bodyInterface)->ActivateBody(JPH::BodyID(bodyId));
}

void JPH_BodyInterface_ActivateBodies(JPH_BodyInterface* bodyInterface, const JPH_BodyID* bodyIDs, uint32_t count)
{
	Array<BodyID> joltBodyIDs;

	for (uint32_t i = 0; i < count; ++i)
	{
		joltBodyIDs.push_back(JPH::BodyID(bodyIDs[i]));
	}

	AsBodyInterface(bodyInterface)->ActivateBodies(joltBodyIDs.data(), count);
}

void JPH_BodyInterface_ActivateBodiesInAABox(JPH_BodyInterface* bodyInterface, const JPH_AABox* box, const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter, const JPH_ObjectLayerFilter* objectLayerFilter)
{
	AsBodyInterface(bodyInterface)->ActivateBodiesInAABox(
		ToJolt(box),
		ToJolt(broadPhaseLayerFilter),
		ToJolt(objectLayerFilter)
	);
}

void JPH_BodyInterface_DeactivateBody(JPH_BodyInterface* bodyInterface, const JPH_BodyID bodyId)
{
	AsBodyInterface(bodyInterface)->DeactivateBody(JPH::BodyID(bodyId));
}

void JPH_BodyInterface_DeactivateBodies(JPH_BodyInterface* bodyInterface, const JPH_BodyID* bodyIDs, uint32_t count)
{
	Array<BodyID> joltBodyIDs;

	for (uint32_t i = 0; i < count; ++i)
	{
		joltBodyIDs.push_back(JPH::BodyID(bodyIDs[i]));
	}

	AsBodyInterface(bodyInterface)->DeactivateBodies(joltBodyIDs.data(), count);
}

bool JPH_BodyInterface_IsActive(const JPH_BodyInterface* bodyInterface, const JPH_BodyID bodyID)
{
	return AsBodyInterface(bodyInterface)->IsActive(JPH::BodyID(bodyID));
}

void JPH_BodyInterface_ResetSleepTimer(JPH_BodyInterface* bodyInterface, const JPH_BodyID bodyID)
{
	AsBodyInterface(bodyInterface)->ResetSleepTimer(JPH::BodyID(bodyID));
}

JPH_ObjectLayer JPH_BodyInterface_GetObjectLayer(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	return AsBodyInterface(bodyInterface)->GetObjectLayer(JPH::BodyID(bodyId));
}

void JPH_BodyInterface_SetObjectLayer(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_ObjectLayer layer)
{
	AsBodyInterface(bodyInterface)->SetObjectLayer(JPH::BodyID(bodyId), layer);
}

void JPH_BodyInterface_GetWorldTransform(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RMat4* result)
{
	const JPH::RMat44& mat = AsBodyInterface(bodyInterface)->GetWorldTransform(JPH::BodyID(bodyId));
	FromJolt(mat, result);
}

void JPH_BodyInterface_GetCenterOfMassTransform(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RMat4* result)
{
	const JPH::RMat44& mat = AsBodyInterface(bodyInterface)->GetCenterOfMassTransform(JPH::BodyID(bodyId));
	FromJolt(mat, result);
}

void JPH_BodyInterface_MoveKinematic(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RVec3* targetPosition, JPH_Quat* targetRotation, float deltaTime)
{
	AsBodyInterface(bodyInterface)->MoveKinematic(JPH::BodyID(bodyId), ToJolt(targetPosition), ToJolt(targetRotation), deltaTime);
}

bool JPH_BodyInterface_ApplyBuoyancyImpulse(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, const JPH_RVec3* surfacePosition, const JPH_Vec3* surfaceNormal, float buoyancy, float linearDrag, float angularDrag, const JPH_Vec3* fluidVelocity, const JPH_Vec3* gravity, float deltaTime)
{
	return AsBodyInterface(bodyInterface)->ApplyBuoyancyImpulse(
		JPH::BodyID(bodyId),
		ToJolt(surfacePosition),
		ToJolt(surfaceNormal),
		buoyancy,
		linearDrag,
		angularDrag,
		ToJolt(fluidVelocity),
		ToJolt(gravity),
		deltaTime
	);
}

void JPH_BodyInterface_SetLinearAndAngularVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* linearVelocity, JPH_Vec3* angularVelocity)
{
	AsBodyInterface(bodyInterface)->SetLinearAndAngularVelocity(JPH::BodyID(bodyId), ToJolt(linearVelocity), ToJolt(angularVelocity));
}

void JPH_BodyInterface_GetLinearAndAngularVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* linearVelocity, JPH_Vec3* angularVelocity)
{
	JPH::Vec3 linear, angular;
	AsBodyInterface(bodyInterface)->GetLinearAndAngularVelocity(JPH::BodyID(bodyId), linear, angular);
	FromJolt(linear, linearVelocity);
	FromJolt(angular, angularVelocity);
}

void JPH_BodyInterface_AddLinearVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* linearVelocity)
{
	AsBodyInterface(bodyInterface)->AddLinearVelocity(JPH::BodyID(bodyId), ToJolt(linearVelocity));
}

void JPH_BodyInterface_AddLinearAndAngularVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* linearVelocity, JPH_Vec3* angularVelocity)
{
	AsBodyInterface(bodyInterface)->AddLinearAndAngularVelocity(JPH::BodyID(bodyId), ToJolt(linearVelocity), ToJolt(angularVelocity));
}

void JPH_BodyInterface_SetAngularVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* angularVelocity)
{
	AsBodyInterface(bodyInterface)->SetAngularVelocity(JPH::BodyID(bodyId), ToJolt(angularVelocity));
}

void JPH_BodyInterface_GetAngularVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* angularVelocity)
{
	auto result = AsBodyInterface(bodyInterface)->GetAngularVelocity(JPH::BodyID(bodyId));
	FromJolt(result, angularVelocity);
}

void JPH_BodyInterface_GetPointVelocity(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_RVec3* point, JPH_Vec3* velocity)
{
	auto result = AsBodyInterface(bodyInterface)->GetPointVelocity(JPH::BodyID(bodyId), ToJolt(point));
	FromJolt(result, velocity);
}

void JPH_BodyInterface_AddForce(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* force)
{
	AsBodyInterface(bodyInterface)->AddForce(JPH::BodyID(bodyId), ToJolt(force));
}

void JPH_BodyInterface_AddForce2(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* force, JPH_RVec3* point)
{
	AsBodyInterface(bodyInterface)->AddForce(JPH::BodyID(bodyId), ToJolt(force), ToJolt(point));
}

void JPH_BodyInterface_AddTorque(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* torque)
{
	AsBodyInterface(bodyInterface)->AddTorque(JPH::BodyID(bodyId), ToJolt(torque));
}

void JPH_BodyInterface_AddForceAndTorque(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* force, JPH_Vec3* torque)
{
	AsBodyInterface(bodyInterface)->AddForceAndTorque(JPH::BodyID(bodyId), ToJolt(force), ToJolt(torque));
}

void JPH_BodyInterface_AddImpulse(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* impulse)
{
	AsBodyInterface(bodyInterface)->AddImpulse(JPH::BodyID(bodyId), ToJolt(impulse));
}

void JPH_BodyInterface_AddImpulse2(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* impulse, JPH_RVec3* point)
{
	AsBodyInterface(bodyInterface)->AddImpulse(JPH::BodyID(bodyId), ToJolt(impulse), ToJolt(point));
}

void JPH_BodyInterface_AddAngularImpulse(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Vec3* angularImpulse)
{
	AsBodyInterface(bodyInterface)->AddAngularImpulse(JPH::BodyID(bodyId), ToJolt(angularImpulse));
}

void JPH_BodyInterface_SetMotionQuality(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_MotionQuality quality)
{
	AsBodyInterface(bodyInterface)->SetMotionQuality(JPH::BodyID(bodyId), static_cast<JPH::EMotionQuality>(quality));
}

JPH_MotionQuality JPH_BodyInterface_GetMotionQuality(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	return static_cast<JPH_MotionQuality>(AsBodyInterface(bodyInterface)->GetMotionQuality(JPH::BodyID(bodyId)));
}

void JPH_BodyInterface_GetInverseInertia(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_Mat4* result)
{
	const JPH::Mat44& mat = AsBodyInterface(bodyInterface)->GetInverseInertia(JPH::BodyID(bodyId));
	FromJolt(mat, result);
}

void JPH_BodyInterface_SetGravityFactor(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, float value)
{
	AsBodyInterface(bodyInterface)->SetGravityFactor(JPH::BodyID(bodyId), value);
}

float JPH_BodyInterface_GetGravityFactor(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	return AsBodyInterface(bodyInterface)->GetGravityFactor(JPH::BodyID(bodyId));
}

void JPH_BodyInterface_SetUseManifoldReduction(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, bool value)
{
	AsBodyInterface(bodyInterface)->SetUseManifoldReduction(JPH::BodyID(bodyId), value);
}

bool JPH_BodyInterface_GetUseManifoldReduction(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	return AsBodyInterface(bodyInterface)->GetUseManifoldReduction(JPH::BodyID(bodyId));
}

void JPH_BodyInterface_SetUserData(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, uint64_t userData)
{
	AsBodyInterface(bodyInterface)->SetUserData(JPH::BodyID(bodyId), userData);
}

uint64_t JPH_BodyInterface_GetUserData(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	return AsBodyInterface(bodyInterface)->GetUserData(JPH::BodyID(bodyId));
}

void JPH_BodyInterface_SetIsSensor(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, bool value)
{
	AsBodyInterface(bodyInterface)->SetIsSensor(JPH::BodyID(bodyId), value);
}

bool JPH_BodyInterface_IsSensor(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	return AsBodyInterface(bodyInterface)->IsSensor(JPH::BodyID(bodyId));
}

const JPH_PhysicsMaterial* JPH_BodyInterface_GetMaterial(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId, JPH_SubShapeID subShapeID)
{
	auto joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(subShapeID);
	return FromJolt(AsBodyInterface(bodyInterface)->GetMaterial(JPH::BodyID(bodyId), joltSubShapeID));
}

void JPH_BodyInterface_InvalidateContactCache(JPH_BodyInterface* bodyInterface, JPH_BodyID bodyId)
{
	AsBodyInterface(bodyInterface)->InvalidateContactCache(JPH::BodyID(bodyId));
}

//--------------------------------------------------------------------------------------------------
// JPH_BodyLockInterface
//--------------------------------------------------------------------------------------------------
void JPH_BodyLockInterface_LockRead(const JPH_BodyLockInterface* lockInterface, JPH_BodyID bodyID, JPH_BodyLockRead* outLock)
{
	JPH_ASSERT(outLock != nullptr);
	auto joltBodyLockInterface = AsBodyLockInterface(lockInterface);

	::new (outLock) JPH::BodyLockRead(*joltBodyLockInterface, JPH::BodyID(bodyID));
}

void JPH_BodyLockInterface_UnlockRead(const JPH_BodyLockInterface* lockInterface, JPH_BodyLockRead* ioLock)
{
	JPH_UNUSED(lockInterface);
	JPH_ASSERT(ioLock != nullptr);
	JPH_ASSERT(lockInterface != nullptr && lockInterface == ioLock->lockInterface);

	reinterpret_cast<const JPH::BodyLockRead*>(ioLock)->~BodyLockRead();
}

void JPH_BodyLockInterface_LockWrite(const JPH_BodyLockInterface* lockInterface, JPH_BodyID bodyID, JPH_BodyLockWrite* outLock)
{
	JPH_ASSERT(outLock != nullptr);
	auto joltBodyLockInterface = reinterpret_cast<const JPH::BodyLockInterface*>(lockInterface);

	::new (outLock) JPH::BodyLockWrite(*joltBodyLockInterface, JPH::BodyID(bodyID));
}

void JPH_BodyLockInterface_UnlockWrite(const JPH_BodyLockInterface* lockInterface, JPH_BodyLockWrite* ioLock)
{
	JPH_UNUSED(lockInterface);
	JPH_ASSERT(ioLock != nullptr);
	JPH_ASSERT(lockInterface != nullptr && lockInterface == ioLock->lockInterface);

	reinterpret_cast<const JPH::BodyLockWrite*>(ioLock)->~BodyLockWrite();
}

struct JPH_BodyLockMultiRead final
{
	Array<BodyID> bodyIDs;
	JPH::BodyLockMultiRead* joltLock = nullptr;
};

JPH_BodyLockMultiRead* JPH_BodyLockInterface_LockMultiRead(const JPH_BodyLockInterface* lockInterface, const JPH_BodyID* bodyIDs, uint32_t count)
{
	auto joltBodyLockInterface = AsBodyLockInterface(lockInterface);
	JPH_BodyLockMultiRead* read = new JPH_BodyLockMultiRead();
	read->bodyIDs.reserve(count);

	for (uint32_t i = 0; i < count; ++i)
	{
		read->bodyIDs.push_back(JPH::BodyID(bodyIDs[i]));
	}

	read->joltLock = new JPH::BodyLockMultiRead(*joltBodyLockInterface, read->bodyIDs.data(), count);
	return read;
}

void JPH_BodyLockMultiRead_Destroy(JPH_BodyLockMultiRead* ioLock)
{
	if (ioLock)
	{
		ioLock->bodyIDs.clear();
		delete ioLock->joltLock;
		delete ioLock;
	}
}

const JPH_Body* JPH_BodyLockMultiRead_GetBody(JPH_BodyLockMultiRead* ioLock, uint32_t bodyIndex)
{
	JPH_ASSERT(ioLock);

	auto joltBody = ioLock->joltLock->GetBody(bodyIndex);
	return reinterpret_cast<const JPH_Body*>(joltBody);
}

struct JPH_BodyLockMultiWrite final
{
	Array<BodyID> bodyIDs;
	JPH::BodyLockMultiWrite* joltLock = nullptr;
};

JPH_BodyLockMultiWrite* JPH_BodyLockInterface_LockMultiWrite(const JPH_BodyLockInterface* lockInterface, const JPH_BodyID* bodyIDs, uint32_t count)
{
	auto joltBodyLockInterface = AsBodyLockInterface(lockInterface);

	JPH_BodyLockMultiWrite* write = new JPH_BodyLockMultiWrite();
	write->bodyIDs.reserve(count);

	for (uint32_t i = 0; i < count; ++i)
	{
		write->bodyIDs.push_back(JPH::BodyID(bodyIDs[i]));
	}

	write->joltLock = new JPH::BodyLockMultiWrite(*joltBodyLockInterface, write->bodyIDs.data(), count);
	return write;
}

void JPH_BodyLockMultiWrite_Destroy(JPH_BodyLockMultiWrite* ioLock)
{
	if (ioLock)
	{
		ioLock->bodyIDs.clear();
		delete ioLock->joltLock;
		delete ioLock;
	}
}

JPH_Body* JPH_BodyLockMultiWrite_GetBody(JPH_BodyLockMultiWrite* ioLock, uint32_t bodyIndex)
{
	JPH_ASSERT(ioLock);

	auto joltBody = ioLock->joltLock->GetBody(bodyIndex);
	return reinterpret_cast<JPH_Body*>(joltBody);
}

//--------------------------------------------------------------------------------------------------
// JPH_CollideSettingsBase
//--------------------------------------------------------------------------------------------------
static inline void ToJolt(const JPH_CollideSettingsBase& settings, JPH::CollideSettingsBase* result)
{
	result->mActiveEdgeMode = static_cast<EActiveEdgeMode>(settings.activeEdgeMode);
	result->mCollectFacesMode = static_cast<ECollectFacesMode>(settings.collectFacesMode);
	result->mCollisionTolerance = settings.collisionTolerance;
	result->mPenetrationTolerance = settings.penetrationTolerance;
	result->mActiveEdgeMovementDirection = ToJolt(settings.activeEdgeMovementDirection);
}

void JPH_CollideSettingsBase_Init(const CollideSettingsBase& joltSettings, JPH_CollideSettingsBase* settings)
{
	// Copy defaults from jolt 
	settings->activeEdgeMode = static_cast<JPH_ActiveEdgeMode>(joltSettings.mActiveEdgeMode);
	settings->collectFacesMode = static_cast<JPH_CollectFacesMode>(joltSettings.mCollectFacesMode);
	settings->collisionTolerance = joltSettings.mCollisionTolerance;
	settings->penetrationTolerance = joltSettings.mPenetrationTolerance;
	FromJolt(joltSettings.mActiveEdgeMovementDirection, &settings->activeEdgeMovementDirection);
}

//--------------------------------------------------------------------------------------------------
// JPH_CollideShapeSettings
//--------------------------------------------------------------------------------------------------
static inline JPH::CollideShapeSettings ToJolt(const JPH_CollideShapeSettings* settings)
{
	JPH::CollideShapeSettings result{};
	if (settings == nullptr)
	{
		result.mActiveEdgeMode = EActiveEdgeMode::CollideWithAll;
		return result;
	}

	ToJolt(settings->base, &result);

	result.mMaxSeparationDistance = settings->maxSeparationDistance;
	result.mBackFaceMode = static_cast<EBackFaceMode>(settings->backFaceMode);
	return result;
}

static inline JPH_CollideShapeSettings FromJolt(const JPH::CollideShapeSettings& joltSettings)
{
	JPH_CollideShapeSettings result{};
	JPH_CollideSettingsBase_Init(joltSettings, &result.base);

	result.maxSeparationDistance = joltSettings.mMaxSeparationDistance;
	result.backFaceMode = static_cast<JPH_BackFaceMode>(joltSettings.mBackFaceMode);
	return result;
}

void JPH_CollideShapeSettings_Init(JPH_CollideShapeSettings* settings)
{
	memset(settings, 0, sizeof(JPH_CollideShapeSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	JPH::CollideShapeSettings joltSettings;
	JPH_CollideSettingsBase_Init(joltSettings, &settings->base);

	settings->maxSeparationDistance = joltSettings.mMaxSeparationDistance;
	settings->backFaceMode = static_cast<JPH_BackFaceMode>(joltSettings.mBackFaceMode);
}

//--------------------------------------------------------------------------------------------------
// JPH_ShapeCastSettings
//--------------------------------------------------------------------------------------------------
static inline ShapeCastSettings ToJolt(const JPH_ShapeCastSettings* settings)
{
	JPH::ShapeCastSettings result{};
	if (settings == nullptr)
	{
		result.mActiveEdgeMode = EActiveEdgeMode::CollideWithAll;
		result.mBackFaceModeTriangles = EBackFaceMode::CollideWithBackFaces;
		result.mBackFaceModeConvex = EBackFaceMode::CollideWithBackFaces;
		return result;
	}

	ToJolt(settings->base, &result);

	result.mBackFaceModeTriangles = static_cast<EBackFaceMode>(settings->backFaceModeTriangles);
	result.mBackFaceModeConvex = static_cast<EBackFaceMode>(settings->backFaceModeConvex);
	result.mUseShrunkenShapeAndConvexRadius = settings->useShrunkenShapeAndConvexRadius;
	result.mReturnDeepestPoint = settings->returnDeepestPoint;
	return result;
}

static inline JPH_ShapeCastSettings FromJolt(const ShapeCastSettings& joltSettings)
{
	JPH_ShapeCastSettings result{};
	JPH_CollideSettingsBase_Init(joltSettings, &result.base);

	result.backFaceModeTriangles = static_cast<JPH_BackFaceMode>(joltSettings.mBackFaceModeTriangles);
	result.backFaceModeConvex = static_cast<JPH_BackFaceMode>(joltSettings.mBackFaceModeConvex);
	result.useShrunkenShapeAndConvexRadius = joltSettings.mUseShrunkenShapeAndConvexRadius;
	result.returnDeepestPoint = joltSettings.mReturnDeepestPoint;
	return result;
}

void JPH_ShapeCastSettings_Init(JPH_ShapeCastSettings* settings)
{
	memset(settings, 0, sizeof(JPH_ShapeCastSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	JPH::ShapeCastSettings joltSettings;
	JPH_CollideSettingsBase_Init(joltSettings, &settings->base);

	settings->backFaceModeTriangles = static_cast<JPH_BackFaceMode>(joltSettings.mBackFaceModeTriangles);
	settings->backFaceModeConvex = static_cast<JPH_BackFaceMode>(joltSettings.mBackFaceModeConvex);
	settings->useShrunkenShapeAndConvexRadius = joltSettings.mUseShrunkenShapeAndConvexRadius;
	settings->returnDeepestPoint = joltSettings.mReturnDeepestPoint;
}

//--------------------------------------------------------------------------------------------------
// JPH_BroadPhaseQuery
//--------------------------------------------------------------------------------------------------
class RayCastBodyCollectorCallback final : public RayCastBodyCollector
{
public:
	RayCastBodyCollectorCallback(JPH_RayCastBodyCollectorCallback* proc_, void* userData_)
		: proc(proc_)
		, userData(userData_)
	{}

	void AddHit(const BroadPhaseCastResult& result) override
	{
		JPH_BroadPhaseCastResult hit;
		hit.bodyID = result.mBodyID.GetIndexAndSequenceNumber();
		hit.fraction = result.mFraction;

		float fraction = proc(userData, &hit);
		UpdateEarlyOutFraction(fraction);
		hadHit = true;
	}

	JPH_RayCastBodyCollectorCallback* proc;
	void* userData;
	bool hadHit = false;
	uint32_t _padding;
};

class CollideShapeBodyCollectorCallback final : public CollideShapeBodyCollector
{
public:
	CollideShapeBodyCollectorCallback(JPH_CollideShapeBodyCollectorCallback* proc_, void* userData_)
		: proc(proc_)
		, userData(userData_)
	{}

	void AddHit(const BodyID& result) override
	{
		float fraction = proc(userData, result.GetIndexAndSequenceNumber());

		UpdateEarlyOutFraction(fraction);
		hadHit = true;
	}

	JPH_CollideShapeBodyCollectorCallback* proc;
	void* userData;
	bool hadHit = false;
	uint32_t _padding;
};

bool JPH_BroadPhaseQuery_CastRay(const JPH_BroadPhaseQuery* query,
	const JPH_Vec3* origin, const JPH_Vec3* direction,
	JPH_RayCastBodyCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter)
{
	JPH_ASSERT(query && origin && direction && callback);

	JPH::RayCast ray(ToJolt(origin), ToJolt(direction));
	RayCastBodyCollectorCallback collector(callback, userData);
	AsBroadPhaseQuery(query)->CastRay(ray, collector, ToJolt(broadPhaseLayerFilter), ToJolt(objectLayerFilter));
	return collector.hadHit;
}

bool JPH_BroadPhaseQuery_CastRay2(const JPH_BroadPhaseQuery* query,
	const JPH_Vec3* origin, const JPH_Vec3* direction,
	JPH_CollisionCollectorType collectorType,
	JPH_RayCastBodyResultCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter)
{
	JPH::RayCast ray(ToJolt(origin), ToJolt(direction));
	JPH_BroadPhaseCastResult hitResult{};

	switch (collectorType)
	{
		case JPH_CollisionCollectorType_AllHit:
		case JPH_CollisionCollectorType_AllHitSorted:
		{
			AllHitCollisionCollector<RayCastBodyCollector> collector;
			AsBroadPhaseQuery(query)->CastRay(ray, collector, ToJolt(broadPhaseLayerFilter), ToJolt(objectLayerFilter));

			if (collector.HadHit())
			{
				if (collectorType == JPH_CollisionCollectorType_AllHitSorted)
					collector.Sort();

				for (auto& hit : collector.mHits)
				{
					hitResult.bodyID = hit.mBodyID.GetIndexAndSequenceNumber();
					hitResult.fraction = hit.mFraction;
					callback(userData, &hitResult);
				}
			}

			return collector.HadHit();
		}
		case JPH_CollisionCollectorType_ClosestHit:
		{
			ClosestHitCollisionCollector<RayCastBodyCollector> collector;
			AsBroadPhaseQuery(query)->CastRay(ray, collector, ToJolt(broadPhaseLayerFilter), ToJolt(objectLayerFilter));

			if (collector.HadHit())
			{
				hitResult.fraction = collector.mHit.mFraction;
				hitResult.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				callback(userData, &hitResult);
			}

			return collector.HadHit();
		}

		case JPH_CollisionCollectorType_AnyHit:
		{
			AnyHitCollisionCollector<RayCastBodyCollector> collector;
			AsBroadPhaseQuery(query)->CastRay(ray, collector, ToJolt(broadPhaseLayerFilter), ToJolt(objectLayerFilter));

			if (collector.HadHit())
			{
				hitResult.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				hitResult.fraction = collector.mHit.mFraction;
				callback(userData, &hitResult);
			}

			return collector.HadHit();
		}

		default:
			return false;
	}
}

bool JPH_BroadPhaseQuery_CollideAABox(const JPH_BroadPhaseQuery* query,
	const JPH_AABox* box, JPH_CollideShapeBodyCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter)
{
	JPH_ASSERT(query && box && callback);

	JPH::AABox joltBox(ToJolt(&box->min), ToJolt(&box->max));
	CollideShapeBodyCollectorCallback collector(callback, userData);
	AsBroadPhaseQuery(query)->CollideAABox(joltBox, collector, ToJolt(broadPhaseLayerFilter), ToJolt(objectLayerFilter));
	return collector.hadHit;
}

bool JPH_BroadPhaseQuery_CollideSphere(const JPH_BroadPhaseQuery* query,
	const JPH_Vec3* center, float radius, JPH_CollideShapeBodyCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter)
{
	JPH_ASSERT(query && center && callback);

	CollideShapeBodyCollectorCallback collector(callback, userData);
	AsBroadPhaseQuery(query)->CollideSphere(ToJolt(center), radius, collector, ToJolt(broadPhaseLayerFilter), ToJolt(objectLayerFilter));
	return collector.hadHit;
}

bool JPH_BroadPhaseQuery_CollidePoint(const JPH_BroadPhaseQuery* query,
	const JPH_Vec3* point, JPH_CollideShapeBodyCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter)
{
	JPH_ASSERT(query && point && callback);

	CollideShapeBodyCollectorCallback collector(callback, userData);
	AsBroadPhaseQuery(query)->CollidePoint(ToJolt(point), collector, ToJolt(broadPhaseLayerFilter), ToJolt(objectLayerFilter));
	return collector.hadHit;
}

//--------------------------------------------------------------------------------------------------
// JPH_NarrowPhaseQuery
//--------------------------------------------------------------------------------------------------
class CastRayCollectorCallback final : public  JPH::CastRayCollector
{
public:
	CastRayCollectorCallback(JPH_CastRayCollectorCallback* proc_, void* userData_)
		: proc(proc_)
		, userData(userData_)
	{}

	void AddHit(const RayCastResult& result) override
	{
		JPH_RayCastResult hit;
		hit.bodyID = result.mBodyID.GetIndexAndSequenceNumber();
		hit.fraction = result.mFraction;
		hit.subShapeID2 = result.mSubShapeID2.GetValue();

		float fraction = proc(userData, &hit);
		UpdateEarlyOutFraction(fraction);
		hadHit = true;
	}

	JPH_CastRayCollectorCallback* proc;
	void* userData;
	bool hadHit = false;
	uint32_t _padding;
};

class CollidePointCollectorCallback final : public CollidePointCollector
{
public:
	CollidePointCollectorCallback(JPH_CollidePointCollectorCallback* proc_, void* userData_)
		: proc(proc_)
		, userData(userData_)
	{}

	void AddHit(const CollidePointResult& result) override
	{
		JPH_CollidePointResult hit;
		hit.bodyID = result.mBodyID.GetIndexAndSequenceNumber();
		hit.subShapeID2 = result.mSubShapeID2.GetValue();

		float fraction = proc(userData, &hit);
		UpdateEarlyOutFraction(fraction);
		hadHit = true;
	}

	JPH_CollidePointCollectorCallback* proc;
	void* userData;
	bool hadHit = false;
	uint32_t _padding;
};

class CollideShapeCollectorCallback : public CollideShapeCollector
{
public:
	CollideShapeCollectorCallback(JPH_CollideShapeCollectorCallback* proc, void* userData)
		: proc(proc)
		, userData(userData)
	{}

	void AddHit(const CollideShapeResult& result) override
	{
		JPH_CollideShapeResult hit = FromJolt(result);

		float fraction = proc(userData, &hit);
		JPH_CollideShapeResult_FreeMembers(&hit);
		UpdateEarlyOutFraction(fraction);
		hadHit = true;
	}

	JPH_CollideShapeCollectorCallback* proc;
	void* userData;
	bool hadHit = false;
	uint32_t _padding;
};

class CastShapeCollectorCallback final : public CastShapeCollector
{
public:
	CastShapeCollectorCallback(JPH_CastShapeCollectorCallback* proc_, void* userData_)
		: proc(proc_)
		, userData(userData_)
	{}

	void AddHit(const ShapeCastResult& result) override
	{
		JPH_ShapeCastResult hit{};
		FromJolt(result.mContactPointOn1, &hit.contactPointOn1);
		FromJolt(result.mContactPointOn2, &hit.contactPointOn2);
		FromJolt(result.mPenetrationAxis, &hit.penetrationAxis);
		hit.penetrationDepth = result.mPenetrationDepth;
		hit.subShapeID1 = result.mSubShapeID1.GetValue();
		hit.subShapeID2 = result.mSubShapeID2.GetValue();
		hit.bodyID2 = result.mBodyID2.GetIndexAndSequenceNumber();
		hit.fraction = result.mFraction;
		hit.isBackFaceHit = result.mIsBackFaceHit;

		float fraction = proc(userData, &hit);
		UpdateEarlyOutFraction(fraction);
		hadHit = true;
	}

	JPH_CastShapeCollectorCallback* proc;
	void* userData;
	bool hadHit = false;
	uint32_t _padding;
};

bool JPH_NarrowPhaseQuery_CastRay(const JPH_NarrowPhaseQuery* query,
	const JPH_RVec3* origin, const JPH_Vec3* direction,
	JPH_RayCastResult* hit,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter)
{
	JPH_ASSERT(query && origin && direction && hit);
	auto joltQuery = reinterpret_cast<const JPH::NarrowPhaseQuery*>(query);

	JPH::RRayCast ray(ToJolt(origin), ToJolt(direction));
	RayCastResult result;

	const bool hadHit = joltQuery->CastRay(
		ray,
		result,
		ToJolt(broadPhaseLayerFilter),
		ToJolt(objectLayerFilter),
		ToJolt(bodyFilter)
	);

	if (hadHit)
	{
		hit->fraction = result.mFraction;
		hit->bodyID = result.mBodyID.GetIndexAndSequenceNumber();
		hit->subShapeID2 = result.mSubShapeID2.GetValue();
	}

	return hadHit;
}

bool JPH_NarrowPhaseQuery_CastRay2(const JPH_NarrowPhaseQuery* query,
	const JPH_RVec3* origin, const JPH_Vec3* direction,
	const JPH_RayCastSettings* rayCastSettings,
	JPH_CastRayCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	JPH::RRayCast ray(ToJolt(origin), ToJolt(direction));
	JPH::RayCastSettings raySettings = ToJolt(rayCastSettings);

	CastRayCollectorCallback collector(callback, userData);

	AsNarrowPhaseQuery(query)->CastRay(
		ray,
		raySettings,
		collector,
		ToJolt(broadPhaseLayerFilter),
		ToJolt(objectLayerFilter),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter)
	);

	return collector.hadHit;
}

bool JPH_NarrowPhaseQuery_CastRay3(const JPH_NarrowPhaseQuery* query,
	const JPH_RVec3* origin, const JPH_Vec3* direction,
	const JPH_RayCastSettings* rayCastSettings,
	JPH_CollisionCollectorType collectorType,
	JPH_CastRayResultCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	JPH::RRayCast ray(ToJolt(origin), ToJolt(direction));
	JPH::RayCastSettings raySettings = ToJolt(rayCastSettings);
	JPH_RayCastResult hitResult{};

	switch (collectorType)
	{
		case JPH_CollisionCollectorType_AllHit:
		case JPH_CollisionCollectorType_AllHitSorted:
		{
			AllHitCollisionCollector<CastRayCollector> collector;
			AsNarrowPhaseQuery(query)->CastRay(
				ray,
				raySettings,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				if (collectorType == JPH_CollisionCollectorType_AllHitSorted)
					collector.Sort();

				for (auto& hit : collector.mHits)
				{
					hitResult.fraction = hit.mFraction;
					hitResult.bodyID = hit.mBodyID.GetIndexAndSequenceNumber();
					hitResult.subShapeID2 = hit.mSubShapeID2.GetValue();
					callback(userData, &hitResult);
				}
			}

			return collector.HadHit();
		}
		case JPH_CollisionCollectorType_ClosestHit:
		{
			ClosestHitCollisionCollector<CastRayCollector> collector;
			AsNarrowPhaseQuery(query)->CastRay(
				ray,
				raySettings,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				hitResult.fraction = collector.mHit.mFraction;
				hitResult.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				hitResult.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &hitResult);
			}

			return collector.HadHit();
		}

		case JPH_CollisionCollectorType_AnyHit:
		{
			AnyHitCollisionCollector<CastRayCollector> collector;
			AsNarrowPhaseQuery(query)->CastRay(
				ray,
				raySettings,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				hitResult.fraction = collector.mHit.mFraction;
				hitResult.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				hitResult.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &hitResult);
			}

			return collector.HadHit();
		}

		default:
			return false;
	}
}

bool JPH_NarrowPhaseQuery_CollidePoint(const JPH_NarrowPhaseQuery* query,
	const JPH_RVec3* point,
	JPH_CollidePointCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	auto joltPoint = ToJolt(point);

	CollidePointCollectorCallback collector(callback, userData);
	AsNarrowPhaseQuery(query)->CollidePoint(
		joltPoint,
		collector,
		ToJolt(broadPhaseLayerFilter),
		ToJolt(objectLayerFilter),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter)
	);

	return collector.hadHit;
}

bool JPH_NarrowPhaseQuery_CollidePoint2(const JPH_NarrowPhaseQuery* query,
	const JPH_RVec3* point,
	JPH_CollisionCollectorType collectorType,
	JPH_CollidePointResultCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	auto joltPoint = ToJolt(point);
	JPH_CollidePointResult result{};

	switch (collectorType)
	{
		case JPH_CollisionCollectorType_AllHit:
		case JPH_CollisionCollectorType_AllHitSorted:
		{
			AllHitCollisionCollector<CollidePointCollector> collector;
			AsNarrowPhaseQuery(query)->CollidePoint(
				joltPoint,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				if (collectorType == JPH_CollisionCollectorType_AllHitSorted)
					collector.Sort();

				for (auto& hit : collector.mHits)
				{
					result.bodyID = hit.mBodyID.GetIndexAndSequenceNumber();
					result.subShapeID2 = hit.mSubShapeID2.GetValue();
					callback(userData, &result);
				}
			}

			return collector.HadHit();
		}
		case JPH_CollisionCollectorType_ClosestHit:
		{
			ClosestHitCollisionCollector<CollidePointCollector> collector;
			AsNarrowPhaseQuery(query)->CollidePoint(
				joltPoint,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				result.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				result.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &result);
			}

			return collector.HadHit();
		}

		case JPH_CollisionCollectorType_AnyHit:
		{
			AnyHitCollisionCollector<CollidePointCollector> collector;
			AsNarrowPhaseQuery(query)->CollidePoint(
				joltPoint,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				result.bodyID = collector.mHit.mBodyID.GetIndexAndSequenceNumber();
				result.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				callback(userData, &result);
			}

			return collector.HadHit();
		}

		default:
			return false;
	}
}

bool JPH_NarrowPhaseQuery_CollideShape(const JPH_NarrowPhaseQuery* query,
	const JPH_Shape* shape, const JPH_Vec3* scale, const JPH_RMat4* centerOfMassTransform,
	const JPH_CollideShapeSettings* settings,
	JPH_RVec3* baseOffset,
	JPH_CollideShapeCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	JPH_ASSERT(query && shape && scale && centerOfMassTransform && callback);

	auto joltScale = ToJolt(scale);
	auto joltTransform = ToJolt(centerOfMassTransform);

	JPH::CollideShapeSettings joltSettings = ToJolt(settings);
	auto joltBaseOffset = ToJolt(baseOffset);

	CollideShapeCollectorCallback collector(callback, userData);

	AsNarrowPhaseQuery(query)->CollideShape(
		AsShape(shape),
		joltScale,
		joltTransform,
		joltSettings,
		joltBaseOffset,
		collector,
		ToJolt(broadPhaseLayerFilter),
		ToJolt(objectLayerFilter),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter)
	);

	return collector.hadHit;
}

bool JPH_NarrowPhaseQuery_CollideShape2(const JPH_NarrowPhaseQuery* query,
	const JPH_Shape* shape, const JPH_Vec3* scale, const JPH_RMat4* centerOfMassTransform,
	const JPH_CollideShapeSettings* settings,
	JPH_RVec3* baseOffset,
	JPH_CollisionCollectorType collectorType,
	JPH_CollideShapeResultCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{

	JPH_ASSERT(query && shape && scale && centerOfMassTransform && callback);

	auto joltScale = ToJolt(scale);
	auto joltTransform = ToJolt(centerOfMassTransform);

	JPH::CollideShapeSettings joltSettings = ToJolt(settings);
	auto joltBaseOffset = ToJolt(baseOffset);

	JPH_CollideShapeResult result{};

	switch (collectorType)
	{
		case JPH_CollisionCollectorType_AllHit:
		case JPH_CollisionCollectorType_AllHitSorted:
		{
			AllHitCollisionCollector<CollideShapeCollector> collector;
			AsNarrowPhaseQuery(query)->CollideShape(
				AsShape(shape),
				joltScale,
				joltTransform,
				joltSettings,
				joltBaseOffset,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				if (collectorType == JPH_CollisionCollectorType_AllHitSorted)
					collector.Sort();

				for (auto& hit : collector.mHits)
				{
					result = FromJolt(hit);
					callback(userData, &result);
				}
			}

			return collector.HadHit();
		}
		case JPH_CollisionCollectorType_ClosestHit:
		{
			ClosestHitCollisionCollector<CollideShapeCollector> collector;
			AsNarrowPhaseQuery(query)->CollideShape(
				AsShape(shape),
				joltScale,
				joltTransform,
				joltSettings,
				joltBaseOffset,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				result = FromJolt(collector.mHit);
				callback(userData, &result);
				JPH_CollideShapeResult_FreeMembers(&result);
			}

			return collector.HadHit();
		}

		case JPH_CollisionCollectorType_AnyHit:
		{
			AnyHitCollisionCollector<CollideShapeCollector> collector;
			AsNarrowPhaseQuery(query)->CollideShape(
				AsShape(shape),
				joltScale,
				joltTransform,
				joltSettings,
				joltBaseOffset,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				result = FromJolt(collector.mHit);
				callback(userData, &result);
				JPH_CollideShapeResult_FreeMembers(&result);
			}

			return collector.HadHit();
		}

		default:
			return false;
	}
}

bool JPH_NarrowPhaseQuery_CastShape(const JPH_NarrowPhaseQuery* query,
	const JPH_Shape* shape,
	const JPH_RMat4* worldTransform, const JPH_Vec3* direction,
	const JPH_ShapeCastSettings* settings,
	JPH_RVec3* baseOffset,
	JPH_CastShapeCollectorCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	JPH_ASSERT(query && shape && worldTransform && direction && callback);

	RShapeCast shapeCast = RShapeCast::sFromWorldTransform(
		AsShape(shape),
		JPH::Vec3(1.f, 1.f, 1.f), // scale can be embedded in worldTransform
		ToJolt(worldTransform),
		ToJolt(direction));

	ShapeCastSettings joltSettings = ToJolt(settings);

	auto joltBaseOffset = ToJolt(baseOffset);
	CastShapeCollectorCallback collector(callback, userData);

	AsNarrowPhaseQuery(query)->CastShape(
		shapeCast,
		joltSettings,
		joltBaseOffset,
		collector,
		ToJolt(broadPhaseLayerFilter),
		ToJolt(objectLayerFilter),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter)
	);

	return collector.hadHit;
}

bool JPH_NarrowPhaseQuery_CastShape2(const JPH_NarrowPhaseQuery* query,
	const JPH_Shape* shape,
	const JPH_RMat4* worldTransform, const JPH_Vec3* direction,
	const JPH_ShapeCastSettings* settings,
	JPH_RVec3* baseOffset,
	JPH_CollisionCollectorType collectorType,
	JPH_CastShapeResultCallback* callback, void* userData,
	const JPH_BroadPhaseLayerFilter* broadPhaseLayerFilter,
	const JPH_ObjectLayerFilter* objectLayerFilter,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	JPH_ASSERT(query && shape && worldTransform && direction && callback);

	RShapeCast shapeCast = RShapeCast::sFromWorldTransform(
		AsShape(shape),
		JPH::Vec3(1.f, 1.f, 1.f), // scale can be embedded in worldTransform
		ToJolt(worldTransform),
		ToJolt(direction));

	ShapeCastSettings joltSettings = ToJolt(settings);

	auto joltBaseOffset = ToJolt(baseOffset);

	JPH_ShapeCastResult result{};

	switch (collectorType)
	{
		case JPH_CollisionCollectorType_AllHit:
		case JPH_CollisionCollectorType_AllHitSorted:
		{
			AllHitCollisionCollector<CastShapeCollector> collector;
			AsNarrowPhaseQuery(query)->CastShape(
				shapeCast,
				joltSettings,
				joltBaseOffset,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				if (collectorType == JPH_CollisionCollectorType_AllHitSorted)
					collector.Sort();

				for (auto& hit : collector.mHits)
				{
					FromJolt(hit.mContactPointOn1, &result.contactPointOn1);
					FromJolt(hit.mContactPointOn2, &result.contactPointOn2);
					FromJolt(hit.mPenetrationAxis, &result.penetrationAxis);
					result.penetrationDepth = hit.mPenetrationDepth;
					result.subShapeID1 = hit.mSubShapeID1.GetValue();
					result.subShapeID2 = hit.mSubShapeID2.GetValue();
					result.bodyID2 = hit.mBodyID2.GetIndexAndSequenceNumber();
					result.fraction = hit.mFraction;
					result.isBackFaceHit = hit.mIsBackFaceHit;
					callback(userData, &result);
				}
			}

			return collector.HadHit();
		}
		case JPH_CollisionCollectorType_ClosestHit:
		{
			ClosestHitCollisionCollector<CastShapeCollector> collector;
			AsNarrowPhaseQuery(query)->CastShape(
				shapeCast,
				joltSettings,
				joltBaseOffset,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				FromJolt(collector.mHit.mContactPointOn1, &result.contactPointOn1);
				FromJolt(collector.mHit.mContactPointOn2, &result.contactPointOn2);
				FromJolt(collector.mHit.mPenetrationAxis, &result.penetrationAxis);
				result.penetrationDepth = collector.mHit.mPenetrationDepth;
				result.subShapeID1 = collector.mHit.mSubShapeID1.GetValue();
				result.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				result.bodyID2 = collector.mHit.mBodyID2.GetIndexAndSequenceNumber();
				result.fraction = collector.mHit.mFraction;
				result.isBackFaceHit = collector.mHit.mIsBackFaceHit;
				callback(userData, &result);
			}

			return collector.HadHit();
		}

		case JPH_CollisionCollectorType_AnyHit:
		{
			AnyHitCollisionCollector<CastShapeCollector> collector;
			AsNarrowPhaseQuery(query)->CastShape(
				shapeCast,
				joltSettings,
				joltBaseOffset,
				collector,
				ToJolt(broadPhaseLayerFilter),
				ToJolt(objectLayerFilter),
				ToJolt(bodyFilter),
				ToJolt(shapeFilter)
			);

			if (collector.HadHit())
			{
				FromJolt(collector.mHit.mContactPointOn1, &result.contactPointOn1);
				FromJolt(collector.mHit.mContactPointOn2, &result.contactPointOn2);
				FromJolt(collector.mHit.mPenetrationAxis, &result.penetrationAxis);
				result.penetrationDepth = collector.mHit.mPenetrationDepth;
				result.subShapeID1 = collector.mHit.mSubShapeID1.GetValue();
				result.subShapeID2 = collector.mHit.mSubShapeID2.GetValue();
				result.bodyID2 = collector.mHit.mBodyID2.GetIndexAndSequenceNumber();
				result.fraction = collector.mHit.mFraction;
				result.isBackFaceHit = collector.mHit.mIsBackFaceHit;
				callback(userData, &result);
			}

			return collector.HadHit();
		}

		default:
			return false;
	}
}

/* Body */
JPH_BodyID JPH_Body_GetID(const JPH_Body* body)
{
	return AsBody(body)->GetID().GetIndexAndSequenceNumber();
}

JPH_BodyType JPH_Body_GetBodyType(const JPH_Body* body)
{
	return static_cast<JPH_BodyType>(AsBody(body)->GetBodyType());
}

bool JPH_Body_IsRigidBody(const JPH_Body* body)
{
	return AsBody(body)->IsRigidBody();
}

bool JPH_Body_IsSoftBody(const JPH_Body* body)
{
	return AsBody(body)->IsSoftBody();
}

bool JPH_Body_IsActive(const JPH_Body* body)
{
	return AsBody(body)->IsActive();
}

bool JPH_Body_IsStatic(const JPH_Body* body)
{
	return AsBody(body)->IsStatic();
}

bool JPH_Body_IsKinematic(const JPH_Body* body)
{
	return AsBody(body)->IsKinematic();
}

bool JPH_Body_IsDynamic(const JPH_Body* body)
{
	return AsBody(body)->IsDynamic();
}

bool JPH_Body_CanBeKinematicOrDynamic(const JPH_Body* body)
{
	return AsBody(body)->CanBeKinematicOrDynamic();
}

void JPH_Body_SetIsSensor(JPH_Body* body, bool value)
{
	AsBody(body)->SetIsSensor(value);
}

bool JPH_Body_IsSensor(const JPH_Body* body)
{
	return AsBody(body)->IsSensor();
}

void JPH_Body_SetCollideKinematicVsNonDynamic(JPH_Body* body, bool value)
{
	AsBody(body)->SetCollideKinematicVsNonDynamic(value);
}

bool JPH_Body_GetCollideKinematicVsNonDynamic(const JPH_Body* body)
{
	return AsBody(body)->GetCollideKinematicVsNonDynamic();
}

void JPH_Body_SetUseManifoldReduction(JPH_Body* body, bool value)
{
	AsBody(body)->SetUseManifoldReduction(value);
}

bool JPH_Body_GetUseManifoldReduction(const JPH_Body* body)
{
	return AsBody(body)->GetUseManifoldReduction();
}

bool JPH_Body_GetUseManifoldReductionWithBody(const JPH_Body* body, const JPH_Body* other)
{
	return AsBody(body)->GetUseManifoldReductionWithBody(*AsBody(other));
}

void JPH_Body_SetApplyGyroscopicForce(JPH_Body* body, bool value)
{
	AsBody(body)->SetApplyGyroscopicForce(value);
}

bool JPH_Body_GetApplyGyroscopicForce(const JPH_Body* body)
{
	return AsBody(body)->GetApplyGyroscopicForce();
}

void JPH_Body_SetEnhancedInternalEdgeRemoval(JPH_Body* body, bool value)
{
	AsBody(body)->SetEnhancedInternalEdgeRemoval(value);
}

bool JPH_Body_GetEnhancedInternalEdgeRemoval(const JPH_Body* body)
{
	return AsBody(body)->GetEnhancedInternalEdgeRemoval();
}

bool JPH_Body_GetEnhancedInternalEdgeRemovalWithBody(const JPH_Body* body, const JPH_Body* other)
{
	return AsBody(body)->GetEnhancedInternalEdgeRemovalWithBody(*AsBody(other));
}

JPH_MotionType JPH_Body_GetMotionType(const JPH_Body* body)
{
	return static_cast<JPH_MotionType>(AsBody(body)->GetMotionType());
}

void JPH_Body_SetMotionType(JPH_Body* body, JPH_MotionType motionType)
{
	AsBody(body)->SetMotionType(static_cast<JPH::EMotionType>(motionType));
}

JPH_BroadPhaseLayer JPH_Body_GetBroadPhaseLayer(const JPH_Body* body)
{
	return static_cast<JPH_BroadPhaseLayer>(AsBody(body)->GetBroadPhaseLayer());
}

JPH_ObjectLayer JPH_Body_GetObjectLayer(const JPH_Body* body)
{
	return static_cast<JPH_ObjectLayer>(AsBody(body)->GetObjectLayer());
}

void JPH_Body_GetCollisionGroup(const JPH_Body* body, JPH_CollisionGroup* result)
{
	FromJolt(AsBody(body)->GetCollisionGroup(), result);
}

void JPH_Body_SetCollisionGroup(JPH_Body* body, const JPH_CollisionGroup* value)
{
	AsBody(body)->SetCollisionGroup(ToJolt(value));
}

bool JPH_Body_GetAllowSleeping(JPH_Body* body)
{
	return AsBody(body)->GetAllowSleeping();
}

void JPH_Body_SetAllowSleeping(JPH_Body* body, bool allowSleeping)
{
	AsBody(body)->SetAllowSleeping(allowSleeping);
}

void JPH_Body_ResetSleepTimer(JPH_Body* body)
{
	AsBody(body)->ResetSleepTimer();
}

float JPH_Body_GetFriction(const JPH_Body* body)
{
	return AsBody(body)->GetFriction();
}

void JPH_Body_SetFriction(JPH_Body* body, float friction)
{
	AsBody(body)->SetFriction(friction);
}

float JPH_Body_GetRestitution(const JPH_Body* body)
{
	return reinterpret_cast<const JPH::Body*>(body)->GetRestitution();
}

void JPH_Body_SetRestitution(JPH_Body* body, float restitution)
{
	reinterpret_cast<JPH::Body*>(body)->SetRestitution(restitution);
}

void JPH_Body_GetLinearVelocity(JPH_Body* body, JPH_Vec3* velocity)
{
	auto joltVector = reinterpret_cast<JPH::Body*>(body)->GetLinearVelocity();
	FromJolt(joltVector, velocity);
}

void JPH_Body_SetLinearVelocity(JPH_Body* body, const JPH_Vec3* velocity)
{
	reinterpret_cast<JPH::Body*>(body)->SetLinearVelocity(ToJolt(velocity));
}

void JPH_Body_SetLinearVelocityClamped(JPH_Body* body, const JPH_Vec3* velocity)
{
	reinterpret_cast<JPH::Body*>(body)->SetLinearVelocityClamped(ToJolt(velocity));
}

void JPH_Body_GetAngularVelocity(JPH_Body* body, JPH_Vec3* velocity)
{
	auto joltVector = reinterpret_cast<JPH::Body*>(body)->GetAngularVelocity();
	FromJolt(joltVector, velocity);
}

void JPH_Body_SetAngularVelocity(JPH_Body* body, const JPH_Vec3* velocity)
{
	AsBody(body)->SetAngularVelocity(ToJolt(velocity));
}

void JPH_Body_SetAngularVelocityClamped(JPH_Body* body, const JPH_Vec3* velocity)
{
	AsBody(body)->SetAngularVelocityClamped(ToJolt(velocity));
}

void JPH_Body_GetPointVelocityCOM(JPH_Body* body, const JPH_Vec3* pointRelativeToCOM, JPH_Vec3* velocity)
{
	FromJolt(AsBody(body)->GetPointVelocityCOM(ToJolt(pointRelativeToCOM)), velocity);
}

void JPH_Body_GetPointVelocity(JPH_Body* body, const JPH_RVec3* point, JPH_Vec3* velocity)
{
	FromJolt(AsBody(body)->GetPointVelocity(ToJolt(point)), velocity);
}

void JPH_Body_AddForce(JPH_Body* body, const JPH_Vec3* force)
{
	AsBody(body)->AddForce(ToJolt(force));
}

void JPH_Body_AddForceAtPosition(JPH_Body* body, const JPH_Vec3* force, const JPH_RVec3* position)
{
	AsBody(body)->AddForce(ToJolt(force), ToJolt(position));
}

void JPH_Body_AddTorque(JPH_Body* body, const JPH_Vec3* force)
{
	AsBody(body)->AddTorque(ToJolt(force));
}

void JPH_Body_GetAccumulatedForce(JPH_Body* body, JPH_Vec3* force)
{
	auto joltVector = AsBody(body)->GetAccumulatedForce();
	FromJolt(joltVector, force);
}

void JPH_Body_GetAccumulatedTorque(JPH_Body* body, JPH_Vec3* force)
{
	auto joltVector = AsBody(body)->GetAccumulatedTorque();
	FromJolt(joltVector, force);
}

void JPH_Body_ResetForce(JPH_Body* body)
{
	AsBody(body)->ResetForce();
}

void JPH_Body_ResetTorque(JPH_Body* body)
{
	AsBody(body)->ResetTorque();
}

void JPH_Body_ResetMotion(JPH_Body* body)
{
	AsBody(body)->ResetMotion();
}

void JPH_Body_GetInverseInertia(JPH_Body* body, JPH_Mat4* result)
{
	FromJolt(AsBody(body)->GetInverseInertia(), result);
}

void JPH_Body_AddImpulse(JPH_Body* body, const JPH_Vec3* impulse)
{
	AsBody(body)->AddImpulse(ToJolt(impulse));
}

void JPH_Body_AddImpulseAtPosition(JPH_Body* body, const JPH_Vec3* impulse, const JPH_RVec3* position)
{
	AsBody(body)->AddImpulse(ToJolt(impulse), ToJolt(position));
}

void JPH_Body_AddAngularImpulse(JPH_Body* body, const JPH_Vec3* angularImpulse)
{
	AsBody(body)->AddAngularImpulse(ToJolt(angularImpulse));
}

void JPH_Body_MoveKinematic(JPH_Body* body, JPH_RVec3* targetPosition, JPH_Quat* targetRotation, float deltaTime)
{
	AsBody(body)->MoveKinematic(ToJolt(targetPosition), ToJolt(targetRotation), deltaTime);
}

bool JPH_Body_ApplyBuoyancyImpulse(JPH_Body* body, const JPH_RVec3* surfacePosition, const JPH_Vec3* surfaceNormal, float buoyancy, float linearDrag, float angularDrag, const JPH_Vec3* fluidVelocity, const JPH_Vec3* gravity, float deltaTime)
{
	return AsBody(body)->ApplyBuoyancyImpulse(
		ToJolt(surfacePosition),
		ToJolt(surfaceNormal),
		buoyancy,
		linearDrag,
		angularDrag,
		ToJolt(fluidVelocity),
		ToJolt(gravity),
		deltaTime
	);
}

bool JPH_Body_IsInBroadPhase(JPH_Body* body)
{
	return AsBody(body)->IsInBroadPhase();
}

bool JPH_Body_IsCollisionCacheInvalid(JPH_Body* body)
{
	return AsBody(body)->IsCollisionCacheInvalid();
}

const JPH_Shape* JPH_Body_GetShape(JPH_Body* body)
{
	return ToShape(AsBody(body)->GetShape());
}

void JPH_Body_GetPosition(const JPH_Body* body, JPH_RVec3* result)
{
	FromJolt(AsBody(body)->GetPosition(), result);
}

void JPH_Body_GetRotation(const JPH_Body* body, JPH_Quat* result)
{
	FromJolt(AsBody(body)->GetRotation(), result);
}

void JPH_Body_GetWorldTransform(const JPH_Body* body, JPH_RMat4* result)
{
	FromJolt(AsBody(body)->GetWorldTransform(), result);
}

void JPH_Body_GetCenterOfMassPosition(const JPH_Body* body, JPH_RVec3* result)
{
	FromJolt(AsBody(body)->GetCenterOfMassPosition(), result);
}

void JPH_Body_GetCenterOfMassTransform(const JPH_Body* body, JPH_RMat4* result)
{
	FromJolt(AsBody(body)->GetCenterOfMassTransform(), result);
}

void JPH_Body_GetInverseCenterOfMassTransform(const JPH_Body* body, JPH_RMat4* result)
{
	FromJolt(AsBody(body)->GetInverseCenterOfMassTransform(), result);
}

void JPH_Body_GetWorldSpaceBounds(const JPH_Body* body, JPH_AABox* result)
{
	FromJolt(AsBody(body)->GetWorldSpaceBounds(), result);
}

void JPH_Body_GetWorldSpaceSurfaceNormal(const JPH_Body* body, JPH_SubShapeID subShapeID, const JPH_RVec3* position, JPH_Vec3* normal)
{
	auto joltSubShapeID = JPH::SubShapeID();
	joltSubShapeID.SetValue(subShapeID);
	Vec3 joltNormal = AsBody(body)->GetWorldSpaceSurfaceNormal(joltSubShapeID, ToJolt(position));
	FromJolt(joltNormal, normal);
}

JPH_MotionProperties* JPH_Body_GetMotionProperties(JPH_Body* body)
{
	return ToMotionProperties(AsBody(body)->GetMotionProperties());
}

JPH_MotionProperties* JPH_Body_GetMotionPropertiesUnchecked(JPH_Body* body)
{
	return ToMotionProperties(AsBody(body)->GetMotionPropertiesUnchecked());
}

void JPH_Body_SetUserData(JPH_Body* body, uint64_t userData)
{
	AsBody(body)->SetUserData(userData);
}

uint64_t JPH_Body_GetUserData(JPH_Body* body)
{
	return AsBody(body)->GetUserData();
}

JPH_Body* JPH_Body_GetFixedToWorldBody(void)
{
	return ToBody(&JPH::Body::sFixedToWorld);
}

uint32_t JPH_Body_GetSoftBodyVertexCount(const JPH_Body* body) {
	if (!body || !AsBody(body)->IsSoftBody()) return 0;
	auto* mp = static_cast<const JPH::SoftBodyMotionProperties*>(AsBody(body)->GetMotionProperties());
	return (uint32_t)mp->GetVertices().size();
}

void JPH_Body_GetSoftBodyVertexPosition(const JPH_Body* body, uint32_t index, JPH_Vec3* outPos) {
	if (!body || !outPos || !AsBody(body)->IsSoftBody()) return;
	auto* jBody = AsBody(body);
	auto* mp = static_cast<const JPH::SoftBodyMotionProperties*>(jBody->GetMotionProperties());
	if (index >= mp->GetVertices().size()) return;

	const auto& v = mp->GetVertices()[index];
	JPH::RVec3 worldPos = jBody->GetCenterOfMassTransform() * v.mPosition;

	outPos->x = (float)worldPos.GetX();
	outPos->y = (float)worldPos.GetY();
	outPos->z = (float)worldPos.GetZ();
}

void JPH_Body_GetSoftBodyVertexPositions(const JPH_Body* body, JPH_Vec3* outPositions, uint32_t capacity, uint32_t* outCount)
{
	if (!body || !outPositions || !AsBody(body)->IsSoftBody()) {
		if (outCount) *outCount = 0;
		return;
	}

	const JPH::Body* jBody = AsBody(body);
	auto* mp = static_cast<const JPH::SoftBodyMotionProperties*>(jBody->GetMotionProperties());
	const JPH::Array<JPH::SoftBodyVertex>& vertices = mp->GetVertices();
	const uint32_t numVertices = (uint32_t)vertices.size();
	const uint32_t writeCount = (capacity < numVertices) ? capacity : numVertices;

	JPH::RMat44 com_transform = jBody->GetCenterOfMassTransform();

	for (uint32_t i = 0; i < writeCount; ++i) {
		JPH::RVec3 worldPos = com_transform * vertices[i].mPosition;
		outPositions[i].x = (float)worldPos.GetX();
		outPositions[i].y = (float)worldPos.GetY();
		outPositions[i].z = (float)worldPos.GetZ();
	}

	if (outCount) *outCount = numVertices; // always report true count, not writeCount
}

/* Contact Listener */
class ManagedContactListener final : public JPH::ContactListener
{
public:
	static const JPH_ContactListener_Procs* s_Procs;
	void* userData = nullptr;

	ManagedContactListener(void* userData_)
		: userData(userData_)
	{

	}

	ValidateResult OnContactValidate(const Body& inBody1, const Body& inBody2, RVec3Arg inBaseOffset, const CollideShapeResult& inCollisionResult) override
	{
		JPH_UNUSED(inCollisionResult);
		JPH_RVec3 baseOffset;
		FromJolt(inBaseOffset, &baseOffset);

		if (s_Procs != nullptr
			&& s_Procs->OnContactValidate)
		{
			JPH_CollideShapeResult collideShapeResult = FromJolt(inCollisionResult);

			JPH_ValidateResult result = s_Procs->OnContactValidate(
				userData,
				reinterpret_cast<const JPH_Body*>(&inBody1),
				reinterpret_cast<const JPH_Body*>(&inBody2),
				&baseOffset,
				&collideShapeResult
			);
			
			JPH_CollideShapeResult_FreeMembers(&collideShapeResult);

			return (JPH::ValidateResult)result;
		}

		return JPH::ValidateResult::AcceptAllContactsForThisBodyPair;
	}

	void OnContactAdded(const Body& inBody1, const Body& inBody2, const ContactManifold& inManifold, ContactSettings& ioSettings) override
	{
		if (s_Procs != nullptr
			&& s_Procs->OnContactAdded)
		{
			JPH_ContactSettings settings;
			FromJolt(ioSettings, &settings);

			s_Procs->OnContactAdded(
				userData,
				reinterpret_cast<const JPH_Body*>(&inBody1),
				reinterpret_cast<const JPH_Body*>(&inBody2),
				ToContactManifold(&inManifold),
				&settings
			);

			// Copy back to jolt
			ToJolt(ioSettings, &settings);
		}
	}

	void OnContactPersisted(const Body& inBody1, const Body& inBody2, const ContactManifold& inManifold, ContactSettings& ioSettings) override
	{
		if (s_Procs != nullptr
			&& s_Procs->OnContactPersisted)
		{
			JPH_ContactSettings settings;
			FromJolt(ioSettings, &settings);

			s_Procs->OnContactPersisted(
				userData,
				reinterpret_cast<const JPH_Body*>(&inBody1),
				reinterpret_cast<const JPH_Body*>(&inBody2),
				ToContactManifold(&inManifold),
				&settings
			);

			// Copy back to jolt
			ToJolt(ioSettings, &settings);
		}
	}

	void OnContactRemoved(const SubShapeIDPair& inSubShapePair) override
	{
		if (s_Procs != nullptr
			&& s_Procs->OnContactRemoved)
		{
			s_Procs->OnContactRemoved(
				userData,
				reinterpret_cast<const JPH_SubShapeIDPair*>(&inSubShapePair)
			);
		}
	}

};

const JPH_ContactListener_Procs* ManagedContactListener::s_Procs = nullptr;

void JPH_ContactListener_SetProcs(const JPH_ContactListener_Procs* procs)
{
	ManagedContactListener::s_Procs = procs;
}

JPH_ContactListener* JPH_ContactListener_Create(void* userData)
{
	auto listener = new ManagedContactListener(userData);
	return reinterpret_cast<JPH_ContactListener*>(listener);
}

void JPH_ContactListener_Destroy(JPH_ContactListener* listener)
{
	if (listener)
	{
		delete reinterpret_cast<ManagedContactListener*>(listener);
	}
}

/* BodyActivationListener */
class ManagedBodyActivationListener final : public JPH::BodyActivationListener
{
public:
	static const JPH_BodyActivationListener_Procs* s_Procs;
	void* userData = nullptr;

	ManagedBodyActivationListener(void* userData_)
		: userData(userData_)
	{

	}

	void OnBodyActivated(const BodyID& inBodyID, uint64 inBodyUserData) override
	{
		if (s_Procs != nullptr && s_Procs->OnBodyActivated)
		{
			s_Procs->OnBodyActivated(
				userData,
				inBodyID.GetIndexAndSequenceNumber(),
				inBodyUserData
			);
		}
	}

	void OnBodyDeactivated(const BodyID& inBodyID, uint64 inBodyUserData) override
	{
		if (s_Procs != nullptr && s_Procs->OnBodyDeactivated)
		{
			s_Procs->OnBodyDeactivated(
				userData,
				inBodyID.GetIndexAndSequenceNumber(),
				inBodyUserData
			);
		}
	}
};

const JPH_BodyActivationListener_Procs* ManagedBodyActivationListener::s_Procs = nullptr;

void JPH_BodyActivationListener_SetProcs(const JPH_BodyActivationListener_Procs* procs)
{
	ManagedBodyActivationListener::s_Procs = procs;
}

JPH_BodyActivationListener* JPH_BodyActivationListener_Create(void* userData)
{
	auto listener = new ManagedBodyActivationListener(userData);
	return reinterpret_cast<JPH_BodyActivationListener*>(listener);
}

void JPH_BodyActivationListener_Destroy(JPH_BodyActivationListener* listener)
{
	if (listener)
	{
		delete reinterpret_cast<ManagedBodyActivationListener*>(listener);
	}
}

/* ContactManifold */
void JPH_ContactManifold_GetWorldSpaceNormal(const JPH_ContactManifold* manifold, JPH_Vec3* result)
{
	FromJolt(AsContactManifold(manifold)->mWorldSpaceNormal, result);
}

float JPH_ContactManifold_GetPenetrationDepth(const JPH_ContactManifold* manifold)
{
	return AsContactManifold(manifold)->mPenetrationDepth;
}

JPH_SubShapeID JPH_ContactManifold_GetSubShapeID1(const JPH_ContactManifold* manifold)
{
	return AsContactManifold(manifold)->mSubShapeID1.GetValue();
}

JPH_SubShapeID JPH_ContactManifold_GetSubShapeID2(const JPH_ContactManifold* manifold)
{
	return AsContactManifold(manifold)->mSubShapeID2.GetValue();
}

uint32_t JPH_ContactManifold_GetPointCount(const JPH_ContactManifold* manifold)
{
	return AsContactManifold(manifold)->mRelativeContactPointsOn1.size();
}

void JPH_ContactManifold_GetWorldSpaceContactPointOn1(const JPH_ContactManifold* manifold, uint32_t index, JPH_RVec3* result)
{
	FromJolt(AsContactManifold(manifold)->GetWorldSpaceContactPointOn1(index), result);
}

void JPH_ContactManifold_GetWorldSpaceContactPointOn2(const JPH_ContactManifold* manifold, uint32_t index, JPH_RVec3* result)
{
	FromJolt(AsContactManifold(manifold)->GetWorldSpaceContactPointOn2(index), result);
}

/* CharacterBaseSettings */
void JPH_CharacterBaseSettings_Init(const CharacterBaseSettings& joltSettings, JPH_CharacterBaseSettings* settings)
{
	// Copy defaults from jolt 
	FromJolt(joltSettings.mUp, &settings->up);
	FromJolt(joltSettings.mSupportingVolume, &settings->supportingVolume);
	settings->maxSlopeAngle = joltSettings.mMaxSlopeAngle;
	settings->enhancedInternalEdgeRemoval = joltSettings.mEnhancedInternalEdgeRemoval;
	if (joltSettings.mShape)
	{
		settings->shape = ToShape(joltSettings.mShape.GetPtr());
	}
	else
	{
		JPH_Vec3 vec = { 0.0f, 0.0f, 0.0f };
		JPH_EmptyShapeSettings* empty_shape_settings = JPH_EmptyShapeSettings_Create(&vec);
		JPH_EmptyShape* shape = JPH_EmptyShapeSettings_CreateShape(empty_shape_settings);
		settings->shape = reinterpret_cast<const JPH_Shape*>(shape);
	}
}

/* CharacterBase */
void JPH_CharacterBase_Destroy(JPH_CharacterBase* character)
{
	if (character)
	{
		auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
		joltCharacter->Release();
	}
}

float JPH_CharacterBase_GetCosMaxSlopeAngle(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return joltCharacter->GetCosMaxSlopeAngle();
}

void JPH_CharacterBase_SetMaxSlopeAngle(JPH_CharacterBase* character, float maxSlopeAngle)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	joltCharacter->SetMaxSlopeAngle(maxSlopeAngle);
}

void JPH_CharacterBase_GetUp(JPH_CharacterBase* character, JPH_Vec3* result)
{
	FromJolt(reinterpret_cast<JPH::CharacterBase*>(character)->GetUp(), result);
}

void JPH_CharacterBase_SetUp(JPH_CharacterBase* character, const JPH_Vec3* value)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	joltCharacter->SetUp(ToJolt(value));
}

bool JPH_CharacterBase_IsSlopeTooSteep(JPH_CharacterBase* character, const JPH_Vec3* value)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return joltCharacter->IsSlopeTooSteep(ToJolt(value));
}

const JPH_Shape* JPH_CharacterBase_GetShape(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return ToShape(joltCharacter->GetShape());
}

JPH_GroundState JPH_CharacterBase_GetGroundState(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return static_cast<JPH_GroundState>(joltCharacter->GetGroundState());
}

bool JPH_CharacterBase_IsSupported(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return joltCharacter->IsSupported();
}

void JPH_CharacterBase_GetGroundPosition(JPH_CharacterBase* character, JPH_RVec3* position)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	auto jolt_vector = joltCharacter->GetGroundPosition();
	FromJolt(jolt_vector, position);
}

void JPH_CharacterBase_GetGroundNormal(JPH_CharacterBase* character, JPH_Vec3* normal)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	auto jolt_vector = joltCharacter->GetGroundNormal();
	FromJolt(jolt_vector, normal);
}

void JPH_CharacterBase_GetGroundVelocity(JPH_CharacterBase* character, JPH_Vec3* velocity)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	auto jolt_vector = joltCharacter->GetGroundVelocity();
	FromJolt(jolt_vector, velocity);
}

const JPH_PhysicsMaterial* JPH_CharacterBase_GetGroundMaterial(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return reinterpret_cast<const JPH_PhysicsMaterial*>(joltCharacter->GetGroundMaterial());
}

JPH_BodyID JPH_CharacterBase_GetGroundBodyId(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return joltCharacter->GetGroundBodyID().GetIndexAndSequenceNumber();
}

JPH_SubShapeID JPH_CharacterBase_GetGroundSubShapeId(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return joltCharacter->GetGroundSubShapeID().GetValue();
}

uint64_t JPH_CharacterBase_GetGroundUserData(JPH_CharacterBase* character)
{
	auto joltCharacter = reinterpret_cast<JPH::CharacterBase*>(character);
	return joltCharacter->GetGroundUserData();
}

/* CharacterSettings */
void JPH_CharacterSettings_Init(JPH_CharacterSettings* settings)
{
	memset(settings, 0, sizeof(JPH_CharacterSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	JPH::CharacterSettings joltSettings;
	JPH_CharacterBaseSettings_Init(joltSettings, &settings->base);

	settings->layer = static_cast<JPH_ObjectLayer>(joltSettings.mLayer);
	settings->mass = joltSettings.mMass;
	settings->friction = joltSettings.mFriction;
	settings->gravityFactor = joltSettings.mGravityFactor;
	settings->allowedDOFs = static_cast<JPH_AllowedDOFs>(joltSettings.mAllowedDOFs);
}

/* Character */
JPH_Character* JPH_Character_Create(const JPH_CharacterSettings* settings,
	const JPH_RVec3* position,
	const JPH_Quat* rotation,
	uint64_t userData,
	JPH_PhysicsSystem* system)
{
	JPH_ASSERT(settings);

	JPH::CharacterSettings joltSettings;

	// Copy base settings
	joltSettings.mUp = ToJolt(settings->base.up);
	joltSettings.mSupportingVolume = ToJolt(&settings->base.supportingVolume);
	joltSettings.mMaxSlopeAngle = settings->base.maxSlopeAngle;
	joltSettings.mEnhancedInternalEdgeRemoval = settings->base.enhancedInternalEdgeRemoval;
	if (settings->base.shape)
	{
		auto joltShape = reinterpret_cast<const JPH::Shape*>(settings->base.shape);
		joltSettings.mShape = joltShape;
	}

	joltSettings.mLayer = static_cast<ObjectLayer>(settings->layer);
	joltSettings.mMass = settings->mass;
	joltSettings.mFriction = settings->friction;
	joltSettings.mGravityFactor = settings->gravityFactor;
	joltSettings.mAllowedDOFs = static_cast<EAllowedDOFs>(settings->allowedDOFs);

	auto joltCharacter = new JPH::Character(&joltSettings,
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		userData,
		system->physicsSystem);
	joltCharacter->AddRef();

	return reinterpret_cast<JPH_Character*>(joltCharacter);
}

void JPH_Character_AddToPhysicsSystem(JPH_Character* character, JPH_Activation activationMode, bool lockBodies)
{
	AsCharacter(character)->AddToPhysicsSystem(static_cast<JPH::EActivation>(activationMode), lockBodies);
}

void JPH_Character_RemoveFromPhysicsSystem(JPH_Character* character, bool lockBodies)
{
	AsCharacter(character)->RemoveFromPhysicsSystem(lockBodies);
}

void JPH_Character_Activate(JPH_Character* character, bool lockBodies)
{
	AsCharacter(character)->Activate(lockBodies);
}

void JPH_Character_PostSimulation(JPH_Character* character, float maxSeparationDistance, bool lockBodies)
{
	AsCharacter(character)->PostSimulation(maxSeparationDistance, lockBodies);
}

void JPH_Character_SetLinearAndAngularVelocity(JPH_Character* character, JPH_Vec3* linearVelocity, JPH_Vec3* angularVelocity, bool lockBodies)
{
	AsCharacter(character)->SetLinearAndAngularVelocity(ToJolt(linearVelocity), ToJolt(angularVelocity), lockBodies);
}

void JPH_Character_GetLinearVelocity(JPH_Character* character, JPH_Vec3* result)
{
	FromJolt(AsCharacter(character)->GetLinearVelocity(), result);
}

void JPH_Character_SetLinearVelocity(JPH_Character* character, const JPH_Vec3* value, bool lockBodies)
{
	AsCharacter(character)->SetLinearVelocity(ToJolt(value), lockBodies);
}

void JPH_Character_AddLinearVelocity(JPH_Character* character, const JPH_Vec3* value, bool lockBodies)
{
	AsCharacter(character)->AddLinearVelocity(ToJolt(value), lockBodies);
}

void JPH_Character_AddImpulse(JPH_Character* character, const JPH_Vec3* value, bool lockBodies)
{
	AsCharacter(character)->AddImpulse(ToJolt(value), lockBodies);
}

JPH_BodyID JPH_Character_GetBodyID(const JPH_Character* character)
{
	return AsCharacter(character)->GetBodyID().GetIndexAndSequenceNumber();
}

void JPH_Character_GetPositionAndRotation(JPH_Character* character, JPH_RVec3* position, JPH_Quat* rotation, bool lockBodies)
{
	JPH::RVec3 joltPosition;
	JPH::Quat joltRotation;
	AsCharacter(character)->GetPositionAndRotation(joltPosition, joltRotation, lockBodies);
	FromJolt(joltPosition, position);
	FromJolt(joltRotation, rotation);
}

void JPH_Character_SetPositionAndRotation(JPH_Character* character, const JPH_RVec3* position, const JPH_Quat* rotation, JPH_Activation activationMode, bool lockBodies /* = true */)
{
	AsCharacter(character)->SetPositionAndRotation(
		ToJolt(position),
		ToJolt(rotation),
		static_cast<JPH::EActivation>(activationMode),
		lockBodies);
}

void JPH_Character_GetPosition(JPH_Character* character, JPH_RVec3* position, bool lockBodies)
{
	FromJolt(AsCharacter(character)->GetPosition(lockBodies), position);
}

void JPH_Character_SetPosition(JPH_Character* character, const JPH_RVec3* position, JPH_Activation activationMode, bool lockBodies)
{
	AsCharacter(character)->SetPosition(ToJolt(position), static_cast<JPH::EActivation>(activationMode), lockBodies);
}

void JPH_Character_SetShape(JPH_Character* character, const JPH_Shape* shape, float maxPenetrationDepth, bool lockBodies)
{
	AsCharacter(character)->SetShape(AsShape(shape), maxPenetrationDepth, lockBodies);
}

void JPH_Character_GetRotation(JPH_Character* character, JPH_Quat* rotation, bool lockBodies)
{
	FromJolt(AsCharacter(character)->GetRotation(lockBodies), rotation);
}

void JPH_Character_SetRotation(JPH_Character* character, const JPH_Quat* rotation, JPH_Activation activationMode, bool lockBodies)
{
	AsCharacter(character)->SetRotation(ToJolt(rotation), static_cast<JPH::EActivation>(activationMode), lockBodies);
}

void JPH_Character_GetCenterOfMassPosition(JPH_Character* character, JPH_RVec3* result, bool lockBodies)
{
	FromJolt(AsCharacter(character)->GetCenterOfMassPosition(lockBodies), result);
}

void JPH_Character_GetWorldTransform(JPH_Character* character, JPH_RMat4* result, bool lockBodies)
{
	FromJolt(AsCharacter(character)->GetWorldTransform(lockBodies), result);
}

JPH_ObjectLayer JPH_Character_GetLayer(const JPH_Character* character)
{
	return static_cast<JPH_ObjectLayer>(AsCharacter(character)->GetLayer());
}

void JPH_Character_SetLayer(JPH_Character* character, JPH_ObjectLayer value, bool lockBodies)
{
	AsCharacter(character)->SetLayer(static_cast<JPH::ObjectLayer>(value), lockBodies);
}

/* CharacterVirtualSettings */
void JPH_CharacterVirtualSettings_Init(JPH_CharacterVirtualSettings* settings)
{
	memset(settings, 0, sizeof(JPH_CharacterVirtualSettings));

	// Copy defaults from jolt 
	JPH::CharacterVirtualSettings joltSettings;
	JPH_CharacterBaseSettings_Init(joltSettings, &settings->base);

	settings->ID = (JPH_CharacterID)joltSettings.mID.GetValue();
	settings->mass = joltSettings.mMass;
	settings->maxStrength = joltSettings.mMaxStrength;
	settings->shapeOffset = FromJolt(joltSettings.mShapeOffset);
	settings->backFaceMode = static_cast<JPH_BackFaceMode>(joltSettings.mBackFaceMode);
	settings->predictiveContactDistance = joltSettings.mPredictiveContactDistance;
	settings->maxCollisionIterations = joltSettings.mMaxCollisionIterations;
	settings->maxConstraintIterations = joltSettings.mMaxConstraintIterations;
	settings->minTimeRemaining = joltSettings.mMinTimeRemaining;
	settings->collisionTolerance = joltSettings.mCollisionTolerance;
	settings->characterPadding = joltSettings.mCharacterPadding;
	settings->maxNumHits = joltSettings.mMaxNumHits;
	settings->hitReductionCosMaxAngle = joltSettings.mHitReductionCosMaxAngle;
	settings->penetrationRecoverySpeed = joltSettings.mPenetrationRecoverySpeed;
	if (joltSettings.mInnerBodyShape)
	{
		settings->innerBodyShape = reinterpret_cast<const JPH_Shape*>(joltSettings.mInnerBodyShape.GetPtr());
	}
	settings->innerBodyIDOverride = joltSettings.mInnerBodyIDOverride.GetIndexAndSequenceNumber();
	settings->innerBodyLayer = static_cast<JPH_ObjectLayer>(joltSettings.mInnerBodyLayer);
}

/* CharacterVirtual */
JPH_CharacterVirtual* JPH_CharacterVirtual_Create(const JPH_CharacterVirtualSettings* settings,
	const JPH_RVec3* position,
	const JPH_Quat* rotation,
	uint64_t userData,
	JPH_PhysicsSystem* system)
{
	JPH_ASSERT(settings);

	JPH::CharacterVirtualSettings joltSettings;

	// Copy base settings
	joltSettings.mUp = ToJolt(settings->base.up);
	joltSettings.mSupportingVolume = ToJolt(&settings->base.supportingVolume);
	joltSettings.mMaxSlopeAngle = settings->base.maxSlopeAngle;
	joltSettings.mEnhancedInternalEdgeRemoval = settings->base.enhancedInternalEdgeRemoval;
	if (settings->base.shape)
	{
		auto joltShape = reinterpret_cast<const JPH::Shape*>(settings->base.shape);
		joltSettings.mShape = joltShape;
	}

	if (settings->ID)
	{
		joltSettings.mID = JPH::CharacterID(settings->ID);
	}

	joltSettings.mMass = settings->mass;
	joltSettings.mMaxStrength = settings->maxStrength;
	joltSettings.mShapeOffset = ToJolt(settings->shapeOffset);
	joltSettings.mBackFaceMode = static_cast<EBackFaceMode>(settings->backFaceMode);
	joltSettings.mPredictiveContactDistance = settings->predictiveContactDistance;
	joltSettings.mMaxCollisionIterations = settings->maxCollisionIterations;
	joltSettings.mMaxConstraintIterations = settings->maxConstraintIterations;
	joltSettings.mMinTimeRemaining = settings->minTimeRemaining;
	joltSettings.mCollisionTolerance = settings->collisionTolerance;
	joltSettings.mCharacterPadding = settings->characterPadding;
	joltSettings.mMaxNumHits = settings->maxNumHits;
	joltSettings.mHitReductionCosMaxAngle = settings->hitReductionCosMaxAngle;
	joltSettings.mPenetrationRecoverySpeed = settings->penetrationRecoverySpeed;
	if (settings->innerBodyShape)
	{
		auto joltShape = reinterpret_cast<const JPH::Shape*>(settings->innerBodyShape);
		joltSettings.mInnerBodyShape = joltShape;
	}

	if (settings->innerBodyIDOverride)
	{
		joltSettings.mInnerBodyIDOverride = JPH::BodyID(settings->innerBodyIDOverride);
	}

	joltSettings.mInnerBodyLayer = static_cast<ObjectLayer>(settings->innerBodyLayer);

	auto joltCharacter = new JPH::CharacterVirtual(&joltSettings,
		ToJolt(position),
		rotation != nullptr ? ToJolt(rotation) : JPH::Quat::sIdentity(),
		userData,
		system->physicsSystem);
	joltCharacter->AddRef();

	return ToCharacterVirtual(joltCharacter);
}

JPH_CharacterID JPH_CharacterVirtual_GetID(const JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetID().GetValue();
}

void JPH_CharacterVirtual_SetListener(JPH_CharacterVirtual* character, JPH_CharacterContactListener* listener)
{
	if (listener)
	{
		auto joltListener = reinterpret_cast<JPH::CharacterContactListener*>(listener);
		AsCharacterVirtual(character)->SetListener(joltListener);
	}
	else
	{
		AsCharacterVirtual(character)->SetListener(nullptr);
	}
}

void JPH_CharacterVirtual_SetCharacterVsCharacterCollision(JPH_CharacterVirtual* character, JPH_CharacterVsCharacterCollision* characterVsCharacterCollision)
{
	if (characterVsCharacterCollision)
	{
		auto joltCharacterVsCharacterCollision = reinterpret_cast<JPH::CharacterVsCharacterCollision*>(characterVsCharacterCollision);
		AsCharacterVirtual(character)->SetCharacterVsCharacterCollision(joltCharacterVsCharacterCollision);
	}
	else
	{
		AsCharacterVirtual(character)->SetCharacterVsCharacterCollision(nullptr);
	}
}

void JPH_CharacterVirtual_GetLinearVelocity(JPH_CharacterVirtual* character, JPH_Vec3* velocity)
{
	FromJolt(AsCharacterVirtual(character)->GetLinearVelocity(), velocity);
}

void JPH_CharacterVirtual_SetLinearVelocity(JPH_CharacterVirtual* character, const JPH_Vec3* velocity)
{
	AsCharacterVirtual(character)->SetLinearVelocity(ToJolt(velocity));
}

void JPH_CharacterVirtual_GetPosition(JPH_CharacterVirtual* character, JPH_RVec3* position)
{
	FromJolt(AsCharacterVirtual(character)->GetPosition(), position);
}

void JPH_CharacterVirtual_SetPosition(JPH_CharacterVirtual* character, const JPH_RVec3* position)
{
	AsCharacterVirtual(character)->SetPosition(ToJolt(position));
}

void JPH_CharacterVirtual_GetRotation(JPH_CharacterVirtual* character, JPH_Quat* rotation)
{
	auto jolt_quat = AsCharacterVirtual(character)->GetRotation();
	FromJolt(jolt_quat, rotation);
}

void JPH_CharacterVirtual_SetRotation(JPH_CharacterVirtual* character, const JPH_Quat* rotation)
{
	AsCharacterVirtual(character)->SetRotation(ToJolt(rotation));
}

void JPH_CharacterVirtual_GetWorldTransform(JPH_CharacterVirtual* character, JPH_RMat4* result)
{
	const JPH::RMat44& mat = AsCharacterVirtual(character)->GetWorldTransform();
	FromJolt(mat, result);
}

void JPH_CharacterVirtual_GetCenterOfMassTransform(JPH_CharacterVirtual* character, JPH_RMat4* result)
{
	const JPH::RMat44& mat = AsCharacterVirtual(character)->GetCenterOfMassTransform();
	FromJolt(mat, result);
}

float JPH_CharacterVirtual_GetMass(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetMass();
}

void JPH_CharacterVirtual_SetMass(JPH_CharacterVirtual* character, float value)
{
	AsCharacterVirtual(character)->SetMass(value);
}

float JPH_CharacterVirtual_GetMaxStrength(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetMaxStrength();
}

void JPH_CharacterVirtual_SetMaxStrength(JPH_CharacterVirtual* character, float value)
{
	AsCharacterVirtual(character)->SetMaxStrength(value);
}

float JPH_CharacterVirtual_GetPenetrationRecoverySpeed(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetPenetrationRecoverySpeed();
}

void JPH_CharacterVirtual_SetPenetrationRecoverySpeed(JPH_CharacterVirtual* character, float value)
{
	AsCharacterVirtual(character)->SetPenetrationRecoverySpeed(value);
}

bool JPH_CharacterVirtual_GetEnhancedInternalEdgeRemoval(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetEnhancedInternalEdgeRemoval();
}

void JPH_CharacterVirtual_SetEnhancedInternalEdgeRemoval(JPH_CharacterVirtual* character, bool value)
{
	AsCharacterVirtual(character)->SetEnhancedInternalEdgeRemoval(value);
}

float JPH_CharacterVirtual_GetCharacterPadding(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetCharacterPadding();
}

uint32_t JPH_CharacterVirtual_GetMaxNumHits(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetMaxNumHits();
}

void JPH_CharacterVirtual_SetMaxNumHits(JPH_CharacterVirtual* character, uint32_t value)
{
	AsCharacterVirtual(character)->SetMaxNumHits(value);
}

float JPH_CharacterVirtual_GetHitReductionCosMaxAngle(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetHitReductionCosMaxAngle();
}

void JPH_CharacterVirtual_SetHitReductionCosMaxAngle(JPH_CharacterVirtual* character, float value)
{
	AsCharacterVirtual(character)->SetHitReductionCosMaxAngle(value);
}

bool JPH_CharacterVirtual_GetMaxHitsExceeded(JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetMaxHitsExceeded();
}

void JPH_CharacterVirtual_GetShapeOffset(JPH_CharacterVirtual* character, JPH_Vec3* result)
{
	auto joltVector = AsCharacterVirtual(character)->GetShapeOffset();
	FromJolt(joltVector, result);
}

void JPH_CharacterVirtual_SetShapeOffset(JPH_CharacterVirtual* character, const JPH_Vec3* value)
{
	AsCharacterVirtual(character)->SetShapeOffset(ToJolt(value));
}

uint64_t JPH_CharacterVirtual_GetUserData(const JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetUserData();
}

void JPH_CharacterVirtual_SetUserData(JPH_CharacterVirtual* character, uint64_t value)
{
	AsCharacterVirtual(character)->SetUserData(value);
}

JPH_BodyID JPH_CharacterVirtual_GetInnerBodyID(const JPH_CharacterVirtual* character)
{
	return AsCharacterVirtual(character)->GetInnerBodyID().GetIndexAndSequenceNumber();
}

void JPH_CharacterVirtual_CancelVelocityTowardsSteepSlopes(JPH_CharacterVirtual* character, const JPH_Vec3* desiredVelocity, JPH_Vec3* velocity)
{
	FromJolt(AsCharacterVirtual(character)->CancelVelocityTowardsSteepSlopes(ToJolt(desiredVelocity)), velocity);
}

void JPH_CharacterVirtual_StartTrackingContactChanges(JPH_CharacterVirtual* character)
{
	AsCharacterVirtual(character)->StartTrackingContactChanges();
}

void JPH_CharacterVirtual_FinishTrackingContactChanges(JPH_CharacterVirtual* character)
{
	AsCharacterVirtual(character)->FinishTrackingContactChanges();
}

void JPH_CharacterVirtual_Update(JPH_CharacterVirtual* character,
	float deltaTime, JPH_ObjectLayer layer, JPH_PhysicsSystem* system,
	const JPH_BodyFilter* bodyFilter, const JPH_ShapeFilter* shapeFilter)
{
	auto joltLayer = static_cast<JPH::ObjectLayer>(layer);

	AsCharacterVirtual(character)->Update(deltaTime,
		system->physicsSystem->GetGravity(),
		system->physicsSystem->GetDefaultBroadPhaseLayerFilter(joltLayer),
		system->physicsSystem->GetDefaultLayerFilter(joltLayer),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter),
		*s_TempAllocator
	);
}

void JPH_CharacterVirtual_ExtendedUpdate(JPH_CharacterVirtual* character, float deltaTime,
	const JPH_ExtendedUpdateSettings* settings, JPH_ObjectLayer layer, JPH_PhysicsSystem* system,
	const JPH_BodyFilter* bodyFilter, const JPH_ShapeFilter* shapeFilter)
{
	JPH_ASSERT(settings);

	// Convert to Jolt
	JPH::CharacterVirtual::ExtendedUpdateSettings joltSettings = {};
	joltSettings.mStickToFloorStepDown = ToJolt(&settings->stickToFloorStepDown);
	joltSettings.mWalkStairsStepUp = ToJolt(&settings->walkStairsStepUp);
	joltSettings.mWalkStairsMinStepForward = settings->walkStairsMinStepForward;
	joltSettings.mWalkStairsStepForwardTest = settings->walkStairsStepForwardTest;
	joltSettings.mWalkStairsCosAngleForwardContact = settings->walkStairsCosAngleForwardContact;
	joltSettings.mWalkStairsStepDownExtra = ToJolt(&settings->walkStairsStepDownExtra);

	auto joltLayer = static_cast<JPH::ObjectLayer>(layer);

	AsCharacterVirtual(character)->ExtendedUpdate(deltaTime,
		system->physicsSystem->GetGravity(),
		joltSettings,
		system->physicsSystem->GetDefaultBroadPhaseLayerFilter(joltLayer),
		system->physicsSystem->GetDefaultLayerFilter(joltLayer),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter),
		*s_TempAllocator
	);
}

void JPH_CharacterVirtual_RefreshContacts(JPH_CharacterVirtual* character,
	JPH_ObjectLayer layer,
	JPH_PhysicsSystem* system,
	const JPH_BodyFilter* bodyFilter, const JPH_ShapeFilter* shapeFilter)
{
	auto joltLayer = static_cast<JPH::ObjectLayer>(layer);

	AsCharacterVirtual(character)->RefreshContacts(
		system->physicsSystem->GetDefaultBroadPhaseLayerFilter(joltLayer),
		system->physicsSystem->GetDefaultLayerFilter(joltLayer),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter),
		*s_TempAllocator
	);
}

bool JPH_CharacterVirtual_CanWalkStairs(JPH_CharacterVirtual* character, const JPH_Vec3* linearVelocity)
{
	return AsCharacterVirtual(character)->CanWalkStairs(ToJolt(linearVelocity));
}

bool JPH_CharacterVirtual_WalkStairs(JPH_CharacterVirtual* character, float deltaTime,
	const JPH_Vec3* stepUp,
	const JPH_Vec3* stepForward,
	const JPH_Vec3* stepForwardTest,
	const JPH_Vec3* stepDownExtra,
	JPH_ObjectLayer layer,
	JPH_PhysicsSystem* system,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	auto joltLayer = static_cast<JPH::ObjectLayer>(layer);

	return AsCharacterVirtual(character)->WalkStairs(
		deltaTime,
		ToJolt(stepUp),
		ToJolt(stepForward),
		ToJolt(stepForwardTest),
		ToJolt(stepDownExtra),
		system->physicsSystem->GetDefaultBroadPhaseLayerFilter(joltLayer),
		system->physicsSystem->GetDefaultLayerFilter(joltLayer),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter),
		*s_TempAllocator
	);
}

bool JPH_CharacterVirtual_StickToFloor(JPH_CharacterVirtual* character, const JPH_Vec3* stepDown,
	JPH_ObjectLayer layer, JPH_PhysicsSystem* system,
	const JPH_BodyFilter* bodyFilter, const JPH_ShapeFilter* shapeFilter)
{
	auto joltLayer = static_cast<JPH::ObjectLayer>(layer);

	return AsCharacterVirtual(character)->StickToFloor(
		ToJolt(stepDown),
		system->physicsSystem->GetDefaultBroadPhaseLayerFilter(joltLayer),
		system->physicsSystem->GetDefaultLayerFilter(joltLayer),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter),
		*s_TempAllocator
	);
}

void JPH_CharacterVirtual_UpdateGroundVelocity(JPH_CharacterVirtual* character)
{
	AsCharacterVirtual(character)->UpdateGroundVelocity();
}

bool JPH_CharacterVirtual_SetShape(JPH_CharacterVirtual* character,
	const JPH_Shape* shape,
	float maxPenetrationDepth,
	JPH_ObjectLayer layer,
	JPH_PhysicsSystem* system,
	const JPH_BodyFilter* bodyFilter,
	const JPH_ShapeFilter* shapeFilter)
{
	auto joltLayer = static_cast<JPH::ObjectLayer>(layer);
	return AsCharacterVirtual(character)->SetShape(
		AsShape(shape),
		maxPenetrationDepth,
		system->physicsSystem->GetDefaultBroadPhaseLayerFilter(joltLayer),
		system->physicsSystem->GetDefaultLayerFilter(joltLayer),
		ToJolt(bodyFilter),
		ToJolt(shapeFilter),
		*s_TempAllocator
	);
}

void JPH_CharacterVirtual_SetInnerBodyShape(JPH_CharacterVirtual* character, const JPH_Shape* shape)
{
	AsCharacterVirtual(character)->SetInnerBodyShape(AsShape(shape));
}

uint32_t JPH_CharacterVirtual_GetNumActiveContacts(JPH_CharacterVirtual* character)
{
	return (uint32_t)AsCharacterVirtual(character)->GetActiveContacts().size();
}

void JPH_CharacterVirtual_GetActiveContact(JPH_CharacterVirtual* character, uint32_t index, JPH_CharacterContact* result)
{
	FromJolt(AsCharacterVirtual(character)->GetActiveContacts().at(index), result);
}

bool JPH_CharacterVirtual_HasCollidedWithBody(JPH_CharacterVirtual* character, const JPH_BodyID body)
{
	return AsCharacterVirtual(character)->HasCollidedWith(JPH::BodyID(body));
}

bool JPH_CharacterVirtual_HasCollidedWith(JPH_CharacterVirtual* character, const JPH_CharacterID other)
{
	return AsCharacterVirtual(character)->HasCollidedWith(JPH::CharacterID(other));
}

bool JPH_CharacterVirtual_HasCollidedWithCharacter(JPH_CharacterVirtual* character, const JPH_CharacterVirtual* other)
{
	return AsCharacterVirtual(character)->HasCollidedWith(AsCharacterVirtual(other));
}

/* CharacterContactListener */
class ManagedCharacterContactListener final : public JPH::CharacterContactListener
{
public:
	static const JPH_CharacterContactListener_Procs* s_Procs;
	void* userData = nullptr;

	ManagedCharacterContactListener(void* userData_)
		: userData(userData_)
	{

	}

	void OnAdjustBodyVelocity(const CharacterVirtual* inCharacter, const Body& inBody2, Vec3& ioLinearVelocity, Vec3& ioAngularVelocity) override
	{
		JPH_Vec3 linearVelocity, angularVelocity;
		FromJolt(ioLinearVelocity, &linearVelocity);
		FromJolt(ioAngularVelocity, &angularVelocity);

		if (s_Procs != nullptr && s_Procs->OnAdjustBodyVelocity)
		{
			s_Procs->OnAdjustBodyVelocity(
				userData,
				ToCharacterVirtual(inCharacter),
				ToBody(&inBody2),
				&linearVelocity,
				&angularVelocity
			);

			ioLinearVelocity = ToJolt(linearVelocity);
			ioAngularVelocity = ToJolt(angularVelocity);
		}
	}

	bool OnContactValidate(const CharacterVirtual* inCharacter, const CharacterContact& inContact) override
	{
		if (s_Procs != nullptr && s_Procs->OnContactValidate)
		{
			JPH_CharacterContact contact;
			FromJolt(inContact, &contact);

			return s_Procs->OnContactValidate(
				userData,
				ToCharacterVirtual(inCharacter),
				&contact
			);
		}

		return true;
	}

	bool OnCharacterContactValidate(const CharacterVirtual* inCharacter, const CharacterContact& inContact) override
	{
		if (s_Procs != nullptr && s_Procs->OnCharacterContactValidate)
		{
			JPH_CharacterContact contact;
			FromJolt(inContact, &contact);

			return s_Procs->OnCharacterContactValidate(
				userData,
				ToCharacterVirtual(inCharacter),
				&contact
			);
		}

		return true;
	}

	void OnContactAdded(const CharacterVirtual* inCharacter, const CharacterContact& inContact, CharacterContactSettings& ioSettings) override
	{
		if (s_Procs != nullptr && s_Procs->OnContactAdded)
		{
			JPH_CharacterContact contact;
			FromJolt(inContact, &contact);

			JPH_CharacterContactSettings settings = {};
			settings.canPushCharacter = ioSettings.mCanPushCharacter;
			settings.canReceiveImpulses = ioSettings.mCanReceiveImpulses;

			s_Procs->OnContactAdded(
				userData,
				ToCharacterVirtual(inCharacter),
				&contact,
				&settings
			);

			ioSettings.mCanPushCharacter = settings.canPushCharacter;
			ioSettings.mCanReceiveImpulses = settings.canReceiveImpulses;
		}
	}

	void OnContactPersisted(const CharacterVirtual* inCharacter, const CharacterContact& inContact, CharacterContactSettings& ioSettings) override
	{
		if (s_Procs != nullptr && s_Procs->OnContactPersisted)
		{
			JPH_CharacterContact contact;
			FromJolt(inContact, &contact);

			JPH_CharacterContactSettings settings = {};
			settings.canPushCharacter = ioSettings.mCanPushCharacter;
			settings.canReceiveImpulses = ioSettings.mCanReceiveImpulses;

			s_Procs->OnContactPersisted(
				userData,
				ToCharacterVirtual(inCharacter),
				&contact,
				&settings
			);

			ioSettings.mCanPushCharacter = settings.canPushCharacter;
			ioSettings.mCanReceiveImpulses = settings.canReceiveImpulses;
		}
	}

	void OnContactRemoved(const CharacterVirtual* inCharacter, const BodyID& inBodyID2, const SubShapeID& inSubShapeID2) override
	{
		if (s_Procs != nullptr && s_Procs->OnContactRemoved)
		{
			s_Procs->OnContactRemoved(
				userData,
				ToCharacterVirtual(inCharacter),
				(JPH_BodyID)inBodyID2.GetIndexAndSequenceNumber(),
				(JPH_SubShapeID)inSubShapeID2.GetValue()
			);
		}
	}

	void OnCharacterContactAdded(const CharacterVirtual* inCharacter, const CharacterContact& inContact, CharacterContactSettings& ioSettings) override
	{
		if (s_Procs != nullptr && s_Procs->OnCharacterContactAdded)
		{
			JPH_CharacterContact contact;
			FromJolt(inContact, &contact);

			JPH_CharacterContactSettings settings = {};
			settings.canPushCharacter = ioSettings.mCanPushCharacter;
			settings.canReceiveImpulses = ioSettings.mCanReceiveImpulses;

			s_Procs->OnCharacterContactAdded(
				userData,
				ToCharacterVirtual(inCharacter),
				&contact,
				&settings
			);

			ioSettings.mCanPushCharacter = settings.canPushCharacter;
			ioSettings.mCanReceiveImpulses = settings.canReceiveImpulses;
		}
	}

	void OnCharacterContactPersisted(const CharacterVirtual* inCharacter, const CharacterContact& inContact, CharacterContactSettings& ioSettings) override
	{
		if (s_Procs != nullptr && s_Procs->OnCharacterContactPersisted)
		{
			JPH_CharacterContact contact;
			FromJolt(inContact, &contact);

			JPH_CharacterContactSettings settings = {};
			settings.canPushCharacter = ioSettings.mCanPushCharacter;
			settings.canReceiveImpulses = ioSettings.mCanReceiveImpulses;

			s_Procs->OnCharacterContactPersisted(
				userData,
				ToCharacterVirtual(inCharacter),
				&contact,
				&settings
			);

			ioSettings.mCanPushCharacter = settings.canPushCharacter;
			ioSettings.mCanReceiveImpulses = settings.canReceiveImpulses;
		}
	}

	void OnCharacterContactRemoved(const CharacterVirtual* inCharacter, const CharacterID& inOtherCharacterID, const SubShapeID& inSubShapeID2) override
	{
		if (s_Procs != nullptr && s_Procs->OnCharacterContactRemoved)
		{
			s_Procs->OnCharacterContactRemoved(
				userData,
				ToCharacterVirtual(inCharacter),
				(JPH_CharacterID)inOtherCharacterID.GetValue(),
				(JPH_SubShapeID)inSubShapeID2.GetValue()
			);
		}
	}

	void OnContactSolve(const CharacterVirtual* inCharacter, const BodyID& inBodyID2, const SubShapeID& inSubShapeID2,
		RVec3Arg inContactPosition, Vec3Arg inContactNormal, Vec3Arg inContactVelocity,
		const PhysicsMaterial* inContactMaterial, Vec3Arg inCharacterVelocity,
		Vec3& ioNewCharacterVelocity) override
	{
		if (s_Procs != nullptr && s_Procs->OnContactSolve)
		{
			JPH_RVec3 contactPosition;
			JPH_Vec3 contactNormal, contactVelocity, characterVelocity, newCharacterVelocity;

			FromJolt(inContactPosition, &contactPosition);
			FromJolt(inContactNormal, &contactNormal);
			FromJolt(inContactVelocity, &contactVelocity);
			FromJolt(inCharacterVelocity, &characterVelocity);
			FromJolt(ioNewCharacterVelocity, &newCharacterVelocity);

			s_Procs->OnContactSolve(
				userData,
				ToCharacterVirtual(inCharacter),
				(JPH_BodyID)inBodyID2.GetIndexAndSequenceNumber(),
				(JPH_SubShapeID)inSubShapeID2.GetValue(),
				&contactPosition,
				&contactNormal,
				&contactVelocity,
				reinterpret_cast<const JPH_PhysicsMaterial*>(inContactMaterial),
				&characterVelocity,
				&newCharacterVelocity
			);

			ioNewCharacterVelocity = ToJolt(newCharacterVelocity);
		}
	}

	void OnCharacterContactSolve(const CharacterVirtual* inCharacter, const CharacterVirtual* inOtherCharacter, const SubShapeID& inSubShapeID2, RVec3Arg inContactPosition, Vec3Arg inContactNormal, Vec3Arg inContactVelocity, const PhysicsMaterial* inContactMaterial, Vec3Arg inCharacterVelocity, Vec3& ioNewCharacterVelocity) override
	{
		if (s_Procs != nullptr && s_Procs->OnCharacterContactSolve)
		{
			JPH_RVec3 contactPosition;
			JPH_Vec3 contactNormal, contactVelocity, characterVelocity, newCharacterVelocity;

			FromJolt(inContactPosition, &contactPosition);
			FromJolt(inContactNormal, &contactNormal);
			FromJolt(inContactVelocity, &contactVelocity);
			FromJolt(inCharacterVelocity, &characterVelocity);
			FromJolt(ioNewCharacterVelocity, &newCharacterVelocity);

			s_Procs->OnCharacterContactSolve(
				userData,
				ToCharacterVirtual(inCharacter),
				ToCharacterVirtual(inOtherCharacter),
				(JPH_SubShapeID)inSubShapeID2.GetValue(),
				&contactPosition,
				&contactNormal,
				&contactVelocity,
				reinterpret_cast<const JPH_PhysicsMaterial*>(inContactMaterial),
				&characterVelocity,
				&newCharacterVelocity
			);

			ioNewCharacterVelocity = ToJolt(newCharacterVelocity);
		}
	}
};

const JPH_CharacterContactListener_Procs* ManagedCharacterContactListener::s_Procs = nullptr;

void JPH_CharacterContactListener_SetProcs(const JPH_CharacterContactListener_Procs* procs)
{
	ManagedCharacterContactListener::s_Procs = procs;
}

JPH_CharacterContactListener* JPH_CharacterContactListener_Create(void* userData)
{
	auto impl = new ManagedCharacterContactListener(userData);
	return reinterpret_cast<JPH_CharacterContactListener*>(impl);
}

void JPH_CharacterContactListener_Destroy(JPH_CharacterContactListener* listener)
{
	if (listener)
	{
		delete reinterpret_cast<ManagedCharacterContactListener*>(listener);
	}
}

/* JPH_CharacterVsCharacterCollision */
class ManagedCharacterVsCharacterCollision final : public JPH::CharacterVsCharacterCollision
{
public:
	static const JPH_CharacterVsCharacterCollision_Procs* s_Procs;
	void* userData = nullptr;

	ManagedCharacterVsCharacterCollision(void* userData_)
		: userData(userData_)
	{

	}

	void CollideCharacter(const CharacterVirtual* inCharacter,
		RMat44Arg inCenterOfMassTransform,
		const CollideShapeSettings& inCollideShapeSettings,
		RVec3Arg inBaseOffset,
		CollideShapeCollector& ioCollector) const override
	{
		if (s_Procs != nullptr && s_Procs->CollideCharacter)
		{
			JPH_RMat4 centerOfMassTransform;
			JPH_RVec3 baseOffset;

			JPH_CollideShapeSettings collideShapeSettings = FromJolt(inCollideShapeSettings);
			FromJolt(inCenterOfMassTransform, &centerOfMassTransform);
			FromJolt(inBaseOffset, &baseOffset);

			s_Procs->CollideCharacter(
				userData,
				ToCharacterVirtual(inCharacter),
				&centerOfMassTransform,
				&collideShapeSettings,
				&baseOffset
			);
		}
	}

	void CastCharacter(const CharacterVirtual* inCharacter,
		RMat44Arg inCenterOfMassTransform,
		Vec3Arg inDirection,
		const ShapeCastSettings& inShapeCastSettings,
		RVec3Arg inBaseOffset,
		CastShapeCollector& ioCollector) const override
	{
		if (s_Procs != nullptr && s_Procs->CastCharacter)
		{
			JPH_RMat4 centerOfMassTransform;
			JPH_Vec3 direction;
			JPH_RVec3 baseOffset;

			JPH_ShapeCastSettings shapeCastSettings = FromJolt(inShapeCastSettings);
			FromJolt(inCenterOfMassTransform, &centerOfMassTransform);
			FromJolt(inDirection, &direction);
			FromJolt(inBaseOffset, &baseOffset);

			s_Procs->CastCharacter(
				userData,
				ToCharacterVirtual(inCharacter),
				&centerOfMassTransform,
				&direction,
				&shapeCastSettings,
				&baseOffset
			);
		}
	}
};

const JPH_CharacterVsCharacterCollision_Procs* ManagedCharacterVsCharacterCollision::s_Procs = nullptr;

void JPH_CharacterVsCharacterCollision_SetProcs(const JPH_CharacterVsCharacterCollision_Procs* procs)
{
	ManagedCharacterVsCharacterCollision::s_Procs = procs;
}

JPH_CharacterVsCharacterCollision* JPH_CharacterVsCharacterCollision_Create(void* userData)
{
	auto impl = new ManagedCharacterVsCharacterCollision(userData);
	return reinterpret_cast<JPH_CharacterVsCharacterCollision*>(impl);
}

JPH_CharacterVsCharacterCollision* JPH_CharacterVsCharacterCollision_CreateSimple(void)
{
	CharacterVsCharacterCollisionSimple* impl = new CharacterVsCharacterCollisionSimple();
	return reinterpret_cast<JPH_CharacterVsCharacterCollision*>(impl);
}

void JPH_CharacterVsCharacterCollisionSimple_AddCharacter(JPH_CharacterVsCharacterCollision* characterVsCharacter, JPH_CharacterVirtual* character)
{
	reinterpret_cast<CharacterVsCharacterCollisionSimple*>(characterVsCharacter)->Add(AsCharacterVirtual(character));
}

void JPH_CharacterVsCharacterCollisionSimple_RemoveCharacter(JPH_CharacterVsCharacterCollision* characterVsCharacter, JPH_CharacterVirtual* character)
{
	reinterpret_cast<CharacterVsCharacterCollisionSimple*>(characterVsCharacter)->Remove(AsCharacterVirtual(character));
}

void JPH_CharacterVsCharacterCollision_Destroy(JPH_CharacterVsCharacterCollision* listener)
{
	if (listener)
	{
		delete reinterpret_cast<JPH::CharacterVsCharacterCollision*>(listener);
	}
}

/* CollisionDispatch */
bool JPH_CollisionDispatch_CollideShapeVsShape(
	const JPH_Shape* shape1, const JPH_Shape* shape2,
	const JPH_Vec3* scale1, const JPH_Vec3* scale2,
	const JPH_Mat4* centerOfMassTransform1, const JPH_Mat4* centerOfMassTransform2,
	const JPH_CollideShapeSettings* collideShapeSettings,
	JPH_CollideShapeCollectorCallback* callback,
	void* userData,
	const JPH_ShapeFilter* shapeFilter)
{
	CollideShapeCollectorCallback collector(callback, userData);

	CollisionDispatch::sCollideShapeVsShape(
		AsShape(shape1), AsShape(shape2),
		ToJolt(scale1), ToJolt(scale2),
		ToJolt(centerOfMassTransform1), ToJolt(centerOfMassTransform2),
		JPH::SubShapeIDCreator(),
		JPH::SubShapeIDCreator(),
		ToJolt(collideShapeSettings), collector, ToJolt(shapeFilter)
	);

	return collector.hadHit;
}

bool JPH_CollisionDispatch_CastShapeVsShapeLocalSpace(
	const JPH_Vec3* direction, const JPH_Shape* shape1, const JPH_Shape* shape2,
	const JPH_Vec3* scale1InShape2LocalSpace, const JPH_Vec3* scale2,
	JPH_Mat4* centerOfMassTransform1InShape2LocalSpace, JPH_Mat4* centerOfMassWorldTransform2,
	const JPH_ShapeCastSettings* shapeCastSettings,
	JPH_CastShapeCollectorCallback* callback, void* userData,
	const JPH_ShapeFilter* shapeFilter)
{
	ShapeCast shapeCast(
		AsShape(shape1),
		ToJolt(scale1InShape2LocalSpace),
		ToJolt(centerOfMassTransform1InShape2LocalSpace),
		ToJolt(direction));

	CastShapeCollectorCallback collector(callback, userData);

	CollisionDispatch::sCastShapeVsShapeLocalSpace(
		shapeCast, ToJolt(shapeCastSettings), AsShape(shape2),
		ToJolt(scale2), ToJolt(shapeFilter), ToJolt(centerOfMassWorldTransform2),
		JPH::SubShapeIDCreator(),
		JPH::SubShapeIDCreator(),
		collector);

	return collector.hadHit;
}

bool JPH_CollisionDispatch_CastShapeVsShapeWorldSpace(
	const JPH_Vec3* direction, const JPH_Shape* shape1, const JPH_Shape* shape2,
	const JPH_Vec3* scale1, const JPH_Vec3* scale2,
	const JPH_Mat4* centerOfMassWorldTransform1, const JPH_Mat4* centerOfMassWorldTransform2,
	const JPH_ShapeCastSettings* shapeCastSettings,
	JPH_CastShapeCollectorCallback* callback, void* userData,
	const JPH_ShapeFilter* shapeFilter)
{
	ShapeCast shapeCast = ShapeCast::sFromWorldTransform(
		AsShape(shape1),
		ToJolt(scale1),
		ToJolt(centerOfMassWorldTransform1),
		ToJolt(direction));

	CastShapeCollectorCallback collector(callback, userData);

	CollisionDispatch::sCastShapeVsShapeWorldSpace(
		shapeCast, ToJolt(shapeCastSettings), AsShape(shape2),
		ToJolt(scale2), ToJolt(shapeFilter), ToJolt(centerOfMassWorldTransform2),
		JPH::SubShapeIDCreator(),
		JPH::SubShapeIDCreator(),
		collector);

	return collector.hadHit;
}

#ifdef JPH_DEBUG_RENDERER
#include <Jolt/Renderer/DebugRendererSimple.h>

/* JPH_BodyDrawFilter */
class ManagedBodyDrawFilter final : public JPH::BodyDrawFilter
{
public:
	static const JPH_BodyDrawFilter_Procs* s_Procs;
	void* userData = nullptr;

	ManagedBodyDrawFilter(void* userData_)
		: userData(userData_)
	{

	}

	bool ShouldDraw([[maybe_unused]] const Body& inBody) const override
	{
		if (s_Procs != nullptr && s_Procs->ShouldDraw)
		{
			return s_Procs->ShouldDraw(userData, reinterpret_cast<const JPH_Body*>(&inBody));
		}

		return true;
	}
};
const JPH_BodyDrawFilter_Procs* ManagedBodyDrawFilter::s_Procs = nullptr;

void JPH_BodyDrawFilter_SetProcs(const JPH_BodyDrawFilter_Procs* procs)
{
	ManagedBodyDrawFilter::s_Procs = procs;
}

JPH_BodyDrawFilter* JPH_BodyDrawFilter_Create(void* userData)
{
	auto filter = new ManagedBodyDrawFilter(userData);
	return reinterpret_cast<JPH_BodyDrawFilter*>(filter);
}

void JPH_BodyDrawFilter_Destroy(JPH_BodyDrawFilter* filter)
{
	if (filter)
	{
		delete reinterpret_cast<ManagedBodyDrawFilter*>(filter);
	}
}

/* DebugRenderer */
class ManagedDebugRendererSimple final : public DebugRendererSimple
{
public:
	static const JPH_DebugRenderer_Procs* s_Procs;
	void* userData = nullptr;

	ManagedDebugRendererSimple(void* userData_)
		: userData(userData_)
	{

	}

	void DrawLine(RVec3Arg inFrom, RVec3Arg inTo, ColorArg inColor) override
	{
		if (s_Procs != nullptr && s_Procs->DrawLine)
		{
			JPH_RVec3 from, to;

			FromJolt(inFrom, &from);
			FromJolt(inTo, &to);

			s_Procs->DrawLine(userData, &from, &to, inColor.GetUInt32());
		}
	}

	void DrawTriangle(RVec3Arg inV1, RVec3Arg inV2, RVec3Arg inV3, ColorArg inColor, ECastShadow inCastShadow = ECastShadow::Off) override
	{
		if (s_Procs != nullptr && s_Procs->DrawTriangle)
		{
			JPH_RVec3 v1, v2, v3;

			FromJolt(inV1, &v1);
			FromJolt(inV2, &v2);
			FromJolt(inV3, &v3);

			s_Procs->DrawTriangle(userData, &v1, &v2, &v3, inColor.GetUInt32(), static_cast<JPH_DebugRenderer_CastShadow>(inCastShadow));
		}
		else
		{
			DebugRendererSimple::DrawTriangle(inV1, inV2, inV3, inColor, inCastShadow);
		}
	}

	void DrawText3D(RVec3Arg inPosition, const string_view& inString, ColorArg inColor, float inHeight) override
	{
		if (s_Procs != nullptr && s_Procs->DrawText3D)
		{
			JPH_RVec3 position;

			FromJolt(inPosition, &position);

			s_Procs->DrawText3D(userData, &position, inString.data(), inColor.GetUInt32(), inHeight);
		}
	}
};

const JPH_DebugRenderer_Procs* ManagedDebugRendererSimple::s_Procs = nullptr;

void JPH_DebugRenderer_SetProcs(const JPH_DebugRenderer_Procs* procs)
{
	ManagedDebugRendererSimple::s_Procs = procs;
}

JPH_DebugRenderer* JPH_DebugRenderer_Create(void* userData)
{
	auto impl = new ManagedDebugRendererSimple(userData);
	return reinterpret_cast<JPH_DebugRenderer*>(impl);
}

void JPH_DebugRenderer_Destroy(JPH_DebugRenderer* renderer)
{
	if (renderer)
		delete reinterpret_cast<ManagedDebugRendererSimple*>(renderer);
}

void JPH_DebugRenderer_NextFrame(JPH_DebugRenderer* renderer)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->NextFrame();
}

void JPH_DebugRenderer_SetCameraPos(JPH_DebugRenderer* renderer, const JPH_RVec3* position)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->SetCameraPos(ToJolt(position));
}

void JPH_DebugRenderer_DrawLine(JPH_DebugRenderer* renderer, const JPH_RVec3* from, const JPH_RVec3* to, JPH_Color color)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawLine(ToJolt(from), ToJolt(to), JPH::Color(color));
}

void JPH_DebugRenderer_DrawWireBox(JPH_DebugRenderer* renderer, const JPH_AABox* box, JPH_Color color)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawWireBox(ToJolt(box), JPH::Color(color));
}

void JPH_DebugRenderer_DrawWireBox2(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, const JPH_AABox* box, JPH_Color color)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawWireBox(ToJolt(matrix), ToJolt(box), JPH::Color(color));
}

void JPH_DebugRenderer_DrawMarker(JPH_DebugRenderer* renderer, const JPH_RVec3* position, JPH_Color color, float size)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawMarker(ToJolt(position), JPH::Color(color), size);
}

void JPH_DebugRenderer_DrawArrow(JPH_DebugRenderer* renderer, const JPH_RVec3* from, const JPH_RVec3* to, JPH_Color color, float size)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawArrow(ToJolt(from), ToJolt(to), JPH::Color(color), size);
}

void JPH_DebugRenderer_DrawCoordinateSystem(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, float size)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawCoordinateSystem(ToJolt(matrix), size);
}

void JPH_DebugRenderer_DrawPlane(JPH_DebugRenderer* renderer, const JPH_RVec3* point, const JPH_Vec3* normal, JPH_Color color, float size)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawPlane(ToJolt(point), ToJolt(normal), JPH::Color(color), size);
}

void JPH_DebugRenderer_DrawWireTriangle(JPH_DebugRenderer* renderer, const JPH_RVec3* v1, const JPH_RVec3* v2, const JPH_RVec3* v3, JPH_Color color)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawWireTriangle(ToJolt(v2), ToJolt(v2), ToJolt(v3), JPH::Color(color));
}

void JPH_DebugRenderer_DrawWireSphere(JPH_DebugRenderer* renderer, const JPH_RVec3* center, float radius, JPH_Color color, int level)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawWireSphere(ToJolt(center), radius, JPH::Color(color), level);
}

void JPH_DebugRenderer_DrawWireUnitSphere(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, JPH_Color color, int level)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawWireUnitSphere(ToJolt(matrix), JPH::Color(color), level);
}

void JPH_DebugRenderer_DrawTriangle(JPH_DebugRenderer* renderer, const JPH_RVec3* v1, const JPH_RVec3* v2, const JPH_RVec3* v3, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawTriangle(
		ToJolt(v1), ToJolt(v2), ToJolt(v3),
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow)
	);
}

void JPH_DebugRenderer_DrawBox(JPH_DebugRenderer* renderer, const JPH_AABox* box, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawBox(
		ToJolt(box),
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawBox2(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, const JPH_AABox* box, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawBox(
		ToJolt(matrix),
		ToJolt(box),
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawSphere(JPH_DebugRenderer* renderer, const JPH_RVec3* center, float radius, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawSphere(
		ToJolt(center),
		radius,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawUnitSphere(JPH_DebugRenderer* renderer, JPH_RMat4 matrix, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawUnitSphere(
		ToJolt(&matrix),
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawCapsule(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, float halfHeightOfCylinder, float radius, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawCapsule(
		ToJolt(matrix),
		halfHeightOfCylinder,
		radius,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawCylinder(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, float halfHeight, float radius, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawCylinder(
		ToJolt(matrix),
		halfHeight,
		radius,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawOpenCone(JPH_DebugRenderer* renderer, const JPH_RVec3* top, const JPH_Vec3* axis, const JPH_Vec3* perpendicular, float halfAngle, float length, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawOpenCone(
		ToJolt(top),
		ToJolt(axis),
		ToJolt(perpendicular),
		halfAngle,
		length,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawSwingConeLimits(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, float swingYHalfAngle, float swingZHalfAngle, float edgeLength, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawSwingConeLimits(
		ToJolt(matrix),
		swingYHalfAngle,
		swingZHalfAngle,
		edgeLength,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawSwingPyramidLimits(JPH_DebugRenderer* renderer, const JPH_RMat4* matrix, float minSwingYAngle, float maxSwingYAngle, float minSwingZAngle, float maxSwingZAngle, float edgeLength, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawSwingPyramidLimits(
		ToJolt(matrix),
		minSwingYAngle,
		maxSwingYAngle,
		minSwingZAngle,
		maxSwingZAngle,
		edgeLength,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}
void JPH_DebugRenderer_DrawPie(JPH_DebugRenderer* renderer, const JPH_RVec3* center, float radius, const JPH_Vec3* normal, const JPH_Vec3* axis, float minAngle, float maxAngle, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawPie(
		ToJolt(center),
		radius,
		ToJolt(normal),
		ToJolt(axis),
		minAngle,
		maxAngle,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}

void JPH_DebugRenderer_DrawTaperedCylinder(JPH_DebugRenderer* renderer, const JPH_RMat4* inMatrix, float top, float bottom, float topRadius, float bottomRadius, JPH_Color color, JPH_DebugRenderer_CastShadow castShadow, JPH_DebugRenderer_DrawMode drawMode)
{
	reinterpret_cast<ManagedDebugRendererSimple*>(renderer)->DrawTaperedCylinder(
		ToJolt(inMatrix),
		top,
		bottom,
		topRadius,
		bottomRadius,
		JPH::Color(color),
		static_cast<JPH::DebugRenderer::ECastShadow>(castShadow),
		static_cast<JPH::DebugRenderer::EDrawMode>(drawMode)
	);
}
#endif

/* Skeleton */
JPH_Skeleton* JPH_Skeleton_Create(void)
{
	auto skeleton = new JPH::Skeleton();
	skeleton->AddRef();

	return ToSkeleton(skeleton);
}

void JPH_Skeleton_Destroy(JPH_Skeleton* skeleton)
{
	if (skeleton)
		AsSkeleton(skeleton)->Release();
}

uint32_t JPH_Skeleton_AddJoint(JPH_Skeleton* skeleton, const char* name)
{
	return AsSkeleton(skeleton)->AddJoint(name);
}

uint32_t JPH_Skeleton_AddJoint2(JPH_Skeleton* skeleton, const char* name, int parentIndex)
{
	return AsSkeleton(skeleton)->AddJoint(name, parentIndex);
}

uint32_t JPH_Skeleton_AddJoint3(JPH_Skeleton* skeleton, const char* name, const char* parentName)
{
	return AsSkeleton(skeleton)->AddJoint(name, parentName);
}

int JPH_Skeleton_GetJointCount(const JPH_Skeleton* skeleton)
{
	return AsSkeleton(skeleton)->GetJointCount();
}

void JPH_Skeleton_GetJoint(const JPH_Skeleton* skeleton, int index, JPH_SkeletonJoint* joint)
{
	FromJolt(AsSkeleton(skeleton)->GetJoint(index), joint);
}

int JPH_Skeleton_GetJointIndex(const JPH_Skeleton* skeleton, const char* name)
{
	return AsSkeleton(skeleton)->GetJointIndex(name);
}

void JPH_Skeleton_CalculateParentJointIndices(JPH_Skeleton* skeleton)
{
	AsSkeleton(skeleton)->CalculateParentJointIndices();
}

bool JPH_Skeleton_AreJointsCorrectlyOrdered(const JPH_Skeleton* skeleton)
{
	return AsSkeleton(skeleton)->AreJointsCorrectlyOrdered();
}

/* RagdollSettings */
JPH_RagdollSettings* JPH_RagdollSettings_Create(void)
{
	auto settings = new JPH::RagdollSettings();
	settings->AddRef();
	return ToRagdollSettings(settings);
}

void JPH_RagdollSettings_Destroy(JPH_RagdollSettings* settings)
{
	if (settings)
		AsRagdollSettings(settings)->Release();
}

const JPH_Skeleton* JPH_RagdollSettings_GetSkeleton(const JPH_RagdollSettings* character)
{
	return ToSkeleton(AsRagdollSettings(character)->GetSkeleton());
}

void JPH_RagdollSettings_SetSkeleton(JPH_RagdollSettings* character, JPH_Skeleton* skeleton)
{
	AsRagdollSettings(character)->mSkeleton = AsSkeleton(skeleton);
}

bool JPH_RagdollSettings_Stabilize(JPH_RagdollSettings* settings)
{
	return AsRagdollSettings(settings)->Stabilize();
}

void JPH_RagdollSettings_DisableParentChildCollisions(JPH_RagdollSettings* settings, const JPH_Mat4* jointMatrices, float minSeparationDistance)
{
	AsRagdollSettings(settings)->DisableParentChildCollisions(
		jointMatrices ? reinterpret_cast<const JPH::Mat44*>(jointMatrices) : nullptr,
		minSeparationDistance
	);
}

void JPH_RagdollSettings_CalculateBodyIndexToConstraintIndex(JPH_RagdollSettings* settings)
{
	AsRagdollSettings(settings)->CalculateBodyIndexToConstraintIndex();
}

int JPH_RagdollSettings_GetConstraintIndexForBodyIndex(JPH_RagdollSettings* settings, int bodyIndex)
{
	return AsRagdollSettings(settings)->GetConstraintIndexForBodyIndex(bodyIndex);
}

void JPH_RagdollSettings_CalculateConstraintIndexToBodyIdxPair(JPH_RagdollSettings* settings)
{
	AsRagdollSettings(settings)->CalculateConstraintIndexToBodyIdxPair();
}

void JPH_RagdollSettings_ResizeParts(JPH_RagdollSettings* settings, int count)
{
	AsRagdollSettings(settings)->mParts.resize(count);
}

int JPH_RagdollSettings_GetPartCount(const JPH_RagdollSettings* settings)
{
	return (int)AsRagdollSettings(settings)->mParts.size();
}

void JPH_RagdollSettings_SetPartShape(JPH_RagdollSettings* settings, int partIndex, const JPH_Shape* shape)
{
	AsRagdollSettings(settings)->mParts[partIndex].SetShape(AsShape(shape));
}

void JPH_RagdollSettings_SetPartPosition(JPH_RagdollSettings* settings, int partIndex, const JPH_RVec3* position)
{
	AsRagdollSettings(settings)->mParts[partIndex].mPosition = ToJolt(position);
}

void JPH_RagdollSettings_SetPartRotation(JPH_RagdollSettings* settings, int partIndex, const JPH_Quat* rotation)
{
	AsRagdollSettings(settings)->mParts[partIndex].mRotation = ToJolt(rotation);
}

void JPH_RagdollSettings_SetPartMotionType(JPH_RagdollSettings* settings, int partIndex, JPH_MotionType motionType)
{
	AsRagdollSettings(settings)->mParts[partIndex].mMotionType = static_cast<EMotionType>(motionType);
}

void JPH_RagdollSettings_SetPartObjectLayer(JPH_RagdollSettings* settings, int partIndex, JPH_ObjectLayer layer)
{
	AsRagdollSettings(settings)->mParts[partIndex].mObjectLayer = layer;
}

void JPH_RagdollSettings_SetPartMassProperties(JPH_RagdollSettings* settings, int partIndex, float mass)
{
	AsRagdollSettings(settings)->mParts[partIndex].mMassPropertiesOverride.mMass = mass;
	AsRagdollSettings(settings)->mParts[partIndex].mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
}

void JPH_RagdollSettings_SetPartToParent(JPH_RagdollSettings* settings, int partIndex, const JPH_SwingTwistConstraintSettings* constraintSettings)
{
	if (constraintSettings == nullptr)
	{
		AsRagdollSettings(settings)->mParts[partIndex].mToParent = nullptr;
		return;
	}

	SwingTwistConstraintSettings* joltSettings = new SwingTwistConstraintSettings();
	joltSettings->mSpace = static_cast<EConstraintSpace>(constraintSettings->space);
	joltSettings->mPosition1 = ToJolt(&constraintSettings->position1);
	joltSettings->mTwistAxis1 = ToJolt(&constraintSettings->twistAxis1);
	joltSettings->mPlaneAxis1 = ToJolt(&constraintSettings->planeAxis1);
	joltSettings->mPosition2 = ToJolt(&constraintSettings->position2);
	joltSettings->mTwistAxis2 = ToJolt(&constraintSettings->twistAxis2);
	joltSettings->mPlaneAxis2 = ToJolt(&constraintSettings->planeAxis2);
	joltSettings->mSwingType = static_cast<ESwingType>(constraintSettings->swingType);
	joltSettings->mNormalHalfConeAngle = constraintSettings->normalHalfConeAngle;
	joltSettings->mPlaneHalfConeAngle = constraintSettings->planeHalfConeAngle;
	joltSettings->mTwistMinAngle = constraintSettings->twistMinAngle;
	joltSettings->mTwistMaxAngle = constraintSettings->twistMaxAngle;
	joltSettings->mMaxFrictionTorque = constraintSettings->maxFrictionTorque;

	// Copy motor settings
	joltSettings->mSwingMotorSettings.mSpringSettings.mFrequency = constraintSettings->swingMotorSettings.springSettings.frequencyOrStiffness;
	joltSettings->mSwingMotorSettings.mSpringSettings.mDamping = constraintSettings->swingMotorSettings.springSettings.damping;
	joltSettings->mSwingMotorSettings.mMinForceLimit = constraintSettings->swingMotorSettings.minForceLimit;
	joltSettings->mSwingMotorSettings.mMaxForceLimit = constraintSettings->swingMotorSettings.maxForceLimit;
	joltSettings->mTwistMotorSettings.mSpringSettings.mFrequency = constraintSettings->twistMotorSettings.springSettings.frequencyOrStiffness;
	joltSettings->mTwistMotorSettings.mSpringSettings.mDamping = constraintSettings->twistMotorSettings.springSettings.damping;
	joltSettings->mTwistMotorSettings.mMinForceLimit = constraintSettings->twistMotorSettings.minForceLimit;
	joltSettings->mTwistMotorSettings.mMaxForceLimit = constraintSettings->twistMotorSettings.maxForceLimit;

	AsRagdollSettings(settings)->mParts[partIndex].mToParent = joltSettings;
}

JPH_Ragdoll* JPH_RagdollSettings_CreateRagdoll(JPH_RagdollSettings* settings, JPH_PhysicsSystem* system, JPH_CollisionGroupID collisionGroup, uint64_t userData)
{
	Ragdoll* ragdoll = AsRagdollSettings(settings)->CreateRagdoll(collisionGroup, userData, system->physicsSystem);
	ragdoll->AddRef();

	return ToRagdoll(ragdoll);
}

/* Ragdoll */
void JPH_Ragdoll_Destroy(JPH_Ragdoll* ragdoll)
{
	if (ragdoll)
	{
		AsRagdoll(ragdoll)->Release();
	}
}

void JPH_Ragdoll_AddToPhysicsSystem(JPH_Ragdoll* ragdoll, JPH_Activation activationMode /*= JPH_ActivationActivate */, bool lockBodies /* = true */)
{
	AsRagdoll(ragdoll)->AddToPhysicsSystem(static_cast<JPH::EActivation>(activationMode), lockBodies);
}

void JPH_Ragdoll_RemoveFromPhysicsSystem(JPH_Ragdoll* ragdoll, bool lockBodies /* = true */)
{
	AsRagdoll(ragdoll)->RemoveFromPhysicsSystem(lockBodies);
}

void JPH_Ragdoll_Activate(JPH_Ragdoll* ragdoll, bool lockBodies /* = true */)
{
	AsRagdoll(ragdoll)->Activate(lockBodies);
}

bool JPH_Ragdoll_IsActive(const JPH_Ragdoll* ragdoll, bool lockBodies /* = true */)
{
	return AsRagdoll(ragdoll)->IsActive(lockBodies);
}

void JPH_Ragdoll_ResetWarmStart(JPH_Ragdoll* ragdoll)
{
	AsRagdoll(ragdoll)->ResetWarmStart();
}

void JPH_Ragdoll_SetPose(JPH_Ragdoll* ragdoll, const JPH_SkeletonPose* pose, bool lockBodies)
{
	AsRagdoll(ragdoll)->SetPose(*AsSkeletonPose(pose), lockBodies);
}

void JPH_Ragdoll_SetPose2(JPH_Ragdoll* ragdoll, const JPH_RVec3* rootOffset, const JPH_Mat4* jointMatrices, bool lockBodies)
{
	AsRagdoll(ragdoll)->SetPose(ToJolt(rootOffset), reinterpret_cast<const JPH::Mat44*>(jointMatrices), lockBodies);
}

void JPH_Ragdoll_GetPose(const JPH_Ragdoll* ragdoll, JPH_SkeletonPose* outPose, bool lockBodies)
{
	const_cast<JPH::Ragdoll*>(AsRagdoll(ragdoll))->GetPose(*AsSkeletonPose(outPose), lockBodies);
}

void JPH_Ragdoll_GetPose2(const JPH_Ragdoll* ragdoll, JPH_RVec3* outRootOffset, JPH_Mat4* outJointMatrices, bool lockBodies)
{
	JPH::RVec3 rootOffset;
	const_cast<JPH::Ragdoll*>(AsRagdoll(ragdoll))->GetPose(rootOffset, reinterpret_cast<JPH::Mat44*>(outJointMatrices), lockBodies);
	if (outRootOffset)
		FromJolt(rootOffset, outRootOffset);
}

void JPH_Ragdoll_DriveToPoseUsingMotors(JPH_Ragdoll* ragdoll, const JPH_SkeletonPose* pose)
{
	AsRagdoll(ragdoll)->DriveToPoseUsingMotors(*AsSkeletonPose(pose));
}

void JPH_Ragdoll_DriveToPoseUsingKinematics(JPH_Ragdoll* ragdoll, const JPH_SkeletonPose* pose, float deltaTime, bool lockBodies)
{
	AsRagdoll(ragdoll)->DriveToPoseUsingKinematics(*AsSkeletonPose(pose), deltaTime, lockBodies);
}

int JPH_Ragdoll_GetBodyCount(const JPH_Ragdoll* ragdoll)
{
	return (int)AsRagdoll(ragdoll)->GetBodyCount();
}

JPH_BodyID JPH_Ragdoll_GetBodyID(const JPH_Ragdoll* ragdoll, int bodyIndex)
{
	return AsRagdoll(ragdoll)->GetBodyID(bodyIndex).GetIndexAndSequenceNumber();
}

int JPH_Ragdoll_GetConstraintCount(const JPH_Ragdoll* ragdoll)
{
	return (int)AsRagdoll(ragdoll)->GetConstraintCount();
}

JPH_TwoBodyConstraint* JPH_Ragdoll_GetConstraint(JPH_Ragdoll* ragdoll, int constraintIndex)
{
	return ToTwoBodyConstraint(AsRagdoll(ragdoll)->GetConstraint(constraintIndex));
}

void JPH_Ragdoll_GetRootTransform(const JPH_Ragdoll* ragdoll, JPH_RVec3* outPosition, JPH_Quat* outRotation, bool lockBodies)
{
	JPH::RVec3 position;
	JPH::Quat rotation;
	const_cast<JPH::Ragdoll*>(AsRagdoll(ragdoll))->GetRootTransform(position, rotation, lockBodies);
	if (outPosition)
		FromJolt(position, outPosition);
	if (outRotation)
		FromJolt(rotation, outRotation);
}

const JPH_RagdollSettings* JPH_Ragdoll_GetRagdollSettings(const JPH_Ragdoll* ragdoll)
{
	return ToRagdollSettings(AsRagdoll(ragdoll)->GetRagdollSettings());
}

/* SkeletonPose */
JPH_SkeletonPose* JPH_SkeletonPose_Create(void)
{
	auto pose = new JPH::SkeletonPose();
	return ToSkeletonPose(pose);
}

void JPH_SkeletonPose_Destroy(JPH_SkeletonPose* pose)
{
	if (pose)
		delete AsSkeletonPose(pose);
}

void JPH_SkeletonPose_SetSkeleton(JPH_SkeletonPose* pose, const JPH_Skeleton* skeleton)
{
	AsSkeletonPose(pose)->SetSkeleton(AsSkeleton(skeleton));
}

const JPH_Skeleton* JPH_SkeletonPose_GetSkeleton(const JPH_SkeletonPose* pose)
{
	return ToSkeleton(AsSkeletonPose(pose)->GetSkeleton());
}

void JPH_SkeletonPose_SetRootOffset(JPH_SkeletonPose* pose, const JPH_RVec3* offset)
{
	AsSkeletonPose(pose)->SetRootOffset(ToJolt(offset));
}

void JPH_SkeletonPose_GetRootOffset(const JPH_SkeletonPose* pose, JPH_RVec3* result)
{
	FromJolt(AsSkeletonPose(pose)->GetRootOffset(), result);
}

int JPH_SkeletonPose_GetJointCount(const JPH_SkeletonPose* pose)
{
	return (int)AsSkeletonPose(pose)->GetJointCount();
}

void JPH_SkeletonPose_GetJointState(const JPH_SkeletonPose* pose, int index, JPH_Vec3* outTranslation, JPH_Quat* outRotation)
{
	const auto& joint = AsSkeletonPose(pose)->GetJoint(index);
	if (outTranslation)
		FromJolt(joint.mTranslation, outTranslation);
	if (outRotation)
		FromJolt(joint.mRotation, outRotation);
}

void JPH_SkeletonPose_SetJointState(JPH_SkeletonPose* pose, int index, const JPH_Vec3* translation, const JPH_Quat* rotation)
{
	auto& joint = AsSkeletonPose(pose)->GetJoint(index);
	if (translation)
		joint.mTranslation = ToJolt(translation);
	if (rotation)
		joint.mRotation = ToJolt(rotation);
}

void JPH_SkeletonPose_GetJointMatrix(const JPH_SkeletonPose* pose, int index, JPH_Mat4* result)
{
	FromJolt(AsSkeletonPose(pose)->GetJointMatrix(index), result);
}

void JPH_SkeletonPose_SetJointMatrix(JPH_SkeletonPose* pose, int index, const JPH_Mat4* matrix)
{
	AsSkeletonPose(pose)->GetJointMatrix(index) = ToJolt(matrix);
}

void JPH_SkeletonPose_GetJointMatrices(const JPH_SkeletonPose* pose, JPH_Mat4* outMatrices, int count)
{
	const auto& matrices = AsSkeletonPose(pose)->GetJointMatrices();
	int copyCount = (int)matrices.size() < count ? (int)matrices.size() : count;
	for (int i = 0; i < copyCount; i++)
		FromJolt(matrices[i], &outMatrices[i]);
}

void JPH_SkeletonPose_SetJointMatrices(JPH_SkeletonPose* pose, const JPH_Mat4* matrices, int count)
{
	auto& poseMatrices = AsSkeletonPose(pose)->GetJointMatrices();
	int copyCount = (int)poseMatrices.size() < count ? (int)poseMatrices.size() : count;
	for (int i = 0; i < copyCount; i++)
		poseMatrices[i] = ToJolt(&matrices[i]);
}

void JPH_SkeletonPose_CalculateJointMatrices(JPH_SkeletonPose* pose)
{
	AsSkeletonPose(pose)->CalculateJointMatrices();
}

void JPH_SkeletonPose_CalculateJointStates(JPH_SkeletonPose* pose)
{
	AsSkeletonPose(pose)->CalculateJointStates();
}

void JPH_SkeletonPose_CalculateLocalSpaceJointMatrices(const JPH_SkeletonPose* pose, JPH_Mat4* outMatrices)
{
	int count = (int)AsSkeletonPose(pose)->GetJointCount();
	JPH::Array<JPH::Mat44> matrices(count);
	AsSkeletonPose(pose)->CalculateLocalSpaceJointMatrices(matrices.data());
	for (int i = 0; i < count; i++)
		FromJolt(matrices[i], &outMatrices[i]);
}

/* SkeletalAnimation */
JPH_SkeletalAnimation* JPH_SkeletalAnimation_Create(void)
{
	auto animation = new JPH::SkeletalAnimation();
	animation->AddRef();
	return ToSkeletalAnimation(animation);
}

void JPH_SkeletalAnimation_Destroy(JPH_SkeletalAnimation* animation)
{
	if (animation)
		AsSkeletalAnimation(animation)->Release();
}

float JPH_SkeletalAnimation_GetDuration(const JPH_SkeletalAnimation* animation)
{
	return AsSkeletalAnimation(animation)->GetDuration();
}

bool JPH_SkeletalAnimation_IsLooping(const JPH_SkeletalAnimation* animation)
{
	return AsSkeletalAnimation(animation)->IsLooping();
}

void JPH_SkeletalAnimation_SetIsLooping(JPH_SkeletalAnimation* animation, bool looping)
{
	AsSkeletalAnimation(animation)->SetIsLooping(looping);
}

void JPH_SkeletalAnimation_ScaleJoints(JPH_SkeletalAnimation* animation, float scale)
{
	AsSkeletalAnimation(animation)->ScaleJoints(scale);
}

void JPH_SkeletalAnimation_Sample(const JPH_SkeletalAnimation* animation, float time, JPH_SkeletonPose* pose)
{
	AsSkeletalAnimation(animation)->Sample(time, *AsSkeletonPose(pose));
}

int JPH_SkeletalAnimation_GetAnimatedJointCount(const JPH_SkeletalAnimation* animation)
{
	return (int)AsSkeletalAnimation(animation)->GetAnimatedJoints().size();
}

void JPH_SkeletalAnimation_AddAnimatedJoint(JPH_SkeletalAnimation* animation, const char* jointName)
{
	auto& joints = AsSkeletalAnimation(animation)->GetAnimatedJoints();
	joints.push_back(JPH::SkeletalAnimation::AnimatedJoint());
	joints.back().mJointName = jointName;
}

void JPH_SkeletalAnimation_AddKeyframe(JPH_SkeletalAnimation* animation, int jointIndex, float time, const JPH_Vec3* translation, const JPH_Quat* rotation)
{
	auto& joints = AsSkeletalAnimation(animation)->GetAnimatedJoints();
	if (jointIndex >= 0 && jointIndex < (int)joints.size())
	{
		JPH::SkeletalAnimation::Keyframe keyframe;
		keyframe.mTime = time;
		if (translation)
			keyframe.mTranslation = ToJolt(translation);
		if (rotation)
			keyframe.mRotation = ToJolt(rotation);
		joints[jointIndex].mKeyframes.push_back(keyframe);
	}
}

/* SkeletonMapper */
JPH_SkeletonMapper* JPH_SkeletonMapper_Create(void)
{
	auto mapper = new JPH::SkeletonMapper();
	mapper->AddRef();
	return ToSkeletonMapper(mapper);
}

void JPH_SkeletonMapper_Destroy(JPH_SkeletonMapper* mapper)
{
	if (mapper)
		AsSkeletonMapper(mapper)->Release();
}

void JPH_SkeletonMapper_Initialize(JPH_SkeletonMapper* mapper, const JPH_Skeleton* skeleton1, const JPH_Mat4* neutralPose1, const JPH_Skeleton* skeleton2, const JPH_Mat4* neutralPose2)
{
	AsSkeletonMapper(mapper)->Initialize(
		AsSkeleton(skeleton1), reinterpret_cast<const JPH::Mat44*>(neutralPose1),
		AsSkeleton(skeleton2), reinterpret_cast<const JPH::Mat44*>(neutralPose2));
}

void JPH_SkeletonMapper_LockAllTranslations(JPH_SkeletonMapper* mapper, const JPH_Skeleton* skeleton2, const JPH_Mat4* neutralPose2)
{
	AsSkeletonMapper(mapper)->LockAllTranslations(
		AsSkeleton(skeleton2), reinterpret_cast<const JPH::Mat44*>(neutralPose2));
}

void JPH_SkeletonMapper_LockTranslations(JPH_SkeletonMapper* mapper, const JPH_Skeleton* skeleton2, const bool* lockedTranslations, const JPH_Mat4* neutralPose2)
{
	AsSkeletonMapper(mapper)->LockTranslations(
		AsSkeleton(skeleton2), lockedTranslations, reinterpret_cast<const JPH::Mat44*>(neutralPose2));
}

void JPH_SkeletonMapper_Map(const JPH_SkeletonMapper* mapper, const JPH_Mat4* pose1ModelSpace, const JPH_Mat4* pose2LocalSpace, JPH_Mat4* outPose2ModelSpace)
{
	const auto& mappings = AsSkeletonMapper(mapper)->GetMappings();
	if (mappings.empty())
		return;

	AsSkeletonMapper(mapper)->Map(
		reinterpret_cast<const JPH::Mat44*>(pose1ModelSpace),
		reinterpret_cast<const JPH::Mat44*>(pose2LocalSpace),
		reinterpret_cast<JPH::Mat44*>(outPose2ModelSpace)
	);
}

void JPH_SkeletonMapper_MapReverse(const JPH_SkeletonMapper* mapper, const JPH_Mat4* pose2ModelSpace, JPH_Mat4* outPose1ModelSpace)
{
	const auto& mappings = AsSkeletonMapper(mapper)->GetMappings();
	if (mappings.empty())
		return;

	AsSkeletonMapper(mapper)->MapReverse(
		reinterpret_cast<const JPH::Mat44*>(pose2ModelSpace),
		reinterpret_cast<JPH::Mat44*>(outPose1ModelSpace)
	);
}

int JPH_SkeletonMapper_GetMappedJointIndex(const JPH_SkeletonMapper* mapper, int joint1Index)
{
	return AsSkeletonMapper(mapper)->GetMappedJointIdx(joint1Index);
}

bool JPH_SkeletonMapper_IsJointTranslationLocked(const JPH_SkeletonMapper* mapper, int joint2Index)
{
	return AsSkeletonMapper(mapper)->IsJointTranslationLocked(joint2Index);
}

/* CollisionEstimationResult */
void JPH_EstimateCollisionResponse(const JPH_Body* body1, const JPH_Body* body2, const JPH_ContactManifold* manifold, float combinedFriction, float combinedRestitution, float minVelocityForRestitution, uint32_t numIterations, JPH_CollisionEstimationResult* result)
{
	JPH_ASSERT(result);

	JPH::CollisionEstimationResult joltResult;

	JPH::EstimateCollisionResponse(*AsBody(body1), *AsBody(body2),
		*AsContactManifold(manifold), joltResult,
		combinedFriction,
		combinedRestitution,
		minVelocityForRestitution,
		numIterations);

	FromJolt(joltResult.mLinearVelocity1, &result->linearVelocity1);
	FromJolt(joltResult.mAngularVelocity1, &result->angularVelocity1);
	FromJolt(joltResult.mLinearVelocity2, &result->linearVelocity2);
	FromJolt(joltResult.mAngularVelocity2, &result->angularVelocity2);

	FromJolt(joltResult.mFrictionPoint, &result->frictionPoint);
	FromJolt(joltResult.mTangent1, &result->tangent1);
	FromJolt(joltResult.mTangent2, &result->tangent2);

	result->frictionImpulse1 = joltResult.mFrictionImpulse1;
	result->frictionImpulse2 = joltResult.mFrictionImpulse2;
	result->angularFrictionImpulse = joltResult.mAngularFrictionImpulse;

	if (!joltResult.mContactImpulse.empty())
	{
		result->contactImpulseCount = static_cast<uint32_t>(joltResult.mContactImpulse.size());
		result->contactImpulses = (float*)malloc(sizeof(float) * joltResult.mContactImpulse.size());
		memcpy(result->contactImpulses, joltResult.mContactImpulse.data(), sizeof(float) * joltResult.mContactImpulse.size());
	}
	else
	{
		result->contactImpulseCount = 0;
		result->contactImpulses = nullptr;
	}
}

/* Wheel */
JPH_WheelSettings* JPH_WheelSettings_Create(void)
{
	auto settings = new JPH::WheelSettings();
	settings->AddRef();

	return ToWheelSettings(settings);
}

void JPH_WheelSettings_Destroy(JPH_WheelSettings* settings)
{
	if (settings)
	{
		AsWheelSettings(settings)->Release();
	}
}

void JPH_WheelSettings_GetPosition(const JPH_WheelSettings* settings, JPH_Vec3* result)
{
	FromJolt(AsWheelSettings(settings)->mPosition, result);
}

void JPH_WheelSettings_SetPosition(JPH_WheelSettings* settings, const JPH_Vec3* value)
{
	AsWheelSettings(settings)->mPosition = ToJolt(value);
}

void JPH_WheelSettings_GetSuspensionForcePoint(const JPH_WheelSettings* settings, JPH_Vec3* result)
{
	FromJolt(AsWheelSettings(settings)->mSuspensionForcePoint, result);
}

void JPH_WheelSettings_SetSuspensionForcePoint(JPH_WheelSettings* settings, const JPH_Vec3* value)
{
	AsWheelSettings(settings)->mSuspensionForcePoint = ToJolt(value);
}

void JPH_WheelSettings_GetSuspensionDirection(const JPH_WheelSettings* settings, JPH_Vec3* result)
{
	FromJolt(AsWheelSettings(settings)->mSuspensionDirection, result);
}

void JPH_WheelSettings_SetSuspensionDirection(JPH_WheelSettings* settings, const JPH_Vec3* value)
{
	AsWheelSettings(settings)->mSuspensionDirection = ToJolt(value);
}

void JPH_WheelSettings_GetSteeringAxis(const JPH_WheelSettings* settings, JPH_Vec3* result)
{
	FromJolt(AsWheelSettings(settings)->mSteeringAxis, result);
}

void JPH_WheelSettings_SetSteeringAxis(JPH_WheelSettings* settings, const JPH_Vec3* value)
{
	AsWheelSettings(settings)->mSteeringAxis = ToJolt(value);
}

void JPH_WheelSettings_GetWheelUp(const JPH_WheelSettings* settings, JPH_Vec3* result)
{
	FromJolt(AsWheelSettings(settings)->mWheelUp, result);
}

void JPH_WheelSettings_SetWheelUp(JPH_WheelSettings* settings, const JPH_Vec3* value)
{
	AsWheelSettings(settings)->mWheelUp = ToJolt(value);
}

void JPH_WheelSettings_GetWheelForward(const JPH_WheelSettings* settings, JPH_Vec3* result)
{
	FromJolt(AsWheelSettings(settings)->mWheelForward, result);
}

void JPH_WheelSettings_SetWheelForward(JPH_WheelSettings* settings, const JPH_Vec3* value)
{
	AsWheelSettings(settings)->mWheelForward = ToJolt(value);
}

float JPH_WheelSettings_GetSuspensionMinLength(const JPH_WheelSettings* settings)
{
	return AsWheelSettings(settings)->mSuspensionMinLength;
}

void JPH_WheelSettings_SetSuspensionMinLength(JPH_WheelSettings* settings, float value)
{
	AsWheelSettings(settings)->mSuspensionMinLength = value;
}

float JPH_WheelSettings_GetSuspensionMaxLength(const JPH_WheelSettings* settings)
{
	return AsWheelSettings(settings)->mSuspensionMaxLength;
}

void JPH_WheelSettings_SetSuspensionMaxLength(JPH_WheelSettings* settings, float value)
{
	AsWheelSettings(settings)->mSuspensionMaxLength = value;
}

float JPH_WheelSettings_GetSuspensionPreloadLength(const JPH_WheelSettings* settings)
{
	return AsWheelSettings(settings)->mSuspensionPreloadLength;
}

void JPH_WheelSettings_SetSuspensionPreloadLength(JPH_WheelSettings* settings, float value)
{
	AsWheelSettings(settings)->mSuspensionPreloadLength = value;
}

void JPH_WheelSettings_GetSuspensionSpring(const JPH_WheelSettings* settings, JPH_SpringSettings* result)
{
	FromJolt(AsWheelSettings(settings)->mSuspensionSpring, result);
}

void JPH_WheelSettings_SetSuspensionSpring(JPH_WheelSettings* settings, JPH_SpringSettings* springSettings)
{
	AsWheelSettings(settings)->mSuspensionSpring = ToJolt(springSettings);
}

float JPH_WheelSettings_GetRadius(const JPH_WheelSettings* settings)
{
	return AsWheelSettings(settings)->mRadius;
}

void JPH_WheelSettings_SetRadius(JPH_WheelSettings* settings, float value)
{
	AsWheelSettings(settings)->mRadius = value;
}

float JPH_WheelSettings_GetWidth(const JPH_WheelSettings* settings)
{
	return AsWheelSettings(settings)->mWidth;
}

void JPH_WheelSettings_SetWidth(JPH_WheelSettings* settings, float value)
{
	AsWheelSettings(settings)->mWidth = value;
}

bool JPH_WheelSettings_GetEnableSuspensionForcePoint(const JPH_WheelSettings* settings)
{
	return AsWheelSettings(settings)->mEnableSuspensionForcePoint;
}

void JPH_WheelSettings_SetEnableSuspensionForcePoint(JPH_WheelSettings* settings, bool value)
{
	AsWheelSettings(settings)->mEnableSuspensionForcePoint = value;
}

JPH_Wheel* JPH_Wheel_Create(const JPH_WheelSettings* settings)
{
	JPH_ASSERT(settings);

	auto wheel = new JPH::Wheel(*AsWheelSettings(settings));
	return ToWheel(wheel);
}

void JPH_Wheel_Destroy(JPH_Wheel* wheel)
{
	if (wheel)
	{
		delete AsWheel(wheel);
	}
}

const JPH_WheelSettings* JPH_Wheel_GetSettings(const JPH_Wheel* wheel)
{
	return ToWheelSettings(AsWheel(wheel)->GetSettings());
}

float JPH_Wheel_GetAngularVelocity(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetAngularVelocity();
}

void JPH_Wheel_SetAngularVelocity(JPH_Wheel* wheel, float value)
{
	AsWheel(wheel)->SetAngularVelocity(value);
}

float JPH_Wheel_GetRotationAngle(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetRotationAngle();
}

void JPH_Wheel_SetRotationAngle(JPH_Wheel* wheel, float value)
{
	AsWheel(wheel)->SetRotationAngle(value);
}

float JPH_Wheel_GetSteerAngle(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetSteerAngle();
}

void JPH_Wheel_SetSteerAngle(JPH_Wheel* wheel, float value)
{
	AsWheel(wheel)->SetSteerAngle(value);
}

bool JPH_Wheel_HasContact(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->HasContact();
}

JPH_BodyID JPH_Wheel_GetContactBodyID(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetContactBodyID().GetIndexAndSequenceNumber();
}

JPH_SubShapeID JPH_Wheel_GetContactSubShapeID(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetContactSubShapeID().GetValue();
}

void JPH_Wheel_GetContactPosition(const JPH_Wheel* wheel, JPH_RVec3* result)
{
	FromJolt(AsWheel(wheel)->GetContactPosition(), result);
}

void JPH_Wheel_GetContactPointVelocity(const JPH_Wheel* wheel, JPH_Vec3* result)
{
	FromJolt(AsWheel(wheel)->GetContactPointVelocity(), result);
}

void JPH_Wheel_GetContactNormal(const JPH_Wheel* wheel, JPH_Vec3* result)
{
	FromJolt(AsWheel(wheel)->GetContactNormal(), result);
}

void JPH_Wheel_GetContactLongitudinal(const JPH_Wheel* wheel, JPH_Vec3* result)
{
	FromJolt(AsWheel(wheel)->GetContactLongitudinal(), result);
}

void JPH_Wheel_GetContactLateral(const JPH_Wheel* wheel, JPH_Vec3* result)
{
	FromJolt(AsWheel(wheel)->GetContactLateral(), result);
}

float JPH_Wheel_GetSuspensionLength(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetSuspensionLength();
}

float JPH_Wheel_GetSuspensionLambda(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetSuspensionLambda();
}

float JPH_Wheel_GetLongitudinalLambda(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetLongitudinalLambda();
}

float JPH_Wheel_GetLateralLambda(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->GetLateralLambda();
}

bool JPH_Wheel_HasHitHardPoint(const JPH_Wheel* wheel)
{
	return AsWheel(wheel)->HasHitHardPoint();
}


/* VehicleAntiRollBar */
JPH_CAPI void JPH_VehicleAntiRollBar_Init(JPH_VehicleAntiRollBar* antiRollBar)
{
	memset(antiRollBar, 0, sizeof(JPH_VehicleAntiRollBar));

	JPH_ASSERT(antiRollBar);

	JPH::VehicleAntiRollBar joltAntiRollBar{};
	antiRollBar->leftWheel = joltAntiRollBar.mLeftWheel;
	antiRollBar->rightWheel = joltAntiRollBar.mRightWheel;
	antiRollBar->stiffness = joltAntiRollBar.mStiffness;
}

/* VehicleEngineSettings */
void JPH_VehicleEngineSettings_Init(JPH_VehicleEngineSettings* settings)
{
	memset(settings, 0, sizeof(JPH_VehicleEngineSettings));

	JPH_ASSERT(settings);

	JPH::VehicleEngineSettings joltSettings{};
	settings->maxTorque = joltSettings.mMaxTorque;
	settings->minRPM = joltSettings.mMinRPM;
	settings->maxRPM = joltSettings.mMaxRPM;
	settings->inertia = joltSettings.mInertia;
	settings->angularDamping = joltSettings.mAngularDamping;

	// Copy default normalized torque to JPH_VehicleEngineSettings->normalizedTorque
	auto joltNormalizedTorque = joltSettings.mNormalizedTorque;
	auto pointCount = joltNormalizedTorque.mPoints.size();
	auto normalizedTorque = JPH_LinearCurve_Create();
	JPH_LinearCurve_Reserve(normalizedTorque, pointCount);
	for (int i = 0; i < pointCount; ++i) {
		auto point = joltNormalizedTorque.mPoints[i];
		JPH_LinearCurve_AddPoint(normalizedTorque, point.mX, point.mY);
	}
	settings->normalizedTorque = normalizedTorque;
}

static void JPH_VehicleEngineSettings_FromJolt(JPH_VehicleEngineSettings* settings, const VehicleEngineSettings& joltSettings)
{
	JPH_ASSERT(settings);

	settings->maxTorque = joltSettings.mMaxTorque;
	settings->minRPM = joltSettings.mMinRPM;
	settings->maxRPM = joltSettings.mMaxRPM;
	settings->inertia = joltSettings.mInertia;
	settings->angularDamping = joltSettings.mAngularDamping;
	settings->normalizedTorque = ToLinearCurve(&joltSettings.mNormalizedTorque);
}

static void JPH_VehicleEngineSettings_ToJolt(VehicleEngineSettings* joltSettings, const JPH_VehicleEngineSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	joltSettings->mMaxTorque = settings->maxTorque;
	joltSettings->mMinRPM = settings->minRPM;
	joltSettings->mMaxRPM = settings->maxRPM;
	joltSettings->mInertia = settings->inertia;
	joltSettings->mAngularDamping = settings->angularDamping;
	joltSettings->mNormalizedTorque = AsLinearCurve(*settings->normalizedTorque);
}

/* VehicleEngine */
void JPH_VehicleEngine_ClampRPM(JPH_VehicleEngine* engine)
{
	AsVehicleEngine(engine)->ClampRPM();
}

float JPH_VehicleEngine_GetCurrentRPM(const JPH_VehicleEngine* engine)
{
	return AsVehicleEngine(engine)->GetCurrentRPM();
}

void JPH_VehicleEngine_SetCurrentRPM(JPH_VehicleEngine* engine, float rpm)
{
	AsVehicleEngine(engine)->SetCurrentRPM(rpm);
}

float JPH_VehicleEngine_GetAngularVelocity(const JPH_VehicleEngine* engine)
{
	return AsVehicleEngine(engine)->GetAngularVelocity();
}

float JPH_VehicleEngine_GetTorque(const JPH_VehicleEngine* engine, float acceleration)
{
	return AsVehicleEngine(engine)->GetTorque(acceleration);
}

void JPH_VehicleEngine_ApplyTorque(JPH_VehicleEngine* engine, float torque, float deltaTime)
{
	AsVehicleEngine(engine)->ApplyTorque(torque, deltaTime);
}

void JPH_VehicleEngine_ApplyDamping(JPH_VehicleEngine* engine, float deltaTime)
{
	AsVehicleEngine(engine)->ApplyDamping(deltaTime);
}

bool JPH_VehicleEngine_AllowSleep(const JPH_VehicleEngine* engine)
{
	return AsVehicleEngine(engine)->AllowSleep();
}

/* VehicleDifferentialSettings */
void JPH_VehicleDifferentialSettings_Init(JPH_VehicleDifferentialSettings* settings)
{
	memset(settings, 0, sizeof(JPH_VehicleDifferentialSettings));

	JPH_ASSERT(settings);

	VehicleDifferentialSettings joltSettings{};
	settings->leftWheel = joltSettings.mLeftWheel;
	settings->rightWheel = joltSettings.mRightWheel;
	settings->differentialRatio = joltSettings.mDifferentialRatio;
	settings->leftRightSplit = joltSettings.mLeftRightSplit;
	settings->limitedSlipRatio = joltSettings.mLimitedSlipRatio;
	settings->engineTorqueRatio = joltSettings.mEngineTorqueRatio;
}

static void JPH_VehicleDifferentialSettings_FromJolt(JPH_VehicleDifferentialSettings* settings, const VehicleDifferentialSettings& joltSettings)
{
	// Copy settings to jolt 
	settings->leftWheel = joltSettings.mLeftWheel;
	settings->rightWheel = joltSettings.mRightWheel;
	settings->differentialRatio = joltSettings.mDifferentialRatio;
	settings->leftRightSplit = joltSettings.mLeftRightSplit;
	settings->limitedSlipRatio = joltSettings.mLimitedSlipRatio;
	settings->engineTorqueRatio = joltSettings.mEngineTorqueRatio;
}

static VehicleDifferentialSettings JPH_VehicleDifferentialSettings_ToJolt(const JPH_VehicleDifferentialSettings& settings)
{
	VehicleDifferentialSettings joltSettings{};
	joltSettings.mLeftWheel = settings.leftWheel;
	joltSettings.mRightWheel = settings.rightWheel;
	joltSettings.mDifferentialRatio = settings.differentialRatio;
	joltSettings.mLeftRightSplit = settings.leftRightSplit;
	joltSettings.mLimitedSlipRatio = settings.limitedSlipRatio;
	joltSettings.mEngineTorqueRatio = settings.engineTorqueRatio;
	return joltSettings;
}

/* VehicleTransmissionSettings */
JPH_VehicleTransmissionSettings* JPH_VehicleTransmissionSettings_Create(void)
{
	auto settings = new VehicleTransmissionSettings();
	return ToVehicleTransmissionSettings(settings);
}

void JPH_VehicleTransmissionSettings_Destroy(JPH_VehicleTransmissionSettings* settings)
{
	if (settings)
	{
		delete AsVehicleTransmissionSettings(settings);
	}
}

JPH_TransmissionMode JPH_VehicleTransmissionSettings_GetMode(const JPH_VehicleTransmissionSettings* settings)
{
	return static_cast<JPH_TransmissionMode>(AsVehicleTransmissionSettings(settings)->mMode);
}

void JPH_VehicleTransmissionSettings_SetMode(JPH_VehicleTransmissionSettings* settings, JPH_TransmissionMode value)
{
	AsVehicleTransmissionSettings(settings)->mMode = static_cast<JPH::ETransmissionMode>(value);
}

uint32_t JPH_VehicleTransmissionSettings_GetGearRatioCount(const JPH_VehicleTransmissionSettings* settings)
{
	return static_cast<uint32_t>(AsVehicleTransmissionSettings(settings)->mGearRatios.size());
}

float JPH_VehicleTransmissionSettings_GetGearRatio(const JPH_VehicleTransmissionSettings* settings, uint32_t index)
{
	return AsVehicleTransmissionSettings(settings)->mGearRatios[index];
}

void JPH_VehicleTransmissionSettings_SetGearRatio(JPH_VehicleTransmissionSettings* settings, uint32_t index, float value)
{
	AsVehicleTransmissionSettings(settings)->mGearRatios[index] = value;
}

const float* JPH_VehicleTransmissionSettings_GetGearRatios(const JPH_VehicleTransmissionSettings* settings)
{
	JPH_ASSERT(settings);

	return AsVehicleTransmissionSettings(settings)->mGearRatios.data();
}

void JPH_VehicleTransmissionSettings_SetGearRatios(JPH_VehicleTransmissionSettings* settings, const float* values, uint32_t count)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(values);

	AsVehicleTransmissionSettings(settings)->mGearRatios.resize(count);
	for (uint32_t i = 0; i < count; ++i)
	{
		AsVehicleTransmissionSettings(settings)->mGearRatios[i] = values[i];
	}
}

uint32_t JPH_VehicleTransmissionSettings_GetReverseGearRatioCount(const JPH_VehicleTransmissionSettings* settings)
{
	return static_cast<uint32_t>(AsVehicleTransmissionSettings(settings)->mReverseGearRatios.size());
}

float JPH_VehicleTransmissionSettings_GetReverseGearRatio(const JPH_VehicleTransmissionSettings* settings, uint32_t index)
{
	return AsVehicleTransmissionSettings(settings)->mReverseGearRatios[index];
}

void JPH_VehicleTransmissionSettings_SetReverseGearRatio(JPH_VehicleTransmissionSettings* settings, uint32_t index, float value)
{
	AsVehicleTransmissionSettings(settings)->mReverseGearRatios[index] = value;
}

const float* JPH_VehicleTransmissionSettings_GetReverseGearRatios(const JPH_VehicleTransmissionSettings* settings)
{
	JPH_ASSERT(settings);

	return AsVehicleTransmissionSettings(settings)->mReverseGearRatios.data();
}

void JPH_VehicleTransmissionSettings_SetReverseGearRatios(JPH_VehicleTransmissionSettings* settings, const float* values, uint32_t count)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(values);

	AsVehicleTransmissionSettings(settings)->mReverseGearRatios.resize(count);
	for (uint32_t i = 0; i < count; ++i)
	{
		AsVehicleTransmissionSettings(settings)->mReverseGearRatios[i] = values[i];
	}
}

float JPH_VehicleTransmissionSettings_GetSwitchTime(const JPH_VehicleTransmissionSettings* settings)
{
	return AsVehicleTransmissionSettings(settings)->mSwitchTime;
}

void JPH_VehicleTransmissionSettings_SetSwitchTime(JPH_VehicleTransmissionSettings* settings, float value)
{
	AsVehicleTransmissionSettings(settings)->mSwitchTime = value;
}

float JPH_VehicleTransmissionSettings_GetClutchReleaseTime(const JPH_VehicleTransmissionSettings* settings)
{
	return AsVehicleTransmissionSettings(settings)->mClutchReleaseTime;
}

void JPH_VehicleTransmissionSettings_SetClutchReleaseTime(JPH_VehicleTransmissionSettings* settings, float value)
{
	AsVehicleTransmissionSettings(settings)->mClutchReleaseTime = value;
}

float JPH_VehicleTransmissionSettings_GetSwitchLatency(const JPH_VehicleTransmissionSettings* settings)
{
	return AsVehicleTransmissionSettings(settings)->mSwitchLatency;
}

void JPH_VehicleTransmissionSettings_SetSwitchLatency(JPH_VehicleTransmissionSettings* settings, float value)
{
	AsVehicleTransmissionSettings(settings)->mSwitchLatency = value;
}

float JPH_VehicleTransmissionSettings_GetShiftUpRPM(const JPH_VehicleTransmissionSettings* settings)
{
	return AsVehicleTransmissionSettings(settings)->mShiftUpRPM;
}

void JPH_VehicleTransmissionSettings_SetShiftUpRPM(JPH_VehicleTransmissionSettings* settings, float value)
{
	AsVehicleTransmissionSettings(settings)->mShiftUpRPM = value;
}

float JPH_VehicleTransmissionSettings_GetShiftDownRPM(const JPH_VehicleTransmissionSettings* settings)
{
	return AsVehicleTransmissionSettings(settings)->mShiftDownRPM;
}

void JPH_VehicleTransmissionSettings_SetShiftDownRPM(JPH_VehicleTransmissionSettings* settings, float value)
{
	AsVehicleTransmissionSettings(settings)->mShiftDownRPM = value;
}

float JPH_VehicleTransmissionSettings_GetClutchStrength(const JPH_VehicleTransmissionSettings* settings)
{
	return AsVehicleTransmissionSettings(settings)->mClutchStrength;
}

void JPH_VehicleTransmissionSettings_SetClutchStrength(JPH_VehicleTransmissionSettings* settings, float value)
{
	AsVehicleTransmissionSettings(settings)->mClutchStrength = value;
}

/* VehicleTransmission */
void JPH_VehicleTransmission_SetMode(JPH_VehicleTransmission* transmission, JPH_TransmissionMode mode)
{
	AsVehicleTransmission(transmission)->mMode = static_cast<JPH::ETransmissionMode>(mode);
}

void JPH_VehicleTransmission_Set(JPH_VehicleTransmission* transmission, int currentGear, float clutchFriction)
{
	AsVehicleTransmission(transmission)->Set(currentGear, clutchFriction);
}

void JPH_VehicleTransmission_Update(JPH_VehicleTransmission* transmission, float deltaTime, float currentRPM, float forwardInput, bool canShiftUp)
{
	AsVehicleTransmission(transmission)->Update(deltaTime, currentRPM, forwardInput, canShiftUp);
}

int JPH_VehicleTransmission_GetCurrentGear(const JPH_VehicleTransmission* transmission)
{
	return AsVehicleTransmission(transmission)->GetCurrentGear();
}

float JPH_VehicleTransmission_GetClutchFriction(const JPH_VehicleTransmission* transmission)
{
	return AsVehicleTransmission(transmission)->GetClutchFriction();
}

bool JPH_VehicleTransmission_IsSwitchingGear(const JPH_VehicleTransmission* transmission)
{
	return AsVehicleTransmission(transmission)->IsSwitchingGear();
}

float JPH_VehicleTransmission_GetCurrentRatio(const JPH_VehicleTransmission* transmission)
{
	return AsVehicleTransmission(transmission)->GetCurrentRatio();
}

bool JPH_VehicleTransmission_AllowSleep(const JPH_VehicleTransmission* transmission)
{
	return AsVehicleTransmission(transmission)->AllowSleep();

}

/* VehicleCollisionTester */
void JPH_VehicleCollisionTester_Destroy(JPH_VehicleCollisionTester* tester)
{
	if (tester)
	{
		auto joltTester = reinterpret_cast<const JPH::VehicleCollisionTester*>(tester);
		joltTester->Release();
	}
}

JPH_ObjectLayer JPH_VehicleCollisionTester_GetObjectLayer(const JPH_VehicleCollisionTester* tester)
{
	return static_cast<JPH_ObjectLayer>(AsVehicleCollisionTester(tester)->GetObjectLayer());
}

void JPH_VehicleCollisionTester_SetObjectLayer(JPH_VehicleCollisionTester* tester, JPH_ObjectLayer value)
{
	AsVehicleCollisionTester(tester)->SetObjectLayer(static_cast<JPH::ObjectLayer>(value));
}

JPH_VehicleCollisionTesterRay* JPH_VehicleCollisionTesterRay_Create(JPH_ObjectLayer layer, const JPH_Vec3* up, float maxSlopeAngle)
{
	auto tester = new VehicleCollisionTesterRay(static_cast<JPH::ObjectLayer>(layer), ToJolt(up), maxSlopeAngle);
	tester->AddRef();

	return ToVehicleCollisionTesterRay(tester);
}

JPH_VehicleCollisionTesterCastSphere* JPH_VehicleCollisionTesterCastSphere_Create(JPH_ObjectLayer layer, float radius, const JPH_Vec3* up, float maxSlopeAngle)
{
	auto tester = new VehicleCollisionTesterCastSphere(static_cast<JPH::ObjectLayer>(layer), radius, ToJolt(up), maxSlopeAngle);
	tester->AddRef();

	return ToVehicleCollisionTesterCastSphere(tester);
}

JPH_VehicleCollisionTesterCastCylinder* JPH_VehicleCollisionTesterCastCylinder_Create(JPH_ObjectLayer layer, float convexRadiusFraction)
{
	auto tester = new VehicleCollisionTesterCastCylinder(static_cast<JPH::ObjectLayer>(layer), convexRadiusFraction);
	tester->AddRef();

	return ToVehicleCollisionTesterCastCylinder(tester);
}

/* VehicleConstraintSettings */
void JPH_VehicleConstraintSettings_FromJolt(JPH_VehicleConstraintSettings* settings, const VehicleConstraintSettings& joltSettings)
{
	JPH_ASSERT(settings);

	// Base
	JPH_ConstraintSettings_Init(joltSettings, &settings->base);

	FromJolt(joltSettings.mUp, &settings->up);
	FromJolt(joltSettings.mForward, &settings->forward);
	settings->maxPitchRollAngle = joltSettings.mMaxPitchRollAngle;
	settings->wheelsCount = 0;
	settings->wheels = nullptr;
	settings->controller = nullptr;
}

void JPH_VehicleConstraintSettings_Init(JPH_VehicleConstraintSettings* settings)
{
	memset(settings, 0, sizeof(JPH_VehicleConstraintSettings));

	JPH_ASSERT(settings);

	// Copy defaults from jolt 
	VehicleConstraintSettings joltSettings;
	JPH_VehicleConstraintSettings_FromJolt(settings, joltSettings);
}

void JPH_VehicleConstraintSettings_ToJolt(VehicleConstraintSettings* joltSettings, const JPH_VehicleConstraintSettings* settings)
{
	JPH_ASSERT(joltSettings);
	JPH_ASSERT(settings);

	// Base settings
	JPH_ConstraintSettings_ToJolt(joltSettings, &settings->base);

	joltSettings->mUp = ToJolt(settings->up);
	joltSettings->mForward = ToJolt(settings->forward);
	joltSettings->mMaxPitchRollAngle = settings->maxPitchRollAngle;

	joltSettings->mWheels.resize(settings->wheelsCount);
	for (uint32_t i = 0; i < settings->wheelsCount; ++i)
	{
		joltSettings->mWheels[i] = AsWheelSettings(settings->wheels[i]);
	}

	if (settings->antiRollBarsCount > 0)
	{
		joltSettings->mAntiRollBars.resize(settings->antiRollBarsCount);
		for (uint32_t i = 0; i < settings->antiRollBarsCount; ++i)
		{
			JPH::VehicleAntiRollBar joltAntiRollBar{};
			joltAntiRollBar.mLeftWheel = settings->antiRollBars[i].leftWheel;
			joltAntiRollBar.mRightWheel = settings->antiRollBars[i].rightWheel;
			joltAntiRollBar.mStiffness = settings->antiRollBars[i].stiffness;
			joltSettings->mAntiRollBars[i] = joltAntiRollBar;
		}
	}

	if (settings->controller)
	{
		joltSettings->mController = AsVehicleControllerSettings(settings->controller);
	}
}

JPH_VehicleConstraint* JPH_VehicleConstraint_Create(JPH_Body* body, const JPH_VehicleConstraintSettings* settings)
{
	JPH_ASSERT(body);
	JPH_ASSERT(settings);

	VehicleConstraintSettings joltSettings;
	JPH_VehicleConstraintSettings_ToJolt(&joltSettings, settings);

	auto vehicleConstraint = new VehicleConstraint(*AsBody(body), joltSettings);
	vehicleConstraint->AddRef();

	return ToVehicleConstraint(vehicleConstraint);
}

JPH_PhysicsStepListener* JPH_VehicleConstraint_AsPhysicsStepListener(JPH_VehicleConstraint* constraint)
{
	JPH_ASSERT(constraint);

	PhysicsStepListener* joltListener = static_cast<PhysicsStepListener*>(AsVehicleConstraint(constraint));
	return ToPhysicsStepListener(joltListener);
}

void JPH_VehicleConstraint_SetMaxPitchRollAngle(JPH_VehicleConstraint* constraint, float maxPitchRollAngle)
{
	AsVehicleConstraint(constraint)->SetMaxPitchRollAngle(maxPitchRollAngle);
}

void JPH_VehicleConstraint_SetVehicleCollisionTester(JPH_VehicleConstraint* constraint, const JPH_VehicleCollisionTester* tester)
{
	AsVehicleConstraint(constraint)->SetVehicleCollisionTester(AsVehicleCollisionTester(tester));
}

void JPH_VehicleConstraint_OverrideGravity(JPH_VehicleConstraint* constraint, const JPH_Vec3* value)
{
	AsVehicleConstraint(constraint)->OverrideGravity(ToJolt(value));
}

bool JPH_VehicleConstraint_IsGravityOverridden(const JPH_VehicleConstraint* constraint)
{
	return AsVehicleConstraint(constraint)->IsGravityOverridden();
}

void JPH_VehicleConstraint_GetGravityOverride(const JPH_VehicleConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsVehicleConstraint(constraint)->GetGravityOverride(), result);
}

void JPH_VehicleConstraint_ResetGravityOverride(JPH_VehicleConstraint* constraint)
{
	AsVehicleConstraint(constraint)->ResetGravityOverride();
}

void JPH_VehicleConstraint_GetLocalForward(const JPH_VehicleConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsVehicleConstraint(constraint)->GetLocalForward(), result);
}

void JPH_VehicleConstraint_GetLocalUp(const JPH_VehicleConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsVehicleConstraint(constraint)->GetLocalUp(), result);
}

void JPH_VehicleConstraint_GetWorldUp(const JPH_VehicleConstraint* constraint, JPH_Vec3* result)
{
	FromJolt(AsVehicleConstraint(constraint)->GetWorldUp(), result);
}

const JPH_Body* JPH_VehicleConstraint_GetVehicleBody(const JPH_VehicleConstraint* constraint)
{
	return ToBody(AsVehicleConstraint(constraint)->GetVehicleBody());
}

JPH_VehicleController* JPH_VehicleConstraint_GetController(JPH_VehicleConstraint* constraint)
{
	return ToVehicleController(AsVehicleConstraint(constraint)->GetController());
}

uint32_t JPH_VehicleConstraint_GetWheelsCount(JPH_VehicleConstraint* constraint)
{
	return static_cast<uint32_t>(AsVehicleConstraint(constraint)->GetWheels().size());
}

JPH_Wheel* JPH_VehicleConstraint_GetWheel(JPH_VehicleConstraint* constraint, uint32_t index)
{
	return ToWheel(AsVehicleConstraint(constraint)->GetWheel(index));
}

void JPH_VehicleConstraint_GetWheelLocalBasis(JPH_VehicleConstraint* constraint, const JPH_Wheel* wheel, JPH_Vec3* outForward, JPH_Vec3* outUp, JPH_Vec3* outRight)
{
	Vec3 forward, up, right;

	AsVehicleConstraint(constraint)->GetWheelLocalBasis(AsWheel(wheel), forward, up, right);
	FromJolt(forward, outForward);
	FromJolt(up, outUp);
	FromJolt(right, outRight);
}

void JPH_VehicleConstraint_GetWheelLocalTransform(JPH_VehicleConstraint* constraint, uint32_t wheelIndex, const JPH_Vec3* wheelRight, const JPH_Vec3* wheelUp, JPH_Mat4* result)
{
	Mat44 joltResult = AsVehicleConstraint(constraint)->GetWheelLocalTransform(wheelIndex, ToJolt(wheelRight), ToJolt(wheelUp));
	FromJolt(joltResult, result);
}

void JPH_VehicleConstraint_GetWheelWorldTransform(JPH_VehicleConstraint* constraint, uint32_t wheelIndex, const JPH_Vec3* wheelRight, const JPH_Vec3* wheelUp, JPH_RMat4* result)
{
	RMat44 joltResult = AsVehicleConstraint(constraint)->GetWheelWorldTransform(wheelIndex, ToJolt(wheelRight), ToJolt(wheelUp));
	FromJolt(joltResult, result);
}

/* VehicleControllerSettings */
void JPH_VehicleControllerSettings_Destroy(JPH_VehicleControllerSettings* settings)
{
	if (settings)
	{
		AsVehicleControllerSettings(settings)->Release();
	}
}

const JPH_VehicleConstraint* JPH_VehicleController_GetConstraint(JPH_VehicleController* controller)
{
	auto constraint = &AsVehicleController(controller)->GetConstraint();
	return ToVehicleConstraint(constraint);
}

/* ---- WheelSettingsWV/WheelWV/WheeledVehicleController ---- */
JPH_WheelSettingsWV* JPH_WheelSettingsWV_Create(void)
{
	auto settings = new JPH::WheelSettingsWV();
	settings->AddRef();

	return ToWheelSettingsWV(settings);
}

float JPH_WheelSettingsWV_GetInertia(const JPH_WheelSettingsWV* settings)
{
	return AsWheelSettingsWV(settings)->mInertia;
}

void JPH_WheelSettingsWV_SetInertia(JPH_WheelSettingsWV* settings, float value)
{
	AsWheelSettingsWV(settings)->mInertia = value;
}

float JPH_WheelSettingsWV_GetAngularDamping(const JPH_WheelSettingsWV* settings)
{
	return AsWheelSettingsWV(settings)->mAngularDamping;
}

void JPH_WheelSettingsWV_SetAngularDamping(JPH_WheelSettingsWV* settings, float value)
{
	AsWheelSettingsWV(settings)->mAngularDamping = value;
}

float JPH_WheelSettingsWV_GetMaxSteerAngle(const JPH_WheelSettingsWV* settings)
{
	return AsWheelSettingsWV(settings)->mMaxSteerAngle;
}

void JPH_WheelSettingsWV_SetMaxSteerAngle(JPH_WheelSettingsWV* settings, float value)
{
	AsWheelSettingsWV(settings)->mMaxSteerAngle = value;
}

const JPH_LinearCurve* JPH_WheelSettingsWV_GetLongitudinalFriction(const JPH_WheelSettingsWV* settings)
{
	return ToLinearCurve(&AsWheelSettingsWV(settings)->mLongitudinalFriction);
}

void JPH_WheelSettingsWV_SetLongitudinalFriction(JPH_WheelSettingsWV* settings, const JPH_LinearCurve* value)
{
	AsWheelSettingsWV(settings)->mLongitudinalFriction = *AsLinearCurve(value);
}

const JPH_LinearCurve* JPH_WheelSettingsWV_GetLateralFriction(const JPH_WheelSettingsWV* settings)
{
	return ToLinearCurve(&AsWheelSettingsWV(settings)->mLateralFriction);
}

void JPH_WheelSettingsWV_SetLateralFriction(JPH_WheelSettingsWV* settings, const JPH_LinearCurve* value)
{
	AsWheelSettingsWV(settings)->mLateralFriction = *AsLinearCurve(value);
}

float JPH_WheelSettingsWV_GetMaxBrakeTorque(const JPH_WheelSettingsWV* settings)
{
	return AsWheelSettingsWV(settings)->mMaxBrakeTorque;
}

void JPH_WheelSettingsWV_SetMaxBrakeTorque(JPH_WheelSettingsWV* settings, float value)
{
	AsWheelSettingsWV(settings)->mMaxBrakeTorque = value;
}

float JPH_WheelSettingsWV_GetMaxHandBrakeTorque(const JPH_WheelSettingsWV* settings)
{
	return AsWheelSettingsWV(settings)->mMaxHandBrakeTorque;
}

void JPH_WheelSettingsWV_SetMaxHandBrakeTorque(JPH_WheelSettingsWV* settings, float value)
{
	AsWheelSettingsWV(settings)->mMaxHandBrakeTorque = value;
}

JPH_WheelWV* JPH_WheelWV_Create(const JPH_WheelSettingsWV* settings)
{
	JPH_ASSERT(settings);

	auto wheel = new JPH::WheelWV(*AsWheelSettingsWV(settings));
	return ToWheelWV(wheel);
}

const JPH_WheelSettingsWV* JPH_WheelWV_GetSettings(const JPH_WheelWV* wheel)
{
	return ToWheelSettingsWV(AsWheelWV(wheel)->GetSettings());
}

void JPH_WheelWV_ApplyTorque(JPH_WheelWV* wheel, float torque, float deltaTime)
{
	AsWheelWV(wheel)->ApplyTorque(torque, deltaTime);
}

JPH_WheeledVehicleControllerSettings* JPH_WheeledVehicleControllerSettings_Create(void)
{
	auto settings = new WheeledVehicleControllerSettings();
	settings->AddRef();

	return ToWheeledVehicleControllerSettings(settings);
}

void JPH_WheeledVehicleControllerSettings_GetEngine(const JPH_WheeledVehicleControllerSettings* settings, JPH_VehicleEngineSettings* result)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(result);

	JPH_VehicleEngineSettings_FromJolt(result, AsWheeledVehicleControllerSettings(settings)->mEngine);
}

void JPH_WheeledVehicleControllerSettings_SetEngine(JPH_WheeledVehicleControllerSettings* settings, const JPH_VehicleEngineSettings* value)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(value);

	VehicleEngineSettings joltEngine;
	JPH_VehicleEngineSettings_ToJolt(&joltEngine, value);

	AsWheeledVehicleControllerSettings(settings)->mEngine = joltEngine;
}

const JPH_VehicleTransmissionSettings* JPH_WheeledVehicleControllerSettings_GetTransmission(const JPH_WheeledVehicleControllerSettings* settings)
{
	JPH_ASSERT(settings);

	return ToVehicleTransmissionSettings(&AsWheeledVehicleControllerSettings(settings)->mTransmission);
}

void JPH_WheeledVehicleControllerSettings_SetTransmission(JPH_WheeledVehicleControllerSettings* settings, const JPH_VehicleTransmissionSettings* value)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(value);

	AsWheeledVehicleControllerSettings(settings)->mTransmission = *AsVehicleTransmissionSettings(value);
}

uint32_t JPH_WheeledVehicleControllerSettings_GetDifferentialsCount(const JPH_WheeledVehicleControllerSettings* settings)
{
	return static_cast<uint32_t>(AsWheeledVehicleControllerSettings(settings)->mDifferentials.size());
}

void JPH_WheeledVehicleControllerSettings_SetDifferentialsCount(JPH_WheeledVehicleControllerSettings* settings, uint32_t count)
{
	AsWheeledVehicleControllerSettings(settings)->mDifferentials.resize(count);
}

void JPH_WheeledVehicleControllerSettings_GetDifferential(const JPH_WheeledVehicleControllerSettings* settings, uint32_t index, JPH_VehicleDifferentialSettings* result)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(result);

	JPH_VehicleDifferentialSettings_FromJolt(result, AsWheeledVehicleControllerSettings(settings)->mDifferentials[index]);
}

void JPH_WheeledVehicleControllerSettings_SetDifferential(JPH_WheeledVehicleControllerSettings* settings, uint32_t index, const JPH_VehicleDifferentialSettings* value)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(value);

	VehicleDifferentialSettings joltDifferential = JPH_VehicleDifferentialSettings_ToJolt(*value);
	AsWheeledVehicleControllerSettings(settings)->mDifferentials[index] = joltDifferential;
}

void JPH_WheeledVehicleControllerSettings_SetDifferentials(JPH_WheeledVehicleControllerSettings* settings, const JPH_VehicleDifferentialSettings* values, uint32_t count)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(values);

	AsWheeledVehicleControllerSettings(settings)->mDifferentials.resize(count);
	for (uint32_t i = 0; i < count; ++i)
	{
		VehicleDifferentialSettings joltDifferential = JPH_VehicleDifferentialSettings_ToJolt(values[i]);
		AsWheeledVehicleControllerSettings(settings)->mDifferentials[i] = joltDifferential;
	}
}

// Helper to ensure a wheel is driven without manual diff setup
JPH_CAPI void JPH_WheeledVehicleControllerSettings_AddDifferential(JPH_WheeledVehicleControllerSettings* settings, int leftWheel, int rightWheel)
{
	JPH_ASSERT(settings);
	VehicleDifferentialSettings diff;
	diff.mLeftWheel = leftWheel;
	diff.mRightWheel = rightWheel;
	diff.mDifferentialRatio = 3.5f;
	diff.mLimitedSlipRatio = 1.4f;
	diff.mEngineTorqueRatio = 1.0f; // This is normalized automatically when multiple are added

	auto* controller = AsWheeledVehicleControllerSettings(settings);
	controller->mDifferentials.push_back(diff);

	// Ensure torque is split evenly across all differentials (e.g. 0.5 for Front, 0.5 for Rear)
	float ratio = 1.0f / (float)controller->mDifferentials.size();
	for (auto& d : controller->mDifferentials) {
		d.mEngineTorqueRatio = ratio;
	}
}

float JPH_WheeledVehicleControllerSettings_GetDifferentialLimitedSlipRatio(const JPH_WheeledVehicleControllerSettings* settings)
{
	return AsWheeledVehicleControllerSettings(settings)->mDifferentialLimitedSlipRatio;
}

void JPH_WheeledVehicleControllerSettings_SetDifferentialLimitedSlipRatio(JPH_WheeledVehicleControllerSettings* settings, float value)
{
	AsWheeledVehicleControllerSettings(settings)->mDifferentialLimitedSlipRatio = value;
}

void JPH_WheeledVehicleController_SetDriverInput(JPH_WheeledVehicleController* controller, float forward, float right, float brake, float handBrake)
{
	AsWheeledVehicleController(controller)->SetDriverInput(forward, right, brake, handBrake);
}

void JPH_WheeledVehicleController_SetForwardInput(JPH_WheeledVehicleController* controller, float forward)
{
	AsWheeledVehicleController(controller)->SetForwardInput(forward);
}

float JPH_WheeledVehicleController_GetForwardInput(const JPH_WheeledVehicleController* controller)
{
	return AsWheeledVehicleController(controller)->GetForwardInput();
}

void JPH_WheeledVehicleController_SetRightInput(JPH_WheeledVehicleController* controller, float right)
{
	AsWheeledVehicleController(controller)->SetRightInput(right);
}

float JPH_WheeledVehicleController_GetRightInput(const JPH_WheeledVehicleController* controller)
{
	return AsWheeledVehicleController(controller)->GetRightInput();
}

void JPH_WheeledVehicleController_SetBrakeInput(JPH_WheeledVehicleController* controller, float brake)
{
	AsWheeledVehicleController(controller)->SetBrakeInput(brake);
}

float JPH_WheeledVehicleController_GetBrakeInput(const JPH_WheeledVehicleController* controller)
{
	return AsWheeledVehicleController(controller)->GetBrakeInput();
}

void JPH_WheeledVehicleController_SetHandBrakeInput(JPH_WheeledVehicleController* controller, float handBrake)
{
	AsWheeledVehicleController(controller)->SetHandBrakeInput(handBrake);
}

float JPH_WheeledVehicleController_GetHandBrakeInput(const JPH_WheeledVehicleController* controller)
{
	return AsWheeledVehicleController(controller)->GetHandBrakeInput();
}

float JPH_WheeledVehicleController_GetWheelSpeedAtClutch(const JPH_WheeledVehicleController* controller)
{
	return AsWheeledVehicleController(controller)->GetWheelSpeedAtClutch();
}

void JPH_WheeledVehicleController_SetTireMaxImpulseCallback(JPH_WheeledVehicleController* controller, JPH_TireMaxImpulseCallback tireMaxImpulseCallback, void* userData)
{
	AsWheeledVehicleController(controller)->SetTireMaxImpulseCallback([tireMaxImpulseCallback, userData](
		int wheelIndex,
		float& outLongitudinalImpulse,
		float& outLateralImpulse,
		float inSuspensionImpulse,
		float inLongitudinalFriction,
		float inLateralFriction,
		float inLongitudinalSlip,
		float inLateralSlip,
		float deltaTime)
		{
			tireMaxImpulseCallback(
				userData,
				static_cast<uint32_t>(wheelIndex),
				&outLongitudinalImpulse,
				&outLateralImpulse,
				inSuspensionImpulse,
				inLongitudinalFriction,
				inLateralFriction,
				inLongitudinalSlip,
				inLateralSlip,
				deltaTime);
		}
	);
}

const JPH_VehicleEngine* JPH_WheeledVehicleController_GetEngine(const JPH_WheeledVehicleController* controller)
{
	return ToVehicleEngine(&AsWheeledVehicleController(controller)->GetEngine());
}

const JPH_VehicleTransmission* JPH_WheeledVehicleController_GetTransmission(const JPH_WheeledVehicleController* controller)
{
	return ToVehicleTransmission(&AsWheeledVehicleController(controller)->GetTransmission());
}

/* WheelSettingsTV - WheelTV - TrackedVehicleController */
JPH_WheelSettingsTV* JPH_WheelSettingsTV_Create(void)
{
	auto settings = new JPH::WheelSettingsTV();
	settings->AddRef();

	return ToWheelSettingsTV(settings);
}

float JPH_WheelSettingsTV_GetLongitudinalFriction(const JPH_WheelSettingsTV* settings)
{
	return AsWheelSettingsTV(settings)->mLongitudinalFriction;
}

void JPH_WheelSettingsTV_SetLongitudinalFriction(JPH_WheelSettingsTV* settings, float value)
{
	AsWheelSettingsTV(settings)->mLongitudinalFriction = value;
}

float JPH_WheelSettingsTV_GetLateralFriction(const JPH_WheelSettingsTV* settings)
{
	return AsWheelSettingsTV(settings)->mLateralFriction;
}

void JPH_WheelSettingsTV_SetLateralFriction(JPH_WheelSettingsTV* settings, float value)
{
	AsWheelSettingsTV(settings)->mLateralFriction = value;
}

JPH_WheelTV* JPH_WheelTV_Create(const JPH_WheelSettingsTV* settings)
{
	JPH_ASSERT(settings);

	auto wheel = new JPH::WheelTV(*AsWheelSettingsTV(settings));
	return ToWheelTV(wheel);
}

const JPH_WheelSettingsTV* JPH_WheelTV_GetSettings(const JPH_WheelTV* wheel)
{
	return ToWheelSettingsTV(AsWheelTV(wheel)->GetSettings());
}

JPH_TrackedVehicleControllerSettings* JPH_TrackedVehicleControllerSettings_Create(void)
{
	auto settings = new JPH::TrackedVehicleControllerSettings();
	settings->AddRef();
	return ToTrackedVehicleControllerSettings(settings);
}

void JPH_TrackedVehicleControllerSettings_GetEngine(const JPH_TrackedVehicleControllerSettings* settings, JPH_VehicleEngineSettings* result)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(result);

	JPH_VehicleEngineSettings_FromJolt(result, AsTrackedVehicleControllerSettings(settings)->mEngine);
}

void JPH_TrackedVehicleControllerSettings_SetEngine(JPH_TrackedVehicleControllerSettings* settings, const JPH_VehicleEngineSettings* value)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(value);

	VehicleEngineSettings joltEngine;
	JPH_VehicleEngineSettings_ToJolt(&joltEngine, value);

	AsTrackedVehicleControllerSettings(settings)->mEngine = joltEngine;
}

const JPH_VehicleTransmissionSettings* JPH_TrackedVehicleControllerSettings_GetTransmission(const JPH_TrackedVehicleControllerSettings* settings)
{
	JPH_ASSERT(settings);
	return ToVehicleTransmissionSettings(&AsTrackedVehicleControllerSettings(settings)->mTransmission);
}

JPH_CAPI void JPH_TrackedVehicleControllerSettings_SetTransmission(JPH_TrackedVehicleControllerSettings* settings, const JPH_VehicleTransmissionSettings* value)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(value);

	AsTrackedVehicleControllerSettings(settings)->mTransmission = *AsVehicleTransmissionSettings(value);
}

JPH_CAPI void JPH_TrackedVehicleControllerSettings_SetTrack(JPH_TrackedVehicleControllerSettings* settings, uint32_t index, const JPH_VehicleTrackSettings* track)
{
	JPH_ASSERT(settings);
	JPH_ASSERT(track);

	// Jolt only supports 2 tracks (Left=0, Right=1)
	if (index >= 2) return;

	JPH::VehicleTrackSettings joltTrack;
	ToJolt(joltTrack, track);

	AsTrackedVehicleControllerSettings(settings)->mTracks[index] = joltTrack;
}

void JPH_TrackedVehicleController_SetDriverInput(JPH_TrackedVehicleController* controller, float forward, float leftRatio, float rightRatio, float brake)
{
	AsTrackedVehicleController(controller)->SetDriverInput(forward, leftRatio, rightRatio, brake);
}

float JPH_TrackedVehicleController_GetForwardInput(const JPH_TrackedVehicleController* controller)
{
	return AsTrackedVehicleController(controller)->GetForwardInput();
}

void JPH_TrackedVehicleController_SetForwardInput(JPH_TrackedVehicleController* controller, float value)
{
	AsTrackedVehicleController(controller)->SetForwardInput(value);
}

float JPH_TrackedVehicleController_GetLeftRatio(const JPH_TrackedVehicleController* controller)
{
	return AsTrackedVehicleController(controller)->GetLeftRatio();
}

void JPH_TrackedVehicleController_SetLeftRatio(JPH_TrackedVehicleController* controller, float value)
{
	AsTrackedVehicleController(controller)->SetLeftRatio(value);
}

float JPH_TrackedVehicleController_GetRightRatio(const JPH_TrackedVehicleController* controller)
{
	return AsTrackedVehicleController(controller)->GetRightRatio();
}

void JPH_TrackedVehicleController_SetRightRatio(JPH_TrackedVehicleController* controller, float value)
{
	AsTrackedVehicleController(controller)->SetRightRatio(value);
}

float JPH_TrackedVehicleController_GetBrakeInput(const JPH_TrackedVehicleController* controller)
{
	return AsTrackedVehicleController(controller)->GetBrakeInput();
}

void JPH_TrackedVehicleController_SetBrakeInput(JPH_TrackedVehicleController* controller, float value)
{
	AsTrackedVehicleController(controller)->SetBrakeInput(value);
}

const JPH_VehicleEngine* JPH_TrackedVehicleController_GetEngine(const JPH_TrackedVehicleController* controller)
{
	return ToVehicleEngine(&AsTrackedVehicleController(controller)->GetEngine());
}

const JPH_VehicleTransmission* JPH_TrackedVehicleController_GetTransmission(const JPH_TrackedVehicleController* controller)
{
	return ToVehicleTransmission(&AsTrackedVehicleController(controller)->GetTransmission());
}

/* VehicleTrack */
void JPH_VehicleTrackSettings_Init(JPH_VehicleTrackSettings* settings)
{
	memset(settings, 0, sizeof(JPH_VehicleTrackSettings));

	settings->drivenWheel = 0;
	settings->wheels = nullptr;
	settings->wheelsCount = 0;
	settings->inertia = 10.0f;
	settings->angularDamping = 0.5f;
	settings->maxBrakeTorque = 15000.0f;
	settings->differentialRatio = 6.0f;
}

float JPH_VehicleTrack_GetAngularVelocity(const JPH_VehicleTrack* track)
{
	return AsVehicleTrack(track)->mAngularVelocity;
}

void JPH_VehicleTrack_SetAngularVelocity(JPH_VehicleTrack* track, float velocity)
{
	AsVehicleTrack(track)->mAngularVelocity = velocity;
}

uint32_t JPH_VehicleTrack_GetDrivenWheel(const JPH_VehicleTrack* track)
{
	return AsVehicleTrack(track)->mDrivenWheel;
}

float JPH_VehicleTrack_GetInertia(const JPH_VehicleTrack* track)
{
	return AsVehicleTrack(track)->mInertia;
}

float JPH_VehicleTrack_GetAngularDamping(const JPH_VehicleTrack* track)
{
	return AsVehicleTrack(track)->mAngularDamping;
}

float JPH_VehicleTrack_GetMaxBrakeTorque(const JPH_VehicleTrack* track)
{
	return AsVehicleTrack(track)->mMaxBrakeTorque;
}

float JPH_VehicleTrack_GetDifferentialRatio(const JPH_VehicleTrack* track)
{
	return AsVehicleTrack(track)->mDifferentialRatio;
}

const JPH_VehicleTrack* JPH_TrackedVehicleController_GetTrack(const JPH_TrackedVehicleController* controller, JPH_TrackSide side)
{
	return ToVehicleTrack(&AsTrackedVehicleController(controller)->GetTracks()[static_cast<int>(side)]);
}

/* MotorcycleController */
JPH_MotorcycleControllerSettings* JPH_MotorcycleControllerSettings_Create(void)
{
	auto settings = new JPH::MotorcycleControllerSettings();
	settings->AddRef();

	return ToMotorcycleControllerSettings(settings);
}

float JPH_MotorcycleControllerSettings_GetMaxLeanAngle(const JPH_MotorcycleControllerSettings* settings)
{
	return AsMotorcycleControllerSettings(settings)->mMaxLeanAngle;
}

JPH_CAPI void JPH_MotorcycleControllerSettings_SetMaxLeanAngle(JPH_MotorcycleControllerSettings* settings, float value)
{
	AsMotorcycleControllerSettings(settings)->mMaxLeanAngle = value;
}

float JPH_MotorcycleControllerSettings_GetLeanSpringConstant(const JPH_MotorcycleControllerSettings* settings)
{
	return AsMotorcycleControllerSettings(settings)->mLeanSpringConstant;
}

void JPH_MotorcycleControllerSettings_SetLeanSpringConstant(JPH_MotorcycleControllerSettings* settings, float value)
{
	AsMotorcycleControllerSettings(settings)->mLeanSpringConstant = value;
}

float JPH_MotorcycleControllerSettings_GetLeanSpringDamping(const JPH_MotorcycleControllerSettings* settings)
{
	return AsMotorcycleControllerSettings(settings)->mLeanSpringDamping;
}

void JPH_MotorcycleControllerSettings_SetLeanSpringDamping(JPH_MotorcycleControllerSettings* settings, float value)
{
	AsMotorcycleControllerSettings(settings)->mLeanSpringDamping = value;
}

float JPH_MotorcycleControllerSettings_GetLeanSpringIntegrationCoefficient(const JPH_MotorcycleControllerSettings* settings)
{
	return AsMotorcycleControllerSettings(settings)->mLeanSpringIntegrationCoefficient;
}

void JPH_MotorcycleControllerSettings_SetLeanSpringIntegrationCoefficient(JPH_MotorcycleControllerSettings* settings, float value)
{
	AsMotorcycleControllerSettings(settings)->mLeanSpringIntegrationCoefficient = value;
}

float JPH_MotorcycleControllerSettings_GetLeanSpringIntegrationCoefficientDecay(const JPH_MotorcycleControllerSettings* settings)
{
	return AsMotorcycleControllerSettings(settings)->mLeanSpringIntegrationCoefficientDecay;
}

void JPH_MotorcycleControllerSettings_SetLeanSpringIntegrationCoefficientDecay(JPH_MotorcycleControllerSettings* settings, float value)
{
	AsMotorcycleControllerSettings(settings)->mLeanSpringIntegrationCoefficientDecay = value;
}

float JPH_MotorcycleControllerSettings_GetLeanSmoothingFactor(const JPH_MotorcycleControllerSettings* settings)
{
	return AsMotorcycleControllerSettings(settings)->mLeanSmoothingFactor;
}

void JPH_MotorcycleControllerSettings_SetLeanSmoothingFactor(JPH_MotorcycleControllerSettings* settings, float value)
{
	AsMotorcycleControllerSettings(settings)->mLeanSmoothingFactor = value;
}

float JPH_MotorcycleController_GetWheelBase(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->GetWheelBase();
}

bool JPH_MotorcycleController_IsLeanControllerEnabled(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->IsLeanControllerEnabled();
}

void JPH_MotorcycleController_EnableLeanController(JPH_MotorcycleController* controller, bool value)
{
	AsMotorcycleController(controller)->EnableLeanController(value);
}

bool JPH_MotorcycleController_IsLeanSteeringLimitEnabled(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->IsLeanSteeringLimitEnabled();
}

void JPH_MotorcycleController_EnableLeanSteeringLimit(JPH_MotorcycleController* controller, bool value)
{
	AsMotorcycleController(controller)->EnableLeanSteeringLimit(value);
}

float JPH_MotorcycleController_GetLeanSpringConstant(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->GetLeanSpringConstant();
}

void JPH_MotorcycleController_SetLeanSpringConstant(JPH_MotorcycleController* controller, float value)
{
	AsMotorcycleController(controller)->SetLeanSpringConstant(value);
}

float JPH_MotorcycleController_GetLeanSpringDamping(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->GetLeanSpringDamping();
}

void JPH_MotorcycleController_SetLeanSpringDamping(JPH_MotorcycleController* controller, float value)
{
	AsMotorcycleController(controller)->SetLeanSpringDamping(value);
}

float JPH_MotorcycleController_GetLeanSpringIntegrationCoefficient(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->GetLeanSpringIntegrationCoefficient();
}

void JPH_MotorcycleController_SetLeanSpringIntegrationCoefficient(JPH_MotorcycleController* controller, float value)
{
	AsMotorcycleController(controller)->SetLeanSpringIntegrationCoefficient(value);
}

float JPH_MotorcycleController_GetLeanSpringIntegrationCoefficientDecay(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->GetLeanSpringIntegrationCoefficientDecay();
}

void JPH_MotorcycleController_SetLeanSpringIntegrationCoefficientDecay(JPH_MotorcycleController* controller, float value)
{
	AsMotorcycleController(controller)->SetLeanSpringIntegrationCoefficientDecay(value);
}

float JPH_MotorcycleController_GetLeanSmoothingFactor(const JPH_MotorcycleController* controller)
{
	return AsMotorcycleController(controller)->GetLeanSmoothingFactor();
}

void JPH_MotorcycleController_SetLeanSmoothingFactor(JPH_MotorcycleController* controller, float value)
{
	AsMotorcycleController(controller)->SetLeanSmoothingFactor(value);
}

/* LinearCurve */

JPH_LinearCurve* JPH_LinearCurve_Create()
{
	JPH::LinearCurve* curve = new JPH::LinearCurve();
	return ToLinearCurve(curve);
}

void JPH_LinearCurve_Destroy(JPH_LinearCurve* curve)
{
	if (curve)
	{
		delete AsLinearCurve(curve);
	}
}

void JPH_LinearCurve_Clear(JPH_LinearCurve* curve)
{
	JPH_ASSERT(curve);
	AsLinearCurve(curve)->Clear();
}

void JPH_LinearCurve_Reserve(JPH_LinearCurve* curve, uint32_t numPoints)
{
	JPH_ASSERT(curve);
	AsLinearCurve(curve)->Reserve(numPoints);
}

void JPH_LinearCurve_AddPoint(JPH_LinearCurve* curve, float x, float y)
{
	JPH_ASSERT(curve);
	AsLinearCurve(curve)->AddPoint(x, y);
}

void JPH_LinearCurve_Sort(JPH_LinearCurve* curve)
{
	JPH_ASSERT(curve);
	AsLinearCurve(curve)->Sort();
}

float JPH_LinearCurve_GetMinX(const JPH_LinearCurve* curve)
{
	JPH_ASSERT(curve);
	return AsLinearCurve(curve)->GetMinX();
}

float JPH_LinearCurve_GetMaxX(const JPH_LinearCurve* curve)
{
	JPH_ASSERT(curve);
	return AsLinearCurve(curve)->GetMaxX();
}

float JPH_LinearCurve_GetValue(const JPH_LinearCurve* curve, float x)
{
	JPH_ASSERT(curve);
	return AsLinearCurve(curve)->GetValue(x);
}

uint32_t JPH_LinearCurve_GetPointCount(const JPH_LinearCurve* curve)
{
	JPH_ASSERT(curve);
	return static_cast<uint32_t>(AsLinearCurve(curve)->mPoints.size());
}

void JPH_LinearCurve_GetPoint(const JPH_LinearCurve* curve, uint32_t index, JPH_Point* result)
{
	JPH_ASSERT(curve);
	JPH_ASSERT(result);

	auto point = AsLinearCurve(curve)->mPoints[index];
	FromJolt(point, result);
}

void JPH_LinearCurve_GetPoints(const JPH_LinearCurve* curve, JPH_Point* points, uint32_t* count)
{
	JPH_ASSERT(curve);
	auto joltPoints = AsLinearCurve(curve)->mPoints;
	*count = static_cast<uint32_t>(joltPoints.size());
	if (points)
	{
		for (int i = 0; i < joltPoints.size(); ++i)
		{
			auto point = joltPoints[i];
			points[i] = JPH_Point{
				point.mX,
				point.mY,
			};
		}
	}
}

JPH_TempAllocator *JPH_TempAllocator_Create(uint32_t size)
{
    return ToTempAllocator(new TempAllocatorImplWithMallocFallback(size));
}

JPH_TempAllocator *JPH_TempAllocatorMalloc_Create(void)
{
    return ToTempAllocator(new TempAllocatorMalloc());
}

void JPH_TempAllocator_Destroy(JPH_TempAllocator* allocator) {
    if (allocator) delete AsTempAllocator(allocator);
}

JPH_PhysicsUpdateError
JPH_PhysicsSystem_Update2(JPH_PhysicsSystem *system, float deltaTime, int collisionSteps, JPH_TempAllocator *tempAllocator, JPH_JobSystem *jobSystem)
{
    JPH::JobSystem* joltJobSystem = reinterpret_cast<JPH::JobSystem*>(jobSystem);
    return static_cast<JPH_PhysicsUpdateError>(system->physicsSystem->Update(deltaTime, collisionSteps, AsTempAllocator(tempAllocator), joltJobSystem));
}

JPH_SUPPRESS_WARNING_POP
